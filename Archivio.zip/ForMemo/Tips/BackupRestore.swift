import SwiftUI
import CryptoKit
import SwiftData
import UniformTypeIdentifiers

struct BackupRestoreView: View {
    @Environment(\.modelContext) private var modelContext

    @Query(sort: \TodoTask.createdAt, order: .forward)
    private var tasks: [TodoTask]
    @Query(sort: \LoyaltyCard.createdAt, order: .forward)
    private var loyaltyCards: [LoyaltyCard]
    @Query(sort: \TripList.sortOrder)
    private var tripLists: [TripList]
    @Query(sort: \DocumentItem.createdAt, order: .forward)
    private var documents: [DocumentItem]
    @Query(sort: \Note.createdAt, order: .forward)
    private var notes: [Note]
    @Query(sort: \VaultItem.title, order: .forward)
    private var vaultItems: [VaultItem]
    
    @State private var isCreatingBackup = false
    @State private var isRestoringBackup = false
    @State private var showRestoreConfirmation = false
    @State private var exportURL: URL?
    @State private var showExporter = false
    @State private var showImporter = false
    @State private var restoreError: String?
    @State private var backupError: String?
    @State private var restoreArchive: BackupArchive?
    @State private var restoreActiveTasks = false
    @State private var restoreCompletedTasks = false
    @State private var restoreWalletCards = false
    @State private var restoreNotes = false
    @State private var restoreTripLists = false
    @State private var restoreDocuments = false
    @State private var restoreVault = false
    @State private var restoreSettings = false
    @State private var backupPassword = ""
    @State private var backupPasswordConfirmation = ""
    @State private var showBackupPasswordPrompt = false
    @State private var showVaultPasswordError = false
    @State private var showBackupCreationPasswordPrompt = false
    @State private var pendingRestoreArchive: BackupArchive?

    @State private var pendingRestoreActiveTasks = false
    @State private var pendingRestoreCompletedTasks = false
    @State private var pendingRestoreWalletCards = false
    @State private var pendingRestoreNotes = false
    @State private var pendingRestoreTripLists = false
    @State private var pendingRestoreDocuments = false
    @State private var pendingRestoreVault = false
    @State private var pendingRestoreSettings = false
    
    private var allRestoreOptionsSelected: Bool {
        guard let archive = restoreArchive else {
            return false
        }

        let hasActiveTasks = archive.tasks.contains {
            !($0.isCompleted ?? false)
        }

        let hasCompletedTasks = archive.tasks.contains {
            $0.isCompleted ?? false
        }

        return (!hasActiveTasks || restoreActiveTasks) &&
            (!hasCompletedTasks || restoreCompletedTasks) &&
            (archive.notes.isEmpty || restoreNotes) &&
            (archive.loyaltyCards.isEmpty || restoreWalletCards) &&
            (archive.tripLists.isEmpty || restoreTripLists) &&
            (archive.documents.isEmpty || restoreDocuments) &&
            (archive.vaultItems.isEmpty || restoreVault) &&
            (archive.settings.isEmpty || restoreSettings)
    }
    
    private var hasPendingNonVaultRestore: Bool {
        pendingRestoreActiveTasks ||
        pendingRestoreCompletedTasks ||
        pendingRestoreNotes ||
        pendingRestoreWalletCards ||
        pendingRestoreTripLists ||
        pendingRestoreDocuments ||
        pendingRestoreSettings
    }
    
    
    var body: some View {

        ZStack {

            AppGlassBackground()

            List {

                Section {

                    VStack(alignment: .leading, spacing: 10) {


                        Text("Backups are stored independently from iCloud sync. You can use them to safely migrate all your ForMemo data to another device.")
                        .font(.caption)
                        .foregroundStyle(.primary)
                    }
                    .padding(.vertical, 8)
                    .listRowInsets(
                        EdgeInsets(top: 2, leading: 16, bottom: 8, trailing: 16)
                    )
                    .listRowBackground(Color.clear)
                }

                Section {

                    Button {
                        let hasVaultCredentials = vaultItems.contains { item in
                            let hasPassword = !(item.encryptedPassword?.isEmpty ?? true)
                            let hasPIN = !(item.encryptedPIN?.isEmpty ?? true)
                            let hasSecrets = !((item.secrets ?? []).isEmpty)

                            return hasPassword || hasPIN || hasSecrets
                        }
                        if !hasVaultCredentials {
                            // No Vault credentials to protect, no password required
                            Task {
                                do {
                                    isCreatingBackup = true
                                    let url = try await BackupManager.createBackup(
                                        tasks: tasks,
                                        notes: notes,
                                        loyaltyCards: loyaltyCards,
                                        tripLists: tripLists,
                                        documents: documents,
                                        vaultItems: vaultItems,
                                        vaultBackupPassword: ""
                                    )
                                    exportURL = url
                                    showExporter = true
                                    isCreatingBackup = false
                                } catch {
                                    backupError = error.localizedDescription
                                    isCreatingBackup = false
                                }
                            }
                        } else {
                            // Vault credentials present, prompt for password
                            showBackupCreationPasswordPrompt = true
                        }
                    } label: {

                        Label {
                            VStack(alignment: .leading, spacing: 2) {

                                Text("Create Backup")
                                    .foregroundStyle(.blue)
                                    Text(
                                        "Create a complete backup of tasks, notes, checklists, reminders, recurrence rules, tags, priorities, locations, cards and tickets, documents, attachments, Vault items and app settings."
                                    )
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            }
                        } icon: {
                            Image(systemName: "externaldrive.badge.plus")
                                .foregroundStyle(.blue)
                        }
                    }
                    .foregroundStyle(.primary)
                }

                Section {

                    Button {
                        showRestoreConfirmation = true
                    } label: {

                        Label {
                            VStack(alignment: .leading, spacing: 2) {

                                Text("Restore Backup")
                                    .foregroundStyle(.blue)

                                Text(
                                    "Restore data from a previously exported backup."
                                )
                                .font(.caption)
                                .foregroundStyle(.secondary)
                            }
                        } icon: {
                            Image(systemName: "arrow.clockwise.icloud")
                                .foregroundStyle(.green)
                        }
                    }
                    .foregroundStyle(.primary)
                }
                Section {

                    VStack(alignment: .leading, spacing: 18) {

                        HStack(alignment: .top, spacing: 12) {

                            Image(systemName: "checkmark.shield")
                                .foregroundStyle(.green)
                                .frame(width: 24)

                            VStack(alignment: .leading, spacing: 2) {

                                Text("Backup includes")

                                Text(
                                    "Tasks, notes, checklists, reminders, recurrence rules, tags, priorities, snooze state, locations, cards and tickets, documents, attachments and Vault items are included in the backup archive."
                                )
                                
                                .foregroundStyle(.secondary)
                            }
                            .font(.caption)
                        }

                        Divider()
                            .padding(.leading, 36)

                        HStack(alignment: .top, spacing: 12) {

                            Image(systemName: "externaldrive")
                                .foregroundStyle(.blue)
                                .frame(width: 24)

                            VStack(alignment: .leading, spacing: 2) {

                                Text("Independent from iCloud Sync")

                                Text(
                                    "Backups can be stored anywhere and restored even on a different Apple account."
                                )
                                
                                .foregroundStyle(.secondary)
                            }
                            .font(.caption)
                        }
                    }
                    .listRowBackground(Color.clear)
                }
            }
            .scrollContentBackground(.hidden)
            .listSectionSpacing(12)
            .background(Color.clear)
            .contentMargins(.bottom, 70, for: .scrollContent)
        }
        .overlay {

            if isCreatingBackup || isRestoringBackup {

                ZStack {

                    Rectangle()
                        .fill(.black.opacity(0.2))
                        .ignoresSafeArea()

                    ProgressView {
                        Text(
                            isCreatingBackup
                            ? "Preparing Backup..."
                            : "Restoring Backup..."
                        )
                    }
                    .padding(24)
                    .background(.ultraThinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))
                }
            }
        }
        .confirmationDialog(
            "Restore Backup",
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {

            Button("Restore", role: .destructive) {
                showImporter = true
            }

            Button("Cancel", role: .cancel) {

            }

        } message: {
            Text(
                "Restoring a backup may overwrite your current local data."
            )
        }
        .fileExporter(
            isPresented: $showExporter,
            document: exportURL.map {
                BackupFileDocument(fileURL: $0)
            },
            contentType: .json,
            defaultFilename: "FM_BK"
        ) { _ in
            isCreatingBackup = false
        }
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: [.json]
        ) { result in

            switch result {
            case .success(let url):

                let didAccess = url.startAccessingSecurityScopedResource()

                Task {
                    do {
                        defer {
                            if didAccess {
                                url.stopAccessingSecurityScopedResource()
                            }
                        }

                        let archive = try await BackupManager.loadBackupArchive(from: url)

                        await MainActor.run {
                            restoreActiveTasks = false
                            restoreCompletedTasks = false
                            restoreWalletCards = false
                            restoreNotes = false
                            restoreTripLists = false
                            restoreDocuments = false
                            restoreVault = false
                            restoreSettings = false

                            pendingRestoreArchive = nil
                            pendingRestoreActiveTasks = false
                            pendingRestoreCompletedTasks = false
                            pendingRestoreWalletCards = false
                            pendingRestoreNotes = false
                            pendingRestoreTripLists = false
                            pendingRestoreDocuments = false
                            pendingRestoreVault = false
                            pendingRestoreSettings = false

                            backupPassword = ""

                            restoreArchive = archive
                        }
                        
                        
                        await MainActor.run {
                            restoreArchive = archive
                        }

                    } catch {
                        await MainActor.run {
                            restoreError = error.localizedDescription
                        }
                    }
                }

            case .failure(let error):
                restoreError = error.localizedDescription
            }
        }
        .sheet(item: Binding(
            get: { restoreArchive.map { RestoreArchiveSheetWrapper(archive: $0) } },
            set: { newValue in
                restoreArchive = newValue?.archive
            }
        )) { wrapper in

            let archive = wrapper.archive
            let hasSelection =
                restoreActiveTasks ||
                restoreCompletedTasks ||
                restoreNotes ||
                restoreWalletCards ||
                restoreTripLists ||
                restoreDocuments ||
                restoreVault ||
                restoreSettings

            NavigationStack {
                ZStack {
                    AppGlassBackground()
                    List {
                        Section("Backup Contents") {

                            Text(
                                "Active Tasks: \(archive.tasks.filter { !($0.isCompleted ?? false) }.count)"
                            )

                            Text(
                                "Completed Tasks: \(archive.tasks.filter { $0.isCompleted ?? false }.count)"
                            )
                            
                            Text("Notes: \(archive.notes.count)")
                            
                            Text("Cards & Tickets: \(archive.loyaltyCards.count)")

                            if !archive.tripLists.isEmpty {
                                Text("Checklists: \(archive.tripLists.count)")
                            }

                            if !archive.documents.isEmpty {
                                Text("Documents: \(archive.documents.count)")
                            }

                            // Show Vault count after Documents (or after Cards & Tickets if Documents are absent)
                            if !archive.vaultItems.isEmpty {
                                Text("Vault: \(archive.vaultItems.count)")
                            }

                            if !archive.settings.isEmpty {
                                Text("Settings: Included")
                            }
                        }

                        Section("Restore") {

                            Toggle(
                                "Select All",
                                isOn: Binding(
                                    get: {
                                        allRestoreOptionsSelected
                                    },
                                    set: { newValue in
                                        guard let archive = restoreArchive else {
                                            return
                                        }

                                        restoreActiveTasks = newValue
                                        restoreCompletedTasks = newValue

                                        if !archive.notes.isEmpty {
                                            restoreNotes = newValue
                                        }

                                        if !archive.loyaltyCards.isEmpty {
                                            restoreWalletCards = newValue
                                        }

                                        if !archive.tripLists.isEmpty {
                                            restoreTripLists = newValue
                                        }

                                        if !archive.documents.isEmpty {
                                            restoreDocuments = newValue
                                        }

                                        if !archive.vaultItems.isEmpty {
                                            restoreVault = newValue
                                        }

                                        if !archive.settings.isEmpty {
                                            restoreSettings = newValue
                                        }
                                    }
                                )
                            )
                            
                            if archive.tasks.contains(where: { !($0.isCompleted ?? false) }) {
                                Toggle(
                                    "Active Tasks",
                                    isOn: $restoreActiveTasks
                                )
                            }

                            if archive.tasks.contains(where: { $0.isCompleted ?? false }) {
                                Toggle(
                                    "Completed Tasks",
                                    isOn: $restoreCompletedTasks
                                )
                            }
                            
                            if !archive.notes.isEmpty {
                                Toggle(
                                    "Notes",
                                    isOn: $restoreNotes
                                )
                            }

                            Toggle(
                                "Cards & Tickets",
                                isOn: $restoreWalletCards
                            )

                            if !archive.tripLists.isEmpty {
                                Toggle(
                                    "Checklists",
                                    isOn: $restoreTripLists
                                )
                            }

                            if !archive.documents.isEmpty {
                                Toggle(
                                    "Documents",
                                    isOn: $restoreDocuments
                                )
                            }

                            if !archive.vaultItems.isEmpty {
                                Toggle("Vault", isOn: $restoreVault)
                            }

                            if !archive.settings.isEmpty {
                                Toggle(
                                    "Settings",
                                    isOn: $restoreSettings
                                )
                            }
                        }
                    }
                    .navigationTitle("Restore Backup")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarLeading) {
                            Button("Cancel") {
                                restoreActiveTasks = false
                                restoreCompletedTasks = false
                                restoreWalletCards = false
                                restoreTripLists = false
                                restoreDocuments = false
                                restoreVault = false
                                restoreSettings = false
                                restoreArchive = nil
                                backupPassword = ""
                            }
                        }

                        ToolbarItem(placement: .topBarTrailing) {
                            Button("Restore") {
                                // If restoring Vault, prompt for password, else restore immediately
                                if !restoreVault {
                                    // No vault restore, no password required
                                    let selectedActiveTasks = restoreActiveTasks
                                    let selectedCompletedTasks = restoreCompletedTasks
                                    let selectedNotes = restoreNotes
                                    let selectedWalletCards = restoreWalletCards
                                    let selectedTripLists = restoreTripLists
                                    let selectedDocuments = restoreDocuments
                                    let selectedVault = restoreVault
                                    let selectedSettings = restoreSettings
                                    let archiveToRestore = restoreArchive
                                    // Reset selections and archive
                                    restoreActiveTasks = false
                                    restoreCompletedTasks = false
                                    restoreWalletCards = false
                                    restoreTripLists = false
                                    restoreDocuments = false
                                    restoreVault = false
                                    restoreSettings = false
                                    restoreArchive = nil
                                    backupPassword = ""
                                    Task {
                                        do {
                                            isRestoringBackup = true
                                            guard let archive = archiveToRestore else {
                                                isRestoringBackup = false
                                                return
                                            }
            
                                            try await BackupManager.restoreArchive(
                                                archive,
                                                modelContext: modelContext,
                                                restoreActiveTasks: selectedActiveTasks,
                                                restoreCompletedTasks: selectedCompletedTasks,
                                                restoreNotes: selectedNotes,
                                                restoreWalletCards: selectedWalletCards,
                                                restoreTripLists: selectedTripLists,
                                                restoreDocuments: selectedDocuments,
                                                restoreVault: selectedVault,
                                                backupPassword: "",
                                                restoreSettings: selectedSettings
                                            )
                                            isRestoringBackup = false
                                        } catch {
                                            isRestoringBackup = false

                                            if case VaultBackupCryptoError.invalidPassword = error {
                                                showVaultPasswordError = true
                                            } else {
                                                restoreError = error.localizedDescription
                                            }
                                        }
                                    }
                                } else {
                                    // Vault restore selected, prompt for password
                                    pendingRestoreArchive = restoreArchive

                                    pendingRestoreActiveTasks = restoreActiveTasks
                                    pendingRestoreCompletedTasks = restoreCompletedTasks
                                    pendingRestoreNotes = restoreNotes
                                    pendingRestoreWalletCards = restoreWalletCards
                                    pendingRestoreTripLists = restoreTripLists
                                    pendingRestoreDocuments = restoreDocuments
                                    pendingRestoreVault = restoreVault
                                    pendingRestoreSettings = restoreSettings

                                    showBackupPasswordPrompt = true
                                }
                            }
                            .disabled(!hasSelection)
                        }
                    }
                    .background(Color.clear)
                    .scrollContentBackground(.hidden)
                }
            }
        }
        .alert(
            "Backup Error",
            isPresented: Binding(
                get: { backupError != nil },
                set: { if !$0 { backupError = nil } }
            )
        ) {
            Button("OK", role: .cancel) {
                backupError = nil
            }
        } message: {
            Text(backupError ?? "")
        }
        .alert(
            "Restore Error",
            isPresented: Binding(
                get: { restoreError != nil },
                set: { if !$0 { restoreError = nil } }
            )
        ) {
            Button("OK", role: .cancel) {
                restoreError = nil
            }
        } message: {
            Text(restoreError ?? "")
        }
        .alert("Backup Password", isPresented: $showBackupPasswordPrompt) {
            SecureField("Password", text: $backupPassword)
            Button("Cancel", role: .cancel) {
                backupPassword = ""
                showBackupPasswordPrompt = false
            }
            Button("Restore") {
                let selectedActiveTasks = pendingRestoreActiveTasks
                let selectedCompletedTasks = pendingRestoreCompletedTasks
                let selectedNotes = pendingRestoreNotes
                let selectedWalletCards = pendingRestoreWalletCards
                let selectedTripLists = pendingRestoreTripLists
                let selectedDocuments = pendingRestoreDocuments
                let selectedVault = pendingRestoreVault
                let selectedSettings = pendingRestoreSettings

                let archiveToRestore = pendingRestoreArchive
                restoreActiveTasks = false
                restoreCompletedTasks = false
                restoreWalletCards = false
                restoreTripLists = false
                restoreDocuments = false
                restoreVault = false
                restoreSettings = false
                restoreArchive = nil
                showBackupPasswordPrompt = false

                Task {
                    do {
                        guard let archive = archiveToRestore else {
                            backupPassword = ""
                            return
                        }

                        try BackupManager.validateVaultBackupPassword(
                            in: archive,
                            password: backupPassword
                        )

                        isRestoringBackup = true

                        try await BackupManager.restoreArchive(
                            archive,
                            modelContext: modelContext,
                            restoreActiveTasks: selectedActiveTasks,
                            restoreCompletedTasks: selectedCompletedTasks,
                            restoreNotes: selectedNotes,
                            restoreWalletCards: selectedWalletCards,
                            restoreTripLists: selectedTripLists,
                            restoreDocuments: selectedDocuments,
                            restoreVault: selectedVault,
                            backupPassword: backupPassword,
                            restoreSettings: selectedSettings
                        )
                        isRestoringBackup = false
                        
                    } catch {
                        isRestoringBackup = false

                        if case VaultBackupCryptoError.invalidPassword = error {
                            showVaultPasswordError = true
                        } else {
                            restoreError = error.localizedDescription
                        }
                    }
                }
            }
        } message: {
            Text("Enter the password to unlock the backup.")
        }
        .alert(
            "Incorrect Password",
            isPresented: $showVaultPasswordError
        ) {
            Button("Try Again") {
                backupPassword = ""
                showVaultPasswordError = false

                DispatchQueue.main.async {
                    showBackupPasswordPrompt = true
                }
            }

            if hasPendingNonVaultRestore {
                Button("Skip Vault") {
                    restoreWithoutVault()
                }
            }

            Button("Cancel", role: .cancel) {
                backupPassword = ""
                pendingRestoreArchive = nil
                pendingRestoreActiveTasks = false
                pendingRestoreCompletedTasks = false
                pendingRestoreNotes = false
                pendingRestoreWalletCards = false
                pendingRestoreTripLists = false
                pendingRestoreDocuments = false
                pendingRestoreVault = false
                pendingRestoreSettings = false
            }
        } message: {
            if hasPendingNonVaultRestore {
                Text("The password is incorrect. Enter the correct password to restore Vault, or continue without Vault.")
            } else {
                Text("The password is incorrect. Enter the correct password to restore Vault.")
            }
        }
        .alert("Backup Password", isPresented: $showBackupCreationPasswordPrompt) {
            SecureField("Password", text: $backupPassword)
            SecureField("Confirm Password", text: $backupPasswordConfirmation)
            Button("Cancel", role: .cancel) {
                backupPassword = ""
                backupPasswordConfirmation = ""
                showBackupCreationPasswordPrompt = false
            }
            Button("Create Backup") {
                showBackupCreationPasswordPrompt = false
                Task {
                    do {
                        isCreatingBackup = true
                        let url = try await BackupManager.createBackup(
                            tasks: tasks,
                            notes: notes,
                            loyaltyCards: loyaltyCards,
                            tripLists: tripLists,
                            documents: documents,
                            vaultItems: vaultItems,
                            vaultBackupPassword: backupPassword
                        )
                        exportURL = url
                        showExporter = true
                        isCreatingBackup = false
                        backupPassword = ""
                        backupPasswordConfirmation = ""
                    } catch {
                        backupError = error.localizedDescription
                        isCreatingBackup = false
                        backupPassword = ""
                        backupPasswordConfirmation = ""
                    }
                }
            }
            .disabled(backupPassword.isEmpty || backupPassword != backupPasswordConfirmation)
        } message: {
            Text("Choose a password and confirm it. This password will be required only to restore Vault data from this backup.")
        }
        .navigationTitle("Backup & Restore")
        .navigationBarTitleDisplayMode(.inline)
    }
    
    
    private func restoreWithoutVault() {
        guard let archive = pendingRestoreArchive else {
            return
        }
        
        guard hasPendingNonVaultRestore else {
            showVaultPasswordError = false
            backupPassword = ""
            pendingRestoreArchive = nil
            pendingRestoreActiveTasks = false
            pendingRestoreCompletedTasks = false
            pendingRestoreWalletCards = false
            pendingRestoreNotes = false
            pendingRestoreTripLists = false
            pendingRestoreDocuments = false
            pendingRestoreVault = false
            pendingRestoreSettings = false
            return
        }
        

        let selectedActiveTasks = pendingRestoreActiveTasks
        let selectedCompletedTasks = pendingRestoreCompletedTasks
        let selectedNotes = pendingRestoreNotes
        let selectedWalletCards = pendingRestoreWalletCards
        let selectedVault = false
        let selectedTripLists = pendingRestoreTripLists
        let selectedDocuments = pendingRestoreDocuments
        let selectedSettings = pendingRestoreSettings

        showVaultPasswordError = false
        isRestoringBackup = true

        Task {
            defer {
                pendingRestoreArchive = nil
                pendingRestoreActiveTasks = false
                pendingRestoreCompletedTasks = false
                pendingRestoreWalletCards = false
                pendingRestoreTripLists = false
                pendingRestoreDocuments = false
                pendingRestoreVault = false
                pendingRestoreSettings = false
                backupPassword = ""
            }

            do {
                try await BackupManager.restoreArchive(
                    archive,
                    modelContext: modelContext,
                    restoreActiveTasks: selectedActiveTasks,
                    restoreCompletedTasks: selectedCompletedTasks,
                    restoreNotes: selectedNotes,
                    restoreWalletCards: selectedWalletCards,
                    restoreTripLists: selectedTripLists,
                    restoreDocuments: selectedDocuments,
                    restoreVault: selectedVault,
                    backupPassword: "",
                    restoreSettings: selectedSettings
                )

                isRestoringBackup = false
            } catch {
                isRestoringBackup = false
                restoreError = error.localizedDescription
            }
        }
    }
    
}

private struct RestoreArchiveSheetWrapper: Identifiable {

    let archive: BackupArchive

    var id: Date {

        archive.createdAt

    }

}

private enum BackupFormat {
    static let currentVersion = 5
}

private extension JSONEncoder {
    
    static let backup: JSONEncoder = {
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.sortedKeys]
            encoder.dateEncodingStrategy = .iso8601
            return encoder
        }()
    }

private extension JSONDecoder {

    static let backup: JSONDecoder = {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }()
}

private struct BackupArchive: Codable {

    enum CodingKeys: String, CodingKey {
        case version
        case createdAt
        case tasks
        case notes
        case loyaltyCards
        case tripLists
        case documents
        case documentAssets
        case documentFiles
        case vaultItems
        case vaultBackupPackage
        case attachmentFiles
        case loyaltyCardLogoFiles
        case settings
    }

    let version: Int
    let createdAt: Date
    let tasks: [TaskTransferObject]
    let notes: [NoteTransferObject]
    let loyaltyCards: [LoyaltyCardTransferObject]
    let tripLists: [TripListTransferObject]
    let documents: [DocumentTransferObject]
    let documentAssets: [DocumentAssetTransferObject]
    let documentFiles: [String: Data]
    let vaultItems: [VaultItemTransferObject]
    let vaultBackupPackage: VaultBackupPackage?
    let attachmentFiles: [String: Data]
    let loyaltyCardLogoFiles: [String: Data]
    let settings: [String: Data]


    init(
        version: Int,
        createdAt: Date,
        tasks: [TaskTransferObject],
        notes: [NoteTransferObject],
        loyaltyCards: [LoyaltyCardTransferObject],
        tripLists: [TripListTransferObject],
        documents: [DocumentTransferObject],
        documentAssets: [DocumentAssetTransferObject],
        documentFiles: [String: Data],
        vaultItems: [VaultItemTransferObject],
        vaultBackupPackage: VaultBackupPackage?,
        attachmentFiles: [String: Data],
        loyaltyCardLogoFiles: [String: Data],
        settings: [String: Data]
    ) {
        self.version = version
        self.createdAt = createdAt
        self.tasks = tasks
        self.notes = notes
        self.loyaltyCards = loyaltyCards
        self.tripLists = tripLists
        self.documents = documents
        self.documentAssets = documentAssets
        self.documentFiles = documentFiles
        self.vaultItems = vaultItems
        self.vaultBackupPackage = vaultBackupPackage
        self.attachmentFiles = attachmentFiles
        self.loyaltyCardLogoFiles = loyaltyCardLogoFiles
        self.settings = settings
        
        
    }

    init(from decoder: Decoder) throws {

        let container = try decoder.container(keyedBy: CodingKeys.self)

        version = try container.decode(Int.self, forKey: .version)
        createdAt = try container.decodeIfPresent(Date.self, forKey: .createdAt) ?? .now

        let taskData = try container.decode([Data].self, forKey: .tasks)

        tasks = try taskData.map {
            try JSONDecoder.backup.decode(
                TaskTransferObject.self,
                from: $0
            )
        }
        loyaltyCards = try container.decodeIfPresent(
            [LoyaltyCardTransferObject].self,
            forKey: .loyaltyCards
        ) ?? []
        notes = try container.decodeIfPresent(
            [NoteTransferObject].self,
            forKey: .notes
        ) ?? []
        tripLists = try container.decodeIfPresent(
            [TripListTransferObject].self,
            forKey: .tripLists
        ) ?? []
        documents = try container.decodeIfPresent(
            [DocumentTransferObject].self,
            forKey: .documents
        ) ?? []
        documentAssets = try container.decodeIfPresent(
            [DocumentAssetTransferObject].self,
            forKey: .documentAssets
        ) ?? []

        documentFiles = try container.decodeIfPresent(
            [String: Data].self,
            forKey: .documentFiles
        ) ?? [:]
        vaultItems = try container.decodeIfPresent(
            [VaultItemTransferObject].self,
            forKey: .vaultItems
        ) ?? []

        vaultBackupPackage = try container.decodeIfPresent(
            VaultBackupPackage.self,
            forKey: .vaultBackupPackage
        )
        attachmentFiles = try container.decodeIfPresent(
            [String: Data].self,
            forKey: .attachmentFiles
        ) ?? [:]
        loyaltyCardLogoFiles = try container.decodeIfPresent(
            [String: Data].self,
            forKey: .loyaltyCardLogoFiles
        ) ?? [:]
        settings = try container.decodeIfPresent(
            [String: Data].self,
            forKey: .settings
        ) ?? [:]
    }

    func encode(to encoder: Encoder) throws {

        var container = encoder.container(keyedBy: CodingKeys.self)

        try container.encode(version, forKey: .version)
        try container.encode(createdAt, forKey: .createdAt)

        let encodedTasks = try tasks.map {
            try JSONEncoder.backup.encode($0)
        }
        
        

        try container.encode(encodedTasks, forKey: .tasks)
        try container.encode(
            notes,
            forKey: .notes
        )
        try container.encode(
            loyaltyCards,
            forKey: .loyaltyCards
        )
        try container.encode(
            tripLists,
            forKey: .tripLists
        )
        try container.encode(
            documents,
            forKey: .documents
        )
        
        try container.encode(
            documentAssets,
            forKey: .documentAssets
        )

        try container.encode(
            documentFiles,
            forKey: .documentFiles
        )
        
        try container.encode(
            vaultItems,
            forKey: .vaultItems
        )
        try container.encodeIfPresent(
            vaultBackupPackage,
            forKey: .vaultBackupPackage
        )
        try container.encode(
            attachmentFiles,
            forKey: .attachmentFiles
        )
        try container.encode(
            loyaltyCardLogoFiles,
            forKey: .loyaltyCardLogoFiles
        )
        try container.encode(
            settings,
            forKey: .settings
        )
    }
}

private struct NoteTransferObject: Codable {
    let id: UUID
    let title: String
    let content: Data
    let createdAt: Date
    let modifiedAt: Date
    let isPinned: Bool
    let isArchived: Bool
    let color: String?
    let archivedAt: Date?
    let lastOpenedAt: Date?
    let sortOrder: Int
    
    private enum CodingKeys: String, CodingKey {
        case id
        case title
        case content
        case createdAt
        case modifiedAt
        case isPinned
        case isArchived
        case color
        case archivedAt
        case lastOpenedAt
        case sortOrder
    }

    init(note: Note) {
        self.id = note.id
        self.title = note.title
        self.content = note.content
        self.createdAt = note.createdAt
        self.modifiedAt = note.modifiedAt
        self.isPinned = note.isPinned
        self.isArchived = note.isArchived
        self.color = note.color
        self.archivedAt = note.archivedAt
        self.lastOpenedAt = note.lastOpenedAt
        self.sortOrder = note.sortOrder
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)

        id = try container.decode(UUID.self, forKey: .id)
        title = try container.decode(String.self, forKey: .title)
        content = try container.decode(Data.self, forKey: .content)
        createdAt = try container.decode(Date.self, forKey: .createdAt)
        modifiedAt = try container.decode(Date.self, forKey: .modifiedAt)
        isPinned = try container.decode(Bool.self, forKey: .isPinned)
        isArchived = try container.decode(Bool.self, forKey: .isArchived)
        color = try container.decodeIfPresent(String.self, forKey: .color)
        archivedAt = try container.decodeIfPresent(Date.self, forKey: .archivedAt)
        lastOpenedAt = try container.decodeIfPresent(Date.self, forKey: .lastOpenedAt)
        sortOrder = try container.decodeIfPresent(Int.self, forKey: .sortOrder) ?? 0
    }
}

private struct LoyaltyCardTransferObject: Codable {

    let id: UUID
    let storeName: String
    let cardHolder: String?
    let barcodeValue: String
    let barcodeFormat: String
    let itemType: String
    let notes: String?
    let colorHex: String?
    let sortOrder: Int
    let createdAt: Date
    let assets: [WalletAssetTransferObject]

    enum CodingKeys: String, CodingKey {
        case id
        case storeName
        case cardHolder
        case barcodeValue
        case barcodeFormat
        case itemType
        case notes
        case colorHex
        case sortOrder
        case createdAt
        case assets
    }

    init(card: LoyaltyCard) {
        self.id = card.id
        self.storeName = card.storeName
        self.cardHolder = card.cardHolder
        self.barcodeValue = card.barcodeValue
        self.barcodeFormat = card.barcodeFormat
        self.itemType = card.itemType
        self.notes = card.notes
        self.colorHex = card.colorHex
        self.sortOrder = card.sortOrder
        self.createdAt = card.createdAt

        var exportedAssetPaths = Set<String>()

        self.assets = (card.assets ?? []).compactMap { asset in

            let relativePath = asset.relativePath
                .trimmingCharacters(in: .whitespacesAndNewlines)

            guard !relativePath.isEmpty else {
                return nil
            }

            guard exportedAssetPaths.insert(relativePath).inserted else {
                return nil
            }

            return WalletAssetTransferObject(
                kind: asset.kind,
                relativePath: relativePath
            )
        }
    }

    init(from decoder: Decoder) throws {

        let container = try decoder.container(
            keyedBy: CodingKeys.self
        )

        id = try container.decode(UUID.self, forKey: .id)
        storeName = try container.decode(String.self, forKey: .storeName)
        cardHolder = try container.decodeIfPresent(
            String.self,
            forKey: .cardHolder
        )
        barcodeValue = try container.decode(
            String.self,
            forKey: .barcodeValue
        )
        barcodeFormat = try container.decode(
            String.self,
            forKey: .barcodeFormat
        )
        itemType = try container.decodeIfPresent(
            String.self,
            forKey: .itemType
        ) ?? "loyaltyCard"
        notes = try container.decodeIfPresent(
            String.self,
            forKey: .notes
        )
        colorHex = try container.decodeIfPresent(
            String.self,
            forKey: .colorHex
        )

        sortOrder = try container.decodeIfPresent(
            Int.self,
            forKey: .sortOrder
        ) ?? 0

        createdAt = try container.decode(
            Date.self,
            forKey: .createdAt
        )

        assets = try container.decodeIfPresent(
            [WalletAssetTransferObject].self,
            forKey: .assets
        ) ?? []
    }

    struct WalletAssetTransferObject: Codable {

        let kind: WalletAssetKind
        let relativePath: String
    }
}

private struct DocumentTransferObject: Codable {

    let id: UUID
    let name: String
    let documentTypeRaw: String
    let documentNumber: String
    let issueDate: Date?
    let expiryDate: Date?
    let notes: String
    let storageLocation: String
    let notificationEnabled: Bool
    let notificationDaysBefore: Int
    let createdAt: Date
    
    private enum CodingKeys: String, CodingKey {
        case id
        case name
        case documentTypeRaw
        case documentNumber
        case issueDate
        case expiryDate
        case notes
        case storageLocation
        case notificationEnabled
        case notificationDaysBefore
        case createdAt
    }
    
    init(document: DocumentItem) {
        self.id = document.id
        self.name = document.name
        self.documentTypeRaw = document.documentTypeRaw
        self.documentNumber = document.documentNumber
        self.issueDate = document.issueDate
        self.expiryDate = document.expiryDate
        self.notes = document.notes
        self.storageLocation = document.storageLocation
        self.notificationEnabled = document.notificationEnabled
        self.notificationDaysBefore = document.notificationDaysBefore
        self.createdAt = document.createdAt
    }
    init(from decoder: Decoder) throws {

        let container = try decoder.container(keyedBy: CodingKeys.self)

        id = try container.decode(UUID.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        documentTypeRaw = try container.decode(String.self, forKey: .documentTypeRaw)
        documentNumber = try container.decode(String.self, forKey: .documentNumber)

        issueDate = try container.decodeIfPresent(Date.self, forKey: .issueDate)
        expiryDate = try container.decodeIfPresent(Date.self, forKey: .expiryDate)

        notes = try container.decodeIfPresent(
            String.self,
            forKey: .notes
        ) ?? ""

        storageLocation = try container.decodeIfPresent(
            String.self,
            forKey: .storageLocation
        ) ?? ""

        notificationEnabled = try container.decodeIfPresent(
            Bool.self,
            forKey: .notificationEnabled
        ) ?? false

        notificationDaysBefore = try container.decodeIfPresent(
            Int.self,
            forKey: .notificationDaysBefore
        ) ?? 30

        createdAt = try container.decode(Date.self, forKey: .createdAt)
    }
    
    
}

private struct DocumentAssetTransferObject: Codable {

    let documentID: UUID
    let relativePath: String
    let kindRaw: String
    let pageIndex: Int
    let fileSize: Int64
    let createdAt: Date

    init(asset: DocumentAsset) {
        documentID = asset.document?.id ?? UUID()
        relativePath = asset.relativePath
        kindRaw = asset.kindRaw
        pageIndex = asset.pageIndex
        fileSize = asset.fileSize
        createdAt = asset.createdAt
    }
}



private struct VaultSecretTransferObject: Codable {

    let encryptedLabel: Data?
    let encryptedValue: Data?
    let sortOrder: Int

    init(secret: VaultSecret) {
        encryptedLabel = secret.encryptedLabel
        encryptedValue = secret.encryptedValue
        sortOrder = secret.sortOrder
    }
    init(
        encryptedLabel: Data?,
        encryptedValue: Data?,
        sortOrder: Int
    ) {
        self.encryptedLabel = encryptedLabel
        self.encryptedValue = encryptedValue
        self.sortOrder = sortOrder
    }
}


private struct VaultItemTransferObject: Codable {

    let id: UUID
    let syncIdentifier: UUID
    let version: Int

    let title: String
    let category: VaultCategory

    let favorite: Bool

    let tags: [String]
    let sortOrder: Int

    let icon: VaultIcon
    let color: VaultColor

    let username: String
    let email: String
    let website: String
    let notes: String

    let encryptedPassword: Data?
    let encryptedPIN: Data?

    let secrets: [VaultSecretTransferObject]

    let createdAt: Date
    let modifiedAt: Date

    let passwordUpdatedAt: Date?
    let passwordExpiresAt: Date?

    let lastViewedAt: Date?
    let lastCopiedAt: Date?

    let deletedAt: Date?

    let requireBiometricEveryTime: Bool

    private enum CodingKeys: String, CodingKey {
        case id
        case syncIdentifier
        case version
        case title
        case category
        case favorite
        case tags
        case sortOrder
        case icon
        case color
        case username
        case email
        case website
        case notes
        case encryptedPassword
        case encryptedPIN
        case secrets
        case createdAt
        case modifiedAt
        case passwordUpdatedAt
        case passwordExpiresAt
        case lastViewedAt
        case lastCopiedAt
        case deletedAt
        case requireBiometricEveryTime
    }

    init(item: VaultItem) {

        id = item.id
        syncIdentifier = item.syncIdentifier
        version = item.version

        title = item.title
        category = item.category

        favorite = item.favorite

        tags = item.tags
        sortOrder = item.sortOrder

        icon = item.icon
        color = item.color

        username = item.username
        email = item.email
        website = item.website
        notes = item.notes

        encryptedPassword = item.encryptedPassword
        encryptedPIN = item.encryptedPIN

        secrets = (item.secrets ?? []).map {
            VaultSecretTransferObject(secret: $0)
        }

        createdAt = item.createdAt
        modifiedAt = item.modifiedAt

        passwordUpdatedAt = item.passwordUpdatedAt
        passwordExpiresAt = item.passwordExpiresAt

        lastViewedAt = item.lastViewedAt
        lastCopiedAt = item.lastCopiedAt

        deletedAt = item.deletedAt

        requireBiometricEveryTime = item.requireBiometricEveryTime
    }

    init(from decoder: Decoder) throws {

        let container = try decoder.container(
            keyedBy: CodingKeys.self
        )

        id = try container.decode(
            UUID.self,
            forKey: .id
        )

        syncIdentifier = try container.decode(
            UUID.self,
            forKey: .syncIdentifier
        )

        version = try container.decode(
            Int.self,
            forKey: .version
        )

        title = try container.decode(
            String.self,
            forKey: .title
        )

        category = try container.decode(
            VaultCategory.self,
            forKey: .category
        )

        favorite = try container.decodeIfPresent(
            Bool.self,
            forKey: .favorite
        ) ?? false

        tags = try container.decodeIfPresent(
            [String].self,
            forKey: .tags
        ) ?? []

        sortOrder = try container.decodeIfPresent(
            Int.self,
            forKey: .sortOrder
        ) ?? 0

        icon = try container.decodeIfPresent(
            VaultIcon.self,
            forKey: .icon
        ) ?? .key

        color = try container.decodeIfPresent(
            VaultColor.self,
            forKey: .color
        ) ?? .blue

        username = try container.decodeIfPresent(
            String.self,
            forKey: .username
        ) ?? ""

        email = try container.decodeIfPresent(
            String.self,
            forKey: .email
        ) ?? ""

        website = try container.decodeIfPresent(
            String.self,
            forKey: .website
        ) ?? ""

        notes = try container.decodeIfPresent(
            String.self,
            forKey: .notes
        ) ?? ""

        encryptedPassword = try container.decodeIfPresent(
            Data.self,
            forKey: .encryptedPassword
        )

        encryptedPIN = try container.decodeIfPresent(
            Data.self,
            forKey: .encryptedPIN
        )

        // VaultSecret was introduced after older backup formats.
        // Older backups do not contain this key.
        secrets = try container.decodeIfPresent(
            [VaultSecretTransferObject].self,
            forKey: .secrets
        ) ?? []

        createdAt = try container.decodeIfPresent(
            Date.self,
            forKey: .createdAt
        ) ?? .now

        modifiedAt = try container.decodeIfPresent(
            Date.self,
            forKey: .modifiedAt
        ) ?? createdAt

        passwordUpdatedAt = try container.decodeIfPresent(
            Date.self,
            forKey: .passwordUpdatedAt
        )

        passwordExpiresAt = try container.decodeIfPresent(
            Date.self,
            forKey: .passwordExpiresAt
        )

        lastViewedAt = try container.decodeIfPresent(
            Date.self,
            forKey: .lastViewedAt
        )

        lastCopiedAt = try container.decodeIfPresent(
            Date.self,
            forKey: .lastCopiedAt
        )

        deletedAt = try container.decodeIfPresent(
            Date.self,
            forKey: .deletedAt
        )

        requireBiometricEveryTime = try container.decodeIfPresent(
            Bool.self,
            forKey: .requireBiometricEveryTime
        ) ?? false
    }
}

private struct TripListTransferObject: Codable {
    let id: UUID
    let name: String
    let icon: String
    let colorHex: String
    let notes: String
    let systemTemplate: String
    let checklistType: String?
    let sortOrder: Int
    let createdAt: Date
    let updatedAt: Date
    let sections: [TripSectionData]

    init(tripList: TripList) {
        self.id = tripList.id
        self.name = tripList.name
        self.icon = tripList.icon
        self.colorHex = tripList.colorHex
        self.notes = tripList.notes
        self.systemTemplate = tripList.systemTemplate
        self.checklistType = tripList.checklistType
        self.sortOrder = tripList.sortOrder
        self.createdAt = tripList.createdAt
        self.updatedAt = tripList.updatedAt
        self.sections = tripList.sections
    }
}

private enum BackupManager {

    static func createBackup(
        tasks: [TodoTask],
        notes: [Note],
        loyaltyCards: [LoyaltyCard],
        tripLists: [TripList],
        documents: [DocumentItem],
        vaultItems: [VaultItem],
        vaultBackupPassword: String
    ) async throws -> URL {

        var attachmentPayload: [String: Data] = [:]
        var walletAssetPayload: [String: Data] = [:]

        var documentAssetPayload: [DocumentAssetTransferObject] = []
        var documentFilePayload: [String: Data] = [:]
        var exportedDocumentAssetKeys = Set<String>()

        var settingsPayload: [String: Data] = [:]

        let hasVaultCredentials = vaultItems.contains { item in
            let hasPassword = !(item.encryptedPassword?.isEmpty ?? true)
            let hasPIN = !(item.encryptedPIN?.isEmpty ?? true)
            let hasSecrets = !((item.secrets ?? []).isEmpty)

            return hasPassword || hasPIN || hasSecrets
        }

        let vaultPackage: VaultBackupPackage?

        if hasVaultCredentials {
            vaultPackage = try VaultCrypto.exportVaultKey(
                protecting: vaultBackupPassword
            )
        } else {
            vaultPackage = nil
        }
        let exportedSettings = await MainActor.run {
            AppSettings.shared.exportSettings()
        }

        for (key, value) in exportedSettings {
            if JSONSerialization.isValidJSONObject(["value": value]),
               let data = try? JSONSerialization.data(withJSONObject: ["value": value]) {
                settingsPayload[key] = data
            }
        }
        
        
        let patternSettings = await MainActor.run {
            (
                AppSettings.shared.backgroundPattern.rawValue,
                AppSettings.shared.backgroundPatternOpacity
            )
        }

        if let data = try? JSONSerialization.data(
            withJSONObject: ["value": patternSettings.0]
        ) {
            settingsPayload["backgroundPattern"] = data
        }

        if let data = try? JSONSerialization.data(
            withJSONObject: ["value": patternSettings.1]
        ) {
            settingsPayload["backgroundPatternOpacity"] = data
        }

        if !tasks.isEmpty {
            
            for task in tasks {

                guard let attachments = task.attachments else {
                    continue
                }

                for attachment in attachments {

                    let relativePath = attachment.relativePath
                        .trimmingCharacters(in: .whitespacesAndNewlines)

                    guard !relativePath.isEmpty else {
                        continue
                    }

                    if let data = await attachment.loadDataAsync() {
                        attachmentPayload[relativePath] = data
                    }
                }
            }
        }

        for card in loyaltyCards {

            for asset in card.assets ?? [] {

                guard let url = WalletAssetStore.fileURL(
                    relativePath: asset.relativePath
                ) else {
                    continue
                }

                let fileManager = FileManager.default

                try? fileManager.startDownloadingUbiquitousItem(at: url)

                for _ in 0..<40 {
                    let exists = fileManager.fileExists(atPath: url.path)

                    let values = try? url.resourceValues(
                        forKeys: [.ubiquitousItemDownloadingStatusKey]
                    )

                    let status = values?.ubiquitousItemDownloadingStatus

                    if exists &&
                        (status == .current ||
                         status == .downloaded ||
                         status == nil) {
                        break
                    }

                    try? await Task.sleep(
                        nanoseconds: 200_000_000
                    )
                }

                guard
                    fileManager.fileExists(atPath: url.path),
                    let data = try? Data(contentsOf: url),
                    !data.isEmpty
                else {
                    continue
                }

                walletAssetPayload[asset.relativePath] = data
            }
        }

        
        for document in documents {

            for asset in document.assets ?? [] {

                let relativePath = asset.relativePath
                    .trimmingCharacters(in: .whitespacesAndNewlines)

                guard !relativePath.isEmpty else {
                    continue
                }

                let key = "\(document.id.uuidString)|\(relativePath)"

                // Un file può comparire una sola volta per documento.
                if exportedDocumentAssetKeys.contains(key) {
                    continue
                }

                guard let url = asset.fileURL else {
                    continue
                }

                let fileManager = FileManager.default

                try? fileManager.startDownloadingUbiquitousItem(at: url)

                for _ in 0..<40 {
                    let exists = fileManager.fileExists(atPath: url.path)

                    let values = try? url.resourceValues(
                        forKeys: [.ubiquitousItemDownloadingStatusKey]
                    )

                    let status = values?.ubiquitousItemDownloadingStatus

                    if exists &&
                        (status == .current ||
                         status == .downloaded ||
                         status == nil) {
                        break
                    }

                    try? await Task.sleep(
                        nanoseconds: 200_000_000
                    )
                }

                guard
                    fileManager.fileExists(atPath: url.path),
                    let data = try? Data(contentsOf: url),
                    !data.isEmpty
                else {
                    continue
                }

                exportedDocumentAssetKeys.insert(key)

                let dto = DocumentAssetTransferObject(asset: asset)
                documentAssetPayload.append(dto)

                documentFilePayload[relativePath] = data
            }
        }
        
        let archive = BackupArchive(
            version: BackupFormat.currentVersion,
            createdAt: .now,
            tasks: tasks.map {
                TaskTransferObject(
                    task: $0,
                    validAttachmentPaths: Set(attachmentPayload.keys)
                )
            },
            notes: notes.map {
                NoteTransferObject(note: $0)
            },
            loyaltyCards: loyaltyCards.map {
                LoyaltyCardTransferObject(card: $0)
            },
            tripLists: tripLists.map {
                TripListTransferObject(tripList: $0)
            },
            documents: documents.map {
                DocumentTransferObject(document: $0)
            },
            documentAssets: documentAssetPayload,
            documentFiles: documentFilePayload,
            
            vaultItems: vaultItems.map {
                VaultItemTransferObject(item: $0)
            },
            vaultBackupPackage: vaultPackage,
            attachmentFiles: attachmentPayload,
            loyaltyCardLogoFiles: walletAssetPayload,
            settings: settingsPayload
        )

        let data = try JSONEncoder.backup.encode(archive)

        let formatter = DateFormatter()
        formatter.dateFormat = "ddMMyy_HHmmss"

        let filename = "FM_BK_\(formatter.string(from: .now)).json"

        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent(filename)

        try data.write(
            to: url,
            options: .atomic
        )

        return url
    }

    
    static func validateVaultBackupPassword(
        in archive: BackupArchive,
        password: String
    ) throws {
        guard let vaultBackupPackage = archive.vaultBackupPackage else {
            throw NSError(
                domain: "BackupManager",
                code: 1,
                userInfo: [
                    NSLocalizedDescriptionKey:
                        String(localized: "Vault restore requested, but no Vault backup package was found in the archive.")
                ]
            )
        }

        let keyData = try VaultBackupCrypto.unwrapKey(
            from: vaultBackupPackage,
            password: password
        )

        guard keyData.count == 32 else {
            throw VaultCryptoError.invalidData
        }
    }
    static func loadBackupArchive(from url: URL) async throws -> BackupArchive {

        let data = try await Task.detached(priority: .userInitiated) {
            try Data(contentsOf: url, options: .mappedIfSafe)
        }.value

        do {
            let archive = try JSONDecoder.backup.decode(
                BackupArchive.self,
                from: data
            )

            guard archive.version <= BackupFormat.currentVersion else {
                throw CocoaError(.coderReadCorrupt)
            }
            return archive
        } catch let DecodingError.dataCorrupted(context) {
            throw DecodingError.dataCorrupted(context)
        } catch let DecodingError.keyNotFound(key, context) {
            throw DecodingError.keyNotFound(key, context)

        } catch let DecodingError.typeMismatch(type, context) {

            throw DecodingError.typeMismatch(type, context)

        } catch let DecodingError.valueNotFound(type, context) {

            throw DecodingError.valueNotFound(type, context)
        } catch {
            throw error
        }
    }

    @MainActor
    static func restoreArchive(
        _ archive: BackupArchive,
        modelContext: ModelContext,
        restoreActiveTasks: Bool,
        restoreCompletedTasks: Bool,
        restoreNotes: Bool,
        restoreWalletCards: Bool,
        restoreTripLists: Bool,
        restoreDocuments: Bool,
        restoreVault: Bool,
        backupPassword: String,
        restoreSettings: Bool
    ) async throws {
        try PersistenceOperationCoordinator.shared.begin(.restore)
        
        defer {
            PersistenceOperationCoordinator.shared.finish()
        }
        
        var vaultKeyToInstall: SymmetricKey?
        
        var backupVaultKey: SymmetricKey?
        var finalVaultKey: SymmetricKey?

        if restoreVault {
            guard let vaultBackupPackage = archive.vaultBackupPackage else {
                throw NSError(
                    domain: "BackupManager",
                    code: 1,
                    userInfo: [
                        NSLocalizedDescriptionKey:
                            String(localized: "Vault restore requested, but no Vault backup package was found in the archive.")
                    ]
                )
            }

            let backupKeyData = try VaultBackupCrypto.unwrapKey(
                from: vaultBackupPackage,
                password: backupPassword
            )

            guard backupKeyData.count == 32 else {
                throw VaultCryptoError.invalidData
            }

            let backupKey = SymmetricKey(data: backupKeyData)
            let localKey = try VaultCrypto.existingKey()

            let finalKey: SymmetricKey

            if let localKey {
                finalKey = localKey
            } else {
                finalKey = backupKey
                vaultKeyToInstall = finalKey
            }

            backupVaultKey = backupKey
            finalVaultKey = finalKey
        }
        
        if restoreNotes {
            for noteData in archive.notes {
                let existingNote = try modelContext.fetch(
                    FetchDescriptor<Note>(
                        predicate: #Predicate { note in
                            note.id == noteData.id
                        }
                    )
                ).first

                guard existingNote == nil else {
                    continue
                }

                let note = Note(
                    id: noteData.id,
                    title: noteData.title,
                    content: noteData.content,
                    createdAt: noteData.createdAt,
                    modifiedAt: noteData.modifiedAt,
                    isPinned: noteData.isPinned,
                    isArchived: noteData.isArchived,
                    color: noteData.color,
                    archivedAt: noteData.archivedAt,
                    lastOpenedAt: noteData.lastOpenedAt,
                    sortOrder: noteData.sortOrder
                )

                modelContext.insert(note)
            }
        }
        if restoreActiveTasks || restoreCompletedTasks {

            let attachmentsDirectory =
                try TaskAttachment.ensureAttachmentsDirectoryForWrite()
            
            var createdAttachmentParents = Set<String>()

            for (relativePath, fileData) in archive.attachmentFiles {

                let destinationURL = attachmentsDirectory
                    .appendingPathComponent(relativePath)

                let parent = destinationURL.deletingLastPathComponent()
                let parentKey = parent.standardizedFileURL.path

                if !createdAttachmentParents.contains(parentKey) {
                    try FileManager.default.createDirectory(
                        at: parent,
                        withIntermediateDirectories: true
                    )
                    createdAttachmentParents.insert(parentKey)
                }

                let shouldWrite: Bool

                if FileManager.default.fileExists(atPath: destinationURL.path) {
                    if let existingData = try? Data(contentsOf: destinationURL) {
                        shouldWrite = existingData != fileData
                    } else {
                        shouldWrite = true
                    }
                } else {
                    shouldWrite = true
                }

                if shouldWrite {
                    try fileData.write(
                        to: destinationURL,
                        options: .atomic
                    )
                }
            }
        }

        if restoreWalletCards {

            let walletDirectory =
                try AssetDirectoryCoordinator
                    .ensureCanonicalDirectory(
                        for: .walletAssets
                    )

            var createdWalletParents = Set<String>()

            for (relativePath, fileData) in archive.loyaltyCardLogoFiles {

                let destinationURL = walletDirectory
                     .appendingPathComponent(relativePath)

                let parent = destinationURL.deletingLastPathComponent()
                let parentKey = parent.standardizedFileURL.path

                if !createdWalletParents.contains(parentKey) {
                    try FileManager.default.createDirectory(
                        at: parent,
                        withIntermediateDirectories: true
                    )
                    createdWalletParents.insert(parentKey)
                }

                try fileData.write(
                    to: destinationURL,
                    options: .atomic
                )
            }
        }

        if restoreDocuments {

            let documentDirectory =
                try AssetDirectoryCoordinator
                    .ensureCanonicalDirectory(
                        for: .documentAssets
                    )

            var createdDocumentParents = Set<String>()

            for (relativePath, fileData) in archive.documentFiles {

                let destinationURL = documentDirectory
                    .appendingPathComponent(relativePath)

                let parent = destinationURL.deletingLastPathComponent()
                let parentKey = parent.standardizedFileURL.path

                if !createdDocumentParents.contains(parentKey) {
                    try FileManager.default.createDirectory(
                        at: parent,
                        withIntermediateDirectories: true
                    )
                    createdDocumentParents.insert(parentKey)
                }

                try fileData.write(
                    to: destinationURL,
                    options: .atomic
                )
            }
        }
        
        if restoreDocuments && !archive.documents.isEmpty {
            for dto in archive.documents {

                let descriptor = FetchDescriptor<DocumentItem>(
                    predicate: #Predicate { $0.id == dto.id }
                )

                let alreadyExists = (try? modelContext.fetch(descriptor))?.isEmpty == false

                guard !alreadyExists else {
                    continue
                }

                let document = DocumentItem(name: dto.name)

                document.id = dto.id
                document.documentTypeRaw = dto.documentTypeRaw
                document.documentNumber = dto.documentNumber
                document.issueDate = dto.issueDate
                document.expiryDate = dto.expiryDate
                document.notes = dto.notes
                document.storageLocation = dto.storageLocation
                document.notificationEnabled = dto.notificationEnabled
                document.notificationDaysBefore = dto.notificationDaysBefore
                document.createdAt = dto.createdAt

                modelContext.insert(document)
            }
        }

        if restoreDocuments && !archive.documentAssets.isEmpty {

            var restoredDocumentAssetKeys = Set<String>()

            for dto in archive.documentAssets {

                let relativePath = dto.relativePath
                    .trimmingCharacters(in: .whitespacesAndNewlines)

                guard !relativePath.isEmpty else {
                    continue
                }

                let key = "\(dto.documentID.uuidString)|\(relativePath)"

                if restoredDocumentAssetKeys.contains(key) {
                    continue
                }

                restoredDocumentAssetKeys.insert(key)

                guard archive.documentFiles[relativePath] != nil else {
                    continue
                }

                let descriptor = FetchDescriptor<DocumentItem>(
                    predicate: #Predicate {
                        $0.id == dto.documentID
                    }
                )

                guard
                    let documents = try? modelContext.fetch(descriptor),
                    let document = documents.first
                else {
                    continue
                }

                let assetAlreadyExists = (document.assets ?? []).contains {
                    $0.relativePath.trimmingCharacters(in: .whitespacesAndNewlines) == relativePath
                }

                guard !assetAlreadyExists else {
                    continue
                }


                let asset = DocumentAsset(
                    relativePath: relativePath,
                    kind: DocumentAssetKind(rawValue: dto.kindRaw) ?? .other,
                    pageIndex: dto.pageIndex,
                    fileSize: dto.fileSize,
                    createdAt: dto.createdAt
                )

                asset.document = document

                modelContext.insert(asset)
            }
        }
        
        
        if restoreTripLists && !archive.tripLists.isEmpty {
            for tripDTO in archive.tripLists {

                let descriptor = FetchDescriptor<TripList>(
                    predicate: #Predicate { $0.id == tripDTO.id }
                )

                let alreadyExists = (try? modelContext.fetch(descriptor))?.isEmpty == false

                guard !alreadyExists else {
                    continue
                }

                let restoredChecklistType =
                    tripDTO.checklistType
                    ?? (tripDTO.systemTemplate.isEmpty ? "custom" : "travel")

                let trip = TripList(
                    name: tripDTO.name,
                    icon: tripDTO.icon,
                    colorHex: tripDTO.colorHex,
                    notes: tripDTO.notes,
                    systemTemplate: tripDTO.systemTemplate,
                    checklistType: restoredChecklistType,
                    sortOrder: tripDTO.sortOrder,
                    sections: tripDTO.sections
                )

                trip.id = tripDTO.id
                trip.createdAt = tripDTO.createdAt
                trip.updatedAt = tripDTO.updatedAt

                modelContext.insert(trip)
            }
        }

        if restoreWalletCards {
            for cardDTO in archive.loyaltyCards {

                let descriptor = FetchDescriptor<LoyaltyCard>(
                    predicate: #Predicate { $0.id == cardDTO.id }
                )

                let alreadyExists = (try? modelContext.fetch(descriptor))?.isEmpty == false

                guard !alreadyExists else {
                    continue
                }

                let card = LoyaltyCard(
                    id: cardDTO.id,
                    storeName: cardDTO.storeName,
                    cardHolder: cardDTO.cardHolder,
                    barcodeValue: cardDTO.barcodeValue,
                    barcodeFormat: cardDTO.barcodeFormat,
                    itemType: cardDTO.itemType,
                    notes: cardDTO.notes,
                    colorHex: cardDTO.colorHex,
                    createdAt: cardDTO.createdAt
                )
                card.sortOrder = cardDTO.sortOrder

                modelContext.insert(card)

                var restoredAssetPaths = Set<String>()

                for assetDTO in cardDTO.assets {

                    let relativePath = assetDTO.relativePath
                        .trimmingCharacters(in: .whitespacesAndNewlines)

                    guard !relativePath.isEmpty else {
                        continue
                    }

                    guard restoredAssetPaths.insert(relativePath).inserted else {
                        continue
                    }

                    guard let imageData = archive.loyaltyCardLogoFiles[relativePath] else {
                        continue
                    }

                    let asset = WalletAsset(
                        kind: assetDTO.kind,
                        relativePath: relativePath,
                        fileSize: Int64(imageData.count)
                    )

                    asset.card = card

                    if asset.kind == .logo {
                        card.loyaltyLogoRelativePath = relativePath
                    }

                    modelContext.insert(asset)
                }
                
                if cardDTO.assets.isEmpty {

                    let legacyRelativePath = "\(card.id.uuidString).jpg"

                    if let imageData =
                        archive.loyaltyCardLogoFiles[legacyRelativePath] {

                        let result = try WalletAssetStore.save(
                            data: imageData,
                            fileExtension: "jpg"
                        )

                        let asset = WalletAsset(
                            kind: .logo,
                            relativePath: result.relativePath,
                            fileSize: result.fileSize
                        )

                        asset.card = card
                        card.loyaltyLogoRelativePath = asset.relativePath

                        modelContext.insert(asset)
                    }
                }
            }
        }

        if restoreActiveTasks || restoreCompletedTasks {

                for dto in archive.tasks {
                    let isCompleted = dto.isCompleted ?? false

                    guard (isCompleted && restoreCompletedTasks) ||
                          (!isCompleted && restoreActiveTasks) else {
                        continue
                    }

                let descriptor = FetchDescriptor<TodoTask>(
                    predicate: #Predicate { $0.id == dto.id }
                )

                let alreadyExists = (try? modelContext.fetch(descriptor))?.isEmpty == false

                guard !alreadyExists else {
                    continue
                }

                let todo = TodoTask(from: dto)

                // Keep only attachments whose physical file is present
                // in the backup archive.
                let validAttachments = (todo.attachments ?? []).filter { attachment in

                    let relativePath = attachment.relativePath
                        .trimmingCharacters(in: .whitespacesAndNewlines)

                    guard !relativePath.isEmpty else {
                        return false
                    }

                    return archive.attachmentFiles[relativePath] != nil
                }

                todo.attachments = validAttachments

                // Rebuild only valid attachment relationships.
                for attachment in validAttachments {
                    attachment.task = todo
                }

                // Insert task only after its attachment graph has been cleaned.
                modelContext.insert(todo)

                for attachment in validAttachments {
                    modelContext.insert(attachment)
                }
            }
        }

        if restoreVault {

            struct PreparedVaultSecret {
                let encryptedLabel: Data?
                let encryptedValue: Data?
                let sortOrder: Int
            }

            struct PreparedVaultItem {
                let dto: VaultItemTransferObject
                let encryptedPassword: Data?
                let encryptedPIN: Data?
                let secrets: [PreparedVaultSecret]
            }

            var preparedVaultItems: [PreparedVaultItem] = []
            preparedVaultItems.reserveCapacity(archive.vaultItems.count)

            // 1. Prepare and validate the entire backup first.
            for dto in archive.vaultItems {

                guard let backupKey = backupVaultKey,
                      let finalKey = finalVaultKey else {
                    throw VaultCryptoError.invalidData
                }

                let encryptedPassword = try VaultCrypto.reencrypt(
                    dto.encryptedPassword,
                    from: backupKey,
                    to: finalKey
                )

                let encryptedPIN = try VaultCrypto.reencrypt(
                    dto.encryptedPIN,
                    from: backupKey,
                    to: finalKey
                )

                var preparedSecrets: [PreparedVaultSecret] = []
                preparedSecrets.reserveCapacity(dto.secrets.count)

                for dtoSecret in dto.secrets {

                    let encryptedLabel = try VaultCrypto.reencrypt(
                        dtoSecret.encryptedLabel,
                        from: backupKey,
                        to: finalKey
                    )

                    let encryptedValue = try VaultCrypto.reencrypt(
                        dtoSecret.encryptedValue,
                        from: backupKey,
                        to: finalKey
                    )

                    preparedSecrets.append(
                        PreparedVaultSecret(
                            encryptedLabel: encryptedLabel,
                            encryptedValue: encryptedValue,
                            sortOrder: dtoSecret.sortOrder
                        )
                    )
                }

                preparedVaultItems.append(
                    PreparedVaultItem(
                        dto: dto,
                        encryptedPassword: encryptedPassword,
                        encryptedPIN: encryptedPIN,
                        secrets: preparedSecrets
                    )
                )
            }

            // 2. Merge backup Vault into the existing local Vault.
            // Local items not present in the backup are preserved.

            for prepared in preparedVaultItems {

                let dto = prepared.dto

                let existingItems = try modelContext.fetch(
                    FetchDescriptor<VaultItem>(
                        predicate: #Predicate {
                            $0.syncIdentifier == dto.syncIdentifier
                        }
                    )
                )

                let item: VaultItem

                if let existing = existingItems.first {
                    item = existing
                } else {
                    item = VaultItem(
                        title: dto.title,
                        category: dto.category
                    )

                    item.id = dto.id
                    item.syncIdentifier = dto.syncIdentifier
                }

                item.version = dto.version
                item.title = dto.title
                item.category = dto.category
                item.favorite = dto.favorite
                item.tags = dto.tags
                item.sortOrder = dto.sortOrder
                item.icon = dto.icon
                item.color = dto.color
                item.username = dto.username
                item.email = dto.email
                item.website = dto.website
                item.notes = dto.notes
                item.encryptedPassword = prepared.encryptedPassword
                item.encryptedPIN = prepared.encryptedPIN
                item.createdAt = dto.createdAt
                item.modifiedAt = dto.modifiedAt
                item.passwordUpdatedAt = dto.passwordUpdatedAt
                item.passwordExpiresAt = dto.passwordExpiresAt
                item.lastViewedAt = dto.lastViewedAt
                item.lastCopiedAt = dto.lastCopiedAt
                item.deletedAt = dto.deletedAt
                item.requireBiometricEveryTime = dto.requireBiometricEveryTime

                // Replace only the secrets belonging to this restored item.
                let existingSecrets = item.secrets ?? []

                for secret in existingSecrets {
                    modelContext.delete(secret)
                }

                item.secrets = []

                for preparedSecret in prepared.secrets {

                    let secret = VaultSecret(
                        encryptedLabel: preparedSecret.encryptedLabel,
                        encryptedValue: preparedSecret.encryptedValue,
                        sortOrder: preparedSecret.sortOrder
                    )

                    modelContext.insert(secret)

                    secret.vaultItem = item
                    item.secrets?.append(secret)
                }

                modelContext.insert(item)
            }
        }

        if restoreSettings && !archive.settings.isEmpty {

            var restoredSettings: [String: Any] = [:]

            for (key, data) in archive.settings {

                guard
                    let object = try? JSONSerialization.jsonObject(with: data),
                    let dictionary = object as? [String: Any],
                    let value = dictionary["value"]
                else {
                    continue
                }

                restoredSettings[key] = value
            }

            await MainActor.run {
                AppSettings.shared.importSettings(from: restoredSettings)
            }
        }

        modelContext.processPendingChanges()

        try modelContext.save()

        if let vaultKeyToInstall {
            try VaultCrypto.installKey(vaultKeyToInstall)
        }

        try await PersistenceOperationCoordinator.shared.waitForSettlement(
            requireExport: Persistence.hasICloudIdentity
        )

        NotificationCenter.default.post(
            name: .taskDidChange,
            object: nil
        )
        
    }
}

private struct BackupFileDocument: FileDocument {

    static var readableContentTypes: [UTType] {
        [.json]
    }

    let fileURL: URL

    init(fileURL: URL) {
        self.fileURL = fileURL
    }

    init(configuration: ReadConfiguration) throws {
        throw CocoaError(.fileReadUnknown)
    }

    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        try FileWrapper(url: fileURL)
    }
}


