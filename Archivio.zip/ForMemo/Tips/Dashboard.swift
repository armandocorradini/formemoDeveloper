import SwiftUI
import SwiftData
import os

struct Dashboard: View {
    @Environment(AppSettings.self) private var settings
    @Environment(\.colorScheme) private var colorScheme
    @Environment(\.modelContext) private var modelContext
    @State private var selectedTask: TodoTask?
    @State private var selectedTrip: TripList?
    @State private var selectedDocument: DocumentItem?
    @State private var selectedLoyaltyCard: LoyaltyCard?
    @State private var selectedWeatherDate: Date?
    @State private var selectedNote: Note?
    @State private var creationSheet: DashboardCreationSheet?
    @State private var draftTask: TodoTask?
    
    @State private var recentWalletLogos: [String: Data] = [:]
    @State private var dashboardContinueItems: [ContinueItem] = []
    
    @State private var recoveryResult: AttachmentRecoveryResult?
    @State private var showRecoveryAlert = false
    
    @State private var recoveryCheck: AssetRecoveryCoordinator.RecoveryCheckResult?
    @State private var showRecoveryConfirmation = false
    
    @State private var showNoRecoveryNeededAlert = false
    
    @State private var dashboardTodayTasks: [TodoTask] = []
    @State private var dashboardTodayTasksCount = 0
    @State private var dashboardTomorrowTasks: [TodoTask] = []
    @State private var dashboardTomorrowTasksCount = 0
    
    
    private let weatherManager = WeatherManager.shared
    
    private enum DashboardCreationSheet: String, Identifiable {
        case checklist
        case note
        case document
        case wallet

        var id: String { rawValue }
    }

    private enum ContinueDestination {
        case trip(TripList)
        case document(DocumentItem)
        case loyaltyCard(LoyaltyCard)
        case note(Note)
    }
    
    private struct ContinueItem: Identifiable {
        let id: String
        let title: String
        let type: String
        let systemImage: String?
        let logoRelativePath: String?
        let lastOpenedAt: Date
        let destination: ContinueDestination
    }
    
    
    @MainActor
    private func refreshContinueItems() {
        var tripDescriptor = FetchDescriptor<TripList>(
            predicate: #Predicate<TripList> {
                $0.lastOpenedAt != nil
            },
            sortBy: [
                SortDescriptor(\TripList.lastOpenedAt, order: .reverse)
            ]
        )
        
        tripDescriptor.fetchLimit = 3
        
        var documentDescriptor = FetchDescriptor<DocumentItem>(
            predicate: #Predicate<DocumentItem> {
                $0.lastOpenedAt != nil
            },
            sortBy: [
                SortDescriptor(\DocumentItem.lastOpenedAt, order: .reverse)
            ]
        )
        
        documentDescriptor.fetchLimit = 3
        
        var cardDescriptor = FetchDescriptor<LoyaltyCard>(
            predicate: #Predicate<LoyaltyCard> {
                $0.lastOpenedAt != nil
            },
            sortBy: [
                SortDescriptor(\LoyaltyCard.lastOpenedAt, order: .reverse)
            ]
        )
        
        cardDescriptor.fetchLimit = 3
        
        var noteDescriptor = FetchDescriptor<Note>(
            predicate: #Predicate<Note> {
                $0.lastOpenedAt != nil
            },
            sortBy: [
                SortDescriptor(\Note.lastOpenedAt, order: .reverse)
            ]
        )
        
        noteDescriptor.fetchLimit = 3
        
        do {
            let trips = try modelContext.fetch(tripDescriptor)
            let documents = try modelContext.fetch(documentDescriptor)
            let loyaltyCards = try modelContext.fetch(cardDescriptor)
            let notes = try modelContext.fetch(noteDescriptor)
            
            let tripItems: [ContinueItem] = trips.compactMap { trip in
                guard let lastOpenedAt = trip.lastOpenedAt else {
                    return nil
                }
                
                return ContinueItem(
                    id: "trip-\(trip.id)",
                    title: trip.name,
                    type: String(localized: "Checklists"),
                    systemImage: trip.icon,
                    logoRelativePath: nil,
                    lastOpenedAt: lastOpenedAt,
                    destination: .trip(trip)
                )
            }
            
            let documentItems: [ContinueItem] = documents.compactMap { document in
                guard let lastOpenedAt = document.lastOpenedAt else {
                    return nil
                }
                
                return ContinueItem(
                    id: "document-\(document.id)",
                    title: document.name,
                    type: String(localized: "Documents"),
                    systemImage: document.documentType.systemImage,
                    logoRelativePath: nil,
                    lastOpenedAt: lastOpenedAt,
                    destination: .document(document)
                )
            }
            
            let cardItems: [ContinueItem] = loyaltyCards.compactMap { card in
                guard let lastOpenedAt = card.lastOpenedAt else {
                    return nil
                }
                
                return ContinueItem(
                    id: "card-\(card.id)",
                    title: card.storeName,
                    type: String(localized: "Wallet"),
                    systemImage: card.itemType == "ticket"
                    ? "ticket.fill"
                    : "creditcard",
                    logoRelativePath:
                        card.logoAsset?.relativePath
                    ?? card.loyaltyLogoRelativePath,
                    lastOpenedAt: lastOpenedAt,
                    destination: .loyaltyCard(card)
                )
            }
            
            let noteItems: [ContinueItem] = notes.compactMap { note in
                guard let lastOpenedAt = note.lastOpenedAt else {
                    return nil
                }
                
                return ContinueItem(
                    id: "note-\(note.id)",
                    title: note.title.isEmpty
                    ? String(localized: "Untitled")
                    : note.title,
                    type: String(localized: "Notes"),
                    systemImage: "note.text",
                    logoRelativePath: nil,
                    lastOpenedAt: lastOpenedAt,
                    destination: .note(note)
                )
            }
            
            dashboardContinueItems = Array(
                (tripItems + documentItems + cardItems + noteItems)
                    .sorted { $0.lastOpenedAt > $1.lastOpenedAt }
                    .prefix(3)
            )
            
        } catch {
            AppLogger.persistence.error(
                "Dashboard recent items fetch failed: \(error.localizedDescription)"
            )
            
            dashboardContinueItems = []
        }
    }
    
    private var tomorrowScheduledTasksText: String {
        String(localized: "^[\(dashboardTomorrowTasksCount) tasks scheduled](inflect: true)")
    }

    private var todayTasksDescription: String {
        if dashboardTodayTasksCount == 1 {
            return String(localized: "task to complete")
        }
        return String(localized: "tasks to complete")
    }

    private var todayStart: Date {
        Calendar.current.startOfDay(for: .now)
    }
    
    private var tomorrowStart: Date {
        Calendar.current.date(
            byAdding: .day,
            value: 1,
            to: todayStart
        ) ?? todayStart
    }
    
    private var dayAfterTomorrowStart: Date {
        Calendar.current.date(
            byAdding: .day,
            value: 2,
            to: todayStart
        ) ?? tomorrowStart
    }
    
    @MainActor
    private func fetchDashboardTasks(
        from start: Date,
        to end: Date
    ) -> [TodoTask] {
        var descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.deadLine != nil &&
                $0.deadLine! >= start &&
                $0.deadLine! < end
            },
            sortBy: [
                SortDescriptor(\TodoTask.deadLine, order: .forward),
                SortDescriptor(\TodoTask.id, order: .forward)
            ]
        )
        
        descriptor.fetchLimit = 100
        
        do {
            return try modelContext.fetch(descriptor)
        } catch {
            AppLogger.persistence.error(
                "Dashboard task fetch failed: \(error.localizedDescription)"
            )
            return []
        }
    }
    
    @MainActor
    private func refreshTodayDashboard() {
        let start = todayStart
        let end = tomorrowStart
        
        dashboardTodayTasks = fetchDashboardTasks(
            from: start,
            to: end
        )
        
        dashboardTodayTasksCount = countDashboardTasks(
            from: start,
            to: end
        )
    }
    
    
    @MainActor
    private func refreshTomorrowDashboard() {
        let start = tomorrowStart
        let end = dayAfterTomorrowStart
        
        dashboardTomorrowTasks = fetchDashboardTasks(
            from: start,
            to: end
        )
        
        dashboardTomorrowTasksCount = countDashboardTasks(
            from: start,
            to: end
        )
    }
    @MainActor
    private func countDashboardTasks(
        from start: Date,
        to end: Date
    ) -> Int {
        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.deadLine != nil &&
                $0.deadLine! >= start &&
                $0.deadLine! < end
            }
        )
        
        do {
            return try modelContext.fetchCount(descriptor)
        } catch {
            AppLogger.persistence.error(
                "Dashboard task count failed: \(error.localizedDescription)"
            )
            return 0
        }
    }
    
    
    @MainActor
    private func fetchOverduePreviousDaysCount() -> Int {
        let startOfToday = todayStart
        
        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.deadLine != nil &&
                $0.deadLine! < startOfToday
            }
        )
        
        do {
            return try modelContext.fetchCount(descriptor)
        } catch {
            AppLogger.persistence.error(
                "Dashboard overdue count failed: \(error.localizedDescription)"
            )
            return 0
        }
    }
    
    private var overduePreviousDaysCount: Int {
        fetchOverduePreviousDaysCount()
    }
    
    private func hide(_ item: ContinueItem) {
        // Remove the card from the visible dashboard immediately.
        // Updating lastOpenedAt alone does not refresh this in-memory array.
        dashboardContinueItems.removeAll { $0.id == item.id }
        
        switch item.destination {
        case .trip(let trip):
            trip.lastOpenedAt = nil
        case .document(let document):
            document.lastOpenedAt = nil
        case .loyaltyCard(let card):
            card.lastOpenedAt = nil
        case .note(let note):
            note.lastOpenedAt = nil
        }
        
        do {
            try modelContext.save()
        } catch {
            AppLogger.persistence.error(
                "Dashboard recent item hide failed: \\(error.localizedDescription)"
            )
            refreshContinueItems()
        }
    }
    
    private var todayWeatherIcon: some View {
        let symbol = weatherManager.representativeSymbol(for: .now)
        let saturation: Double = colorScheme == .light ? 1.25 : 1.0
        let brightness: Double = colorScheme == .light ? -0.2 : 0.0

        return Image(systemName: symbol)
            .symbolRenderingMode(.multicolor)
            .saturation(saturation)
            .brightness(brightness)
            .font(.title.weight(.medium))
    }

    var body: some View {
        ZStack {
            AppGlassBackground()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    
                    // MARK: - Oggi
                    
                    Button {
                        if settings.showTasksTab {
                            NotificationCenter.default.post(
                                name: Notification.Name("DashboardOpenList"),
                                object: nil
                            )
                        }
                    } label: {
                        VStack(alignment: .leading, spacing: 0) {
                            
                            // Header Oggi
                            HStack(alignment: .top) {
                                Text("Today")
                                    .font(.title.bold())
                                
                                Spacer()
                                
                                if settings.showWeatherForecast {
                                    Group {
                                        if let weather = weatherManager.weather(for: Date()) {
                                            VStack(alignment: .trailing, spacing: 4) {
                                                Button {
                                                    selectedWeatherDate = .now
                                                } label: {
                                                    todayWeatherIcon
                                                }
                                                .buttonStyle(.plain)
                                                
                                                HStack(spacing: 4) {
                                                    Text("\(weather.minTemperature)°")
                                                        .foregroundStyle(
                                                            weather.minTemperature >= 35 ? .red :
                                                                weather.minTemperature >= 30 ? .orange :
                                                                weather.minTemperature <= 0
                                                            ? Color(
                                                                red: 0.65,
                                                                green: 0.88,
                                                                blue: 1.00
                                                            )
                                                            : .primary.opacity(0.75)
                                                        )
                                                    
                                                    Text("/")
                                                        .foregroundStyle(.secondary)
                                                    
                                                    Text("\(weather.maxTemperature)°")
                                                        .foregroundStyle(
                                                            weather.maxTemperature >= 35 ? .red :
                                                                weather.maxTemperature >= 30 ? .orange :
                                                                weather.maxTemperature <= 0
                                                            ? Color(
                                                                red: 0.65,
                                                                green: 0.88,
                                                                blue: 1.00
                                                            )
                                                            : .primary
                                                        )
                                                }
                                                .font(.caption)
                                            }
                                        } else {
                                            Color.clear
                                        }
                                    }
                                    .frame(width: 60, height: 48, alignment: .topTrailing)
                                }
                            }
                            .foregroundStyle(.primary)
                            
                            .padding(.bottom,2)
                            
                            // Numero attività
                            HStack(alignment: .firstTextBaseline, spacing: 8) {
                                Text("\(dashboardTodayTasksCount)")
                                    .font(.system(size: 40, weight: .bold, design: .rounded))
                                    .foregroundStyle(.blue)
                                
                                Text(todayTasksDescription)
                                    .font(.title3)
                                .foregroundStyle(.primary.opacity(0.9))
                            }
                            .padding(.top, 2)
                            
                            // Attività
                            if !dashboardTodayTasks.isEmpty {
                                VStack(alignment: .leading, spacing: 6) {
                                    ForEach(
                                        dashboardTodayTasks,
                                        id: \.persistentModelID
                                    ) { task in
                                        dashboardTaskRow(task)
                                    }
                                }
                                .padding(.top, 4)
                            }
                            
                            if overduePreviousDaysCount > 0 {
                                Text(
                                    "\(overduePreviousDaysCount) overdue from previous days"
                                )
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                                .padding(.top, 6)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(20)
                        .background(
                            RoundedRectangle(
                                cornerRadius: 18,
                                style: .continuous
                            )
                            .fill(.regularMaterial)
                        )
                        .overlay {
                            RoundedRectangle(
                                cornerRadius: 18,
                                style: .continuous
                            )
                            .stroke(
                                .white.opacity(0.10),
                                lineWidth: 1
                            )
                        }
                    }
                    .buttonStyle(.plain)
                    
                    
                    // MARK: - Domani
                    
                    if settings.showDashboardTomorrow &&
                        dashboardTomorrowTasksCount > 0 {
                        
                        Button {
                            if settings.showTasksTab {
                                NotificationCenter.default.post(
                                    name: Notification.Name("DashboardOpenList"),
                                    object: nil
                                )
                            }
                        } label: {
                            VStack(alignment: .leading, spacing: 10) {
                                
                                HStack(alignment: .firstTextBaseline) {
                                    Text("Tomorrow")
                                        .font(.title3.weight(.semibold))
                                    
                                    Spacer()
                                    
                                    if settings.showWeatherForecast,
                                       let tomorrowDate = Calendar.current.date(
                                        byAdding: .day,
                                        value: 1,
                                        to: Date()
                                       ),
                                       let tomorrowWeather = weatherManager.weather(
                                        for: tomorrowDate
                                       ) {
                                        
                                        HStack(spacing: 5) {
                                            let tomorrowSymbol = weatherManager.representativeSymbol(
                                                for: tomorrowDate
                                            )
                                            Image(systemName: tomorrowSymbol)
                                            .symbolRenderingMode(.multicolor)
                                            .font(.subheadline)
                                            
                                            Text("\(tomorrowWeather.minTemperature)°")
                                                .foregroundStyle(.secondary)
                                            
                                            Text("/")
                                                .foregroundStyle(.secondary)
                                            
                                            Text("\(tomorrowWeather.maxTemperature)°")
                                        }
                                        .font(.caption)
                                    }
                                }
                                
                                Text(tomorrowScheduledTasksText)
                                    .font(.subheadline)
                                .foregroundStyle(.secondary)
                                
                                if !dashboardTomorrowTasks.isEmpty {
                                    VStack(alignment: .leading, spacing: 6) {
                                        ForEach(
                                            dashboardTomorrowTasks,
                                            id: \.persistentModelID
                                        ) { task in
                                            dashboardTaskRow(task)
                                        }
                                    }
                                }
                            }
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .padding(.horizontal, 4)
                        }
                        .buttonStyle(.plain)
                    }
                    
                    Divider()
                        .overlay(.white.opacity(0.3))
                    // MARK: - Recenti
                    
                    if settings.showDashboardContinue &&
                        !dashboardContinueItems.isEmpty {
                        
                        VStack(alignment: .leading, spacing: 12) {
                            
                            HStack {
                                Label(
                                    "Recent",
                                    systemImage:
                                        "clock.arrow.trianglehead.clockwise.rotate.90.path.dotted"
                                )
                                .font(.headline)
                            }
                            
                            LazyVGrid(
                                columns: Array(
                                    repeating: GridItem(.flexible(), spacing: 8),
                                    count: min(dashboardContinueItems.count, 3)
                                ),
                                spacing: 8
                            ) {
                                ForEach(dashboardContinueItems) { item in
                                    
                                    dashboardContinueItemView(item)
                                }
                            }
                        }
                    }
                }
                .padding()
            }
            .refreshable {
                refreshContinueItems()
                refreshTodayDashboard()
                refreshTomorrowDashboard()
                await weatherManager.refreshIfNeeded()
                TaskWidgetSnapshotStore.scheduleRefresh(from: modelContext)
            }
            .scrollContentBackground(.hidden)
            .scrollEdgeEffectHidden(true, for: .top)
            .background(Color.clear)
        }
        .sheet(item: $draftTask) { task in
            NewTaskSheetView(draftTask: task)
        }
        .alert(
            "Attachment Recovery",
            isPresented: $showNoRecoveryNeededAlert
        ) {
            
            Button("OK") { }
            
        } message: {
            
            Text(
                String(
                    localized:
                        "No duplicate asset folders were found."
                )
            )
            
        }
        .alert(
            "Attachment Recovery",
            isPresented: $showRecoveryConfirmation,
            presenting: recoveryCheck
        ) { check in
            
            Button(
                String(localized: "Repair")
            ) {
                
                recoveryResult = AssetRecoveryCoordinator.repairAll(context: modelContext)
                
                showRecoveryAlert = true
                
            }
            
            Button(
                String(localized: "Cancel"),
                role: .cancel
            ) {
            }
            
        } message: { check in
            
            Text(
                """
                \(check.duplicateFolders.count) duplicate asset folder(s) detected.
                
                Automatic recovery has been suspended because Asset Recovery Diagnostics is enabled.
                
                Press Repair to merge the folders.
                """
            )
            
        }
        
        .alert(
            "Attachment Recovery",
            isPresented: $showRecoveryAlert
        ) {
            
            Button("OK") { }
            
        } message: {
            
            if let result = recoveryResult {
                
                Text("""
                Recovery folders: \(result.folders)
                
                Copied: \(result.copied)
                Skipped: \(result.skipped)
                Errors: \(result.errors)
                """)
                
            }
        }
        .contentMargins(.bottom, 70, for: .scrollContent)
        .containerBackground(.clear, for: .navigation)
        .navigationTitle("Dashboard")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            
            if DiagnosticsOptions.assetRecoveryDiagnostics {
                ToolbarItem(placement: .topBarTrailing) {
                    
                    Button {
                        
                        let result = AssetRecoveryCoordinator.checkIfNeeded()
                        
                        guard result.needsRepair else {
                            
                            showNoRecoveryNeededAlert = true
                            return
                            
                        }
                        
                        recoveryCheck = result
                        showRecoveryConfirmation = true
                        
                    } label: {
                        
                        Image(systemName: "wrench.and.screwdriver")
                        
                    }
                    
                }
            }
            ToolbarItem(placement: .topBarLeading) {
                Menu {
                    Toggle("Show Tomorrow", isOn: Bindable(settings).showDashboardTomorrow)
                    Toggle("Show Recent", isOn: Bindable(settings).showDashboardContinue)
                } label: {
                    Image(systemName: "line.3.horizontal.decrease.circle")
                }
            }
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 8) {
                    NavigationLink {
                        OverviewView()
                    } label: {
                        Image(systemName: "line.3.horizontal.button.angledtop.vertical.right")
                    }

                    Menu {
                        Button {
                            draftTask = TodoTask()
                        } label: {
                            Label(String(localized: "Tasks"), systemImage: "checklist")
                        }

                        Button {
                            creationSheet = .checklist
                        } label: {
                            Label("Checklist", systemImage: "list.bullet.clipboard")
                        }

                        Button {
                            creationSheet = .note
                        } label: {
                            Label(String(localized: "Note"), systemImage: "note.text")
                        }

                        Button {
                            creationSheet = .document
                        } label: {
                            Label(String(localized: "Document"), systemImage: "doc.text")
                        }

                        Button {
                            creationSheet = .wallet
                        } label: {
                            Label("Cards & Tickets", systemImage: "wallet.bifold")
                        }
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .foregroundStyle(.green)
                            .font(.system(size: 22))
                            .frame(width: 36, height: 36)
                            .contentShape(Rectangle())
                    }
                    .accessibilityLabel(String(localized: "Add"))
                }
            }
            
        }
        .sheet(item: $creationSheet, onDismiss: {
            refreshContinueItems()
        }) { destination in
            switch destination {

            case .checklist:
                ChecklistListView(
                    openCreationOnAppear: true,
                    onCreated: { _ in
                        refreshContinueItems()
                    }
                )
            case .note:
                NavigationStack {
                    NoteEditorView(note: Note(), isNew: true)
                }
            case .document:
                NavigationStack {
                    DocumentDetailView(document: DocumentItem(name: ""))
                }
            case .wallet:
                AddLoyaltyCardView(onCreated: { _ in
                    refreshContinueItems()
                })
            }
        }
        .navigationDestination(item: $selectedTask) { task in
            TaskDetailView(task: task)
        }
        .navigationDestination(item: $selectedTrip) { trip in
            ChecklistView(category: trip)
        }
        .navigationDestination(item: $selectedDocument) { document in
            DocumentDetailView(document: document)
        }
        .navigationDestination(item: $selectedLoyaltyCard) { card in
            LoyaltyCardDetailView(card: card)
        }
        .navigationDestination(item: $selectedNote) { note in
            NoteEditorView(note: note)
        }
        .navigationDestination(item: $selectedWeatherDate) {
            date in
            WeatherDayView(
                date: date,
                showsCloseButton: false,
                cameFromForecast: false
            )
        }
        .onAppear {
            refreshContinueItems()
            refreshTodayDashboard()
            refreshTomorrowDashboard()
        }
        
        .task {
            try? await Task.sleep(for: .seconds(2))
            guard !Task.isCancelled else { return }
            await weatherManager.refreshIfNeeded()
            TaskWidgetSnapshotStore.scheduleRefresh(from: modelContext)
        }
        .onReceive(
            NotificationCenter.default.publisher(for: .taskDidChange)
        ) { _ in
            refreshTodayDashboard()
            refreshTomorrowDashboard()
        }
        .onReceive(
            NotificationCenter.default.publisher(
                for: Notification.Name("DashboardReset")
            )
        ) { _ in
            selectedTask = nil
            selectedTrip = nil
            selectedDocument = nil
            selectedLoyaltyCard = nil
            selectedWeatherDate = nil
        }
    }
    
    
    
    @ViewBuilder
    private func dashboardContinueItemView(_ item: ContinueItem) -> some View {
                                    switch item.destination {
                                        
                                    case .trip(let trip):
                                        Button {
                                            selectedTrip = trip
                                        } label: {
                                            sectionCard(
                                                title: item.title,
                                                type: item.type,
                                                systemImage: item.systemImage,
                                                logoData: nil,
                                                isCompleted: isTripComplete(trip),
                                                remainingItems:
                                                    remainingTripItems(for: trip),
                                                iconColor: dashboardTripIconColors(for: trip.icon).0,
                                                iconSecondaryColor: dashboardTripIconColors(for: trip.icon).1                                          )
                                        }
                                        .buttonStyle(.plain)
                                        .contextMenu {
                                            Button {
                                                hide(item)
                                            } label: {
                                                Label(
                                                    "Hide",
                                                    systemImage: "eye.slash"
                                                )
                                            }
                                        }
                                        
                                    case .note(let note):
                                        Button {
                                            selectedNote = note
                                        } label: {
                                            sectionCard(
                                                title: item.title,
                                                type: item.type,
                                                systemImage: item.systemImage,
                                                logoData: nil,
                                                iconColor: .primary,
                                                iconSecondaryColor: note.color != nil ? noteColor(for: note.color) : nil ?? Color(uiColor: .systemBackground)
                                            )
                                        }
                                        .buttonStyle(.plain)
                                        .contextMenu {
                                            Button {
                                                hide(item)
                                            } label: {
                                                Label(
                                                    "Hide",
                                                    systemImage: "eye.slash"
                                                )
                                            }
                                        }
                                        
                                    case .document(let document):
                                        Button {
                                            selectedDocument = document
                                        } label: {
                                            let documentIconColors = dashboardDocumentIconColors(for: document)
                                            
                                            sectionCard(
                                                title: item.title,
                                                type: item.type,
                                                systemImage: item.systemImage,
                                                logoData: nil,
                                                iconColor: documentIconColors.0,
                                                iconSecondaryColor: documentIconColors.1
                                            )
                                        }
                                        .buttonStyle(.plain)
                                        .contextMenu {
                                            Button {
                                                hide(item)
                                            } label: {
                                                Label(
                                                    "Hide",
                                                    systemImage: "eye.slash"
                                                )
                                            }
                                        }
                                        
                                    case .loyaltyCard(let card):
                                        Button {
                                            selectedLoyaltyCard = card
                                        } label: {
                                            sectionCard(
                                                title: item.title,
                                                type: item.type,
                                                systemImage: item.systemImage,
                                                logoData: recentWalletLogos[item.id],
                                                iconColor: .primary,
                                                iconBackgroundColor: Color(hex: card.colorHex ?? "#3B82F6") ?? .blue
                                            )
                                        }
                                        .buttonStyle(.plain)
                                        .task(id: item.id) {
                                            guard let relativePath = item.logoRelativePath else {
                                                return
                                            }
                                            
                                            let data = WalletAssetStore.loadData(
                                                relativePath: relativePath
                                            )
                                            
                                            guard !Task.isCancelled, let data else {
                                                return
                                            }
                                            
                                            recentWalletLogos[item.id] = data
                                        }
                                        .contextMenu {
                                            Button {
                                                hide(item)
                                            } label: {
                                                Label(
                                                    "Hide",
                                                    systemImage: "eye.slash"
                                                )
                                            }
                                        }                                    }
    }

    @ViewBuilder
    private func dashboardTaskRow(_ task: TodoTask) -> some View {
        let isOverdue = (task.deadLine ?? .now) < .now
        
        Button {
            selectedTask = task
        } label: {
            HStack(spacing: 8) {
                
                if settings.highlightEnabled,
                   task.priority == .critical {
                    RoundedRectangle(
                        cornerRadius: TaskRowTheme.highlightCornerRadius
                    )
                    .fill(
                        Color(hex: settings.highlightColorHex) ?? .red
                    )
                    .frame(
                        width: TaskRowMetrics.highlightBarWidth,
                        height: TaskRowMetrics.highlightBarHeight - 12
                    )
                } else {
                    Color.clear
                        .frame(
                            width: TaskRowMetrics.highlightBarWidth,
                            height: TaskRowMetrics.highlightBarHeight - 12
                        )
                }
                
                Image(
                    systemName: task.mainTag?.mainIcon ?? task.status.icon
                )
                .symbolRenderingMode(
                    settings.iconStyle == .polychrome && task.mainTag != nil
                    ? .palette
                    : .monochrome
                )
                .foregroundStyle(
                    settings.iconStyle == .polychrome
                    ? task.iconColor
                    : .primary,
                    .primary
                )
                .opacity(0.9)
                .frame(width: 18)
                
                if let deadline = task.deadLine {
                    Text(
                        deadline.formatted(
                            .dateTime
                                .hour()
                                .minute()
                        )
                    )
                    .monospacedDigit()
                    .foregroundStyle(.secondary)
                }
                
                Text(task.title)
                    .lineLimit(1)
                    .foregroundStyle(.secondary)
                    .overlay(alignment: .bottomLeading) {
                        if isOverdue {
                            Rectangle()
                                .fill(.red)
                                .frame(height: 1.5)
                                .offset(y: 2)
                        }
                    }
                
                if task.recurrenceRule != nil && task.occurrenceIndex == nil {
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.caption)
                        .foregroundStyle(.red)
                } else if task.occurrenceIndex != nil {
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .font(.caption)
                        .foregroundStyle(.blue)
                }
            }
            .font(.subheadline)
        }
        .buttonStyle(.plain)
    }
    
    private func noteColor(for value: String?) -> Color? {
        switch value {
        case "red":
                .red
        case "orange":
                .orange
        case "yellow":
                .yellow
        case "green":
                .green
        case "blue":
                .blue
        case "purple":
                .purple
        case "pink":
                .pink
        default:
            nil
        }
    }
    
    private func dashboardTripIconColors(for icon: String) -> (Color, Color) {
        switch icon {
        case "airplane.path.dotted": return (.blue, .primary)
        case "car.2": return (.mint, .blue)
        case "motorcycle": return (.orange, .red)
        case "bicycle": return (.green, .mint)
        case "tram": return (.indigo, .blue)
        case "ferry": return (.cyan, .blue)
        case "bus": return (.purple, .pink)
        case "sailboat": return (.teal, .cyan)
        case "figure", "figure.hiking": return (.green, .orange)
        case "tent.2": return (.brown, .green)
        case "backpack": return (.green, .brown)
        case "suitcase.rolling.and.suitcase": return (.blue, .cyan)
        case "camera": return (.purple, .pink)
        case "beach.umbrella": return (.yellow, .orange)
        case "snowflake": return (.cyan, .white)
        case "mountain.2": return (.brown, .green)
        case "water.waves": return (.blue, .primary)
        case "drop": return (.teal, .blue)
        case "globe.europe.africa": return (.green, .blue)
        default: return (.blue, .cyan)
        }
    }
    
    private func dashboardDocumentIconColors(for document: DocumentItem) -> (Color, Color) {
        switch document.documentType {
        case .idCard: return (.indigo, .blue)
        case .passport: return (.blue, .cyan)
        case .drivingLicence: return (.orange, .yellow)
        case .healthCard: return (.red, .pink)
        case .carInsurance: return (.green, .mint)
        case .motorbikeInsurance: return (.mint, .blue)
        case .homeInsurance: return (.teal, .green)
        case .lifeInsurance: return (.pink, .red)
        case .medicalCertificate: return (.cyan, .teal)
        case .vaccinationCertificate: return (.green, .mint)
        default: return (.accentColor, .secondary)
        }
    }
    
    @ViewBuilder
    private func sectionCard(
        title: String,
        type: String,
        systemImage: String?,
        logoData: Data?,
        isCompleted: Bool = false,
        remainingItems: Int? = nil,
        iconColor: Color? = nil,
        iconSecondaryColor: Color? = nil,
        iconBackgroundColor: Color? = nil
    ) -> some View {
        
        VStack(alignment: .center, spacing: 0) {
            
            // Categoria
            Text(type)
                .font(.caption.weight(.medium))
                .foregroundStyle(.secondary)
                .tracking(0.5)
                .lineLimit(1)
                .frame(maxWidth: .infinity)
                .frame(height: 18)
            
            Spacer(minLength: 0)
            
            // Immagine / icona
            Group {
                if let logoData,
                   let uiImage = UIImage(data: logoData) {
                    
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 45, height: 45)
                        .clipShape(
                            RoundedRectangle(
                                cornerRadius: 8,
                                style: .continuous
                            )
                        )
                    
                } else if let systemImage {
                    
                    Image(systemName: systemImage)
                        .font(.system(size: 30))
                        .symbolRenderingMode(
                            iconSecondaryColor != nil ? .palette : .monochrome
                        )
                        .foregroundStyle(
                            iconColor ?? .primary,
                            iconSecondaryColor ?? .primary
                        )
                        .frame(width: 45, height: 45)
                }
            }
            .frame(width: 45, height: 45)
            .background(
                iconBackgroundColor ?? .clear,
                in: RoundedRectangle(
                    cornerRadius: 8,
                    style: .continuous
                )
            )
            .offset(y: 6)
            Spacer(minLength: 0)
            
            // Area titolo + dettaglio
            VStack(alignment: .center, spacing: 2) {
                
                if let remainingItems {
                    Text(
                        "\(remainingItems) \(String(localized: "remaining"))"
                    )
                    .font(.caption2)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                }
                // titolo sotto immagine card recenti
                Text(title)
                    .font(.caption2)
                    .foregroundStyle(
                        isCompleted ? .green : .primary
                    )
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .bottom)
            }
            .frame(maxWidth: .infinity)
            .frame(minHeight: 36, alignment: .bottom)
        }
        .frame(maxWidth: .infinity)
        .frame(height: 112)
        .padding(12)
        .background(
            RoundedRectangle(
                cornerRadius: 16,
                style: .continuous
            )
            .fill(.regularMaterial)
        )
        .overlay {
            RoundedRectangle(
                cornerRadius: 16,
                style: .continuous
            )
            .stroke(
                .white.opacity(0.10),
                lineWidth: 1
            )
        }
    }
    
    private func isTripComplete(_ trip: TripList) -> Bool {
        let items = trip.sections.flatMap(\.items)
        return !items.isEmpty && items.allSatisfy(\.isChecked)
    }
    
    private func remainingTripItems(for trip: TripList) -> Int {
        trip.sections.flatMap(\.items).filter { !$0.isChecked }.count
    }
    
    @ViewBuilder
    private func navigationCard(title: String, systemImage: String) -> some View {
        HStack(spacing: 16) {
            Image(systemName: systemImage)
                .font(.title2)
                .foregroundStyle(.primary)
            Text(title)
                .foregroundStyle(.primary)
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 14)
        .padding(.horizontal, 16)
        .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}
