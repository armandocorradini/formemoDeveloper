import SwiftUI
import SwiftData
import os

struct OverviewView: View {

    private struct OverviewFileStats: Sendable {
        var activeAttachmentBytes: Int64 = 0
        var completedAttachmentBytes: Int64 = 0
        var documentAssetBytes: Int64 = 0
        var recentlyDeletedBytes: Int64 = 0
        var usedStorageBytes: Int64 = 0
        var walletAssetBytes: Int64 = 0
    }

    @State private var fileStats = OverviewFileStats()
    
    @Environment(\.modelContext) private var modelContext

    @State private var activeTasksCount = 0
    @State private var overdueTasksCountValue = 0
    
    @State private var recurringTasksCountValue = 0
    @State private var activeWithAttachmentsCountValue = 0
    @State private var activeWithLocationCountValue = 0
    @State private var activeAttachmentsCountValue = 0
    @State private var completedTasksCountValue = 0


    @Query private var documents: [DocumentItem]
    @Query private var documentAssets: [DocumentAsset]
    @Query private var notes: [Note]
    private var activeNotesCount: Int {
        notes.filter { !$0.isArchived }.count
    }

    private var archivedNotesCount: Int {
        notes.filter { $0.isArchived }.count
    }
    
    // 2. Separate le query per evitare filtri in memoria
    @Query(filter: #Predicate<LoyaltyCard> { $0.itemType == "ticket" })
    private var tickets: [LoyaltyCard]

    @Query(filter: #Predicate<LoyaltyCard> { $0.itemType != "ticket" })
    private var cardsOnly: [LoyaltyCard]
    
    @Query
    private var walletAssets: [WalletAsset]
    
    @Query private var trips: [TripList]
    
    @Query(
        filter: #Predicate<VaultItem> {
            $0.deletedAt == nil
        }
    )
    private var activeVaultItems: [VaultItem]

    @Query(
        filter: #Predicate<VaultItem> {
            $0.deletedAt != nil
        }
    )
    private var deletedVaultItems: [VaultItem]
    
    @Query(sort: \DeletedItem.deletedAt, order: .reverse)
    private var deletedItems: [DeletedItem]
    
    
    var recentlyDeletedItemsCount: Int {
        deletedItems.count
    }

    var recentlyDeletedStorage: String {
        formattedSize(bytes: fileStats.recentlyDeletedBytes)
    }

    private var usedStorage: String {
        formattedSize(bytes: fileStats.usedStorageBytes)
    }

    private var activeAttachmentsSize: String {
        formattedSize(bytes: fileStats.activeAttachmentBytes)
    }

    @MainActor
    private func refreshRecurringTasksCount() {
        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.recurrenceRule != nil
            }
        )

        do {
            recurringTasksCountValue = try modelContext.fetchCount(descriptor)
        } catch {
            recurringTasksCountValue = 0
            AppLogger.persistence.error(
                "Overview recurring task count failed: \(error.localizedDescription)"
            )
        }
    }

    @MainActor
    private func refreshActiveWithLocationCount() {
        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.locationName != nil &&
                $0.locationName != ""
            }
        )

        do {
            activeWithLocationCountValue = try modelContext.fetchCount(descriptor)
        } catch {
            activeWithLocationCountValue = 0
            AppLogger.persistence.error(
                "Overview active location task count failed: \(error.localizedDescription)"
            )
        }
    }
    
    @MainActor
    private func refreshActiveAttachmentsCount() {
        let descriptor = FetchDescriptor<TaskAttachment>(
            predicate: #Predicate<TaskAttachment> {
                $0.task?.isCompleted == false
            }
        )

        do {
            let attachments = try modelContext.fetch(descriptor)

            activeAttachmentsCountValue = attachments.count

            activeWithAttachmentsCountValue = Set(
                attachments.compactMap { $0.task?.id }
            ).count

        } catch {
            activeAttachmentsCountValue = 0
            activeWithAttachmentsCountValue = 0

            AppLogger.persistence.error(
                "Overview active attachment count failed: \(error.localizedDescription)"
            )
        }
    }
    
    private func formattedSize(bytes: Int64) -> String {
        ByteCountFormatter.string(
            fromByteCount: bytes,
            countStyle: .file
        )
    }

    private var completedAttachmentsSize: String {
        formattedSize(bytes: fileStats.completedAttachmentBytes)
    }

    private var activeAttachmentBytes: Int64 {
        fileStats.activeAttachmentBytes
    }

    private func refreshFileStats() {
        // Read SwiftData relationships on the current actor, then perform
        // filesystem I/O on a detached utility task. No SwiftData models
        // cross the concurrency boundary.
        
        let activeAttachmentURLs: [URL] = {
            let descriptor = FetchDescriptor<TaskAttachment>(
                predicate: #Predicate<TaskAttachment> {
                    $0.task?.isCompleted == false
                }
            )

            do {
                return try modelContext.fetch(descriptor)
                    .compactMap(\.fileURL)
            } catch {
                AppLogger.persistence.error(
                    "Overview active attachment URL fetch failed: \(error.localizedDescription)"
                )
                return []
            }
        }()
        let completedAttachmentURLs: [URL] = {
            let descriptor = FetchDescriptor<TaskAttachment>(
                predicate: #Predicate<TaskAttachment> {
                    $0.task?.isCompleted == true
                }
            )

            do {
                return try modelContext.fetch(descriptor)
                    .compactMap(\.fileURL)
            } catch {
                AppLogger.persistence.error(
                    "Overview completed attachment fetch failed: \(error.localizedDescription)"
                )
                return []
            }
        }()
        let documentAssetURLs = documentAssets
            .compactMap(\.fileURL)

        let walletAssetRelativePaths = walletAssets
            .map(\.relativePath)
            .filter { !$0.isEmpty }

        let walletAssetsDirectory = WalletAssetStore.assetsDirectory

        let trashDirectories = [
            TaskAttachment.trashDirectory,
            DocumentAssetStore.trashDirectory,
            WalletAssetStore.trashDirectory
        ].compactMap { $0 }

        // Resolve these URLs while still on the main actor.
        // ForMemoStorageManager is main-actor isolated, so it must not be
        // called from the detached filesystem worker.
        let usedStorageDirectories = [
            TaskAttachment.attachmentsDirectory,
            DocumentAssetStore.assetsDirectory,
            WalletAssetStore.assetsDirectory,
            Self.loyaltyCardLogosDirectoryURL()
        ].compactMap { $0 }

        // SwiftData uses the selected local store (App Group on current builds).
        // Count the SQLite store and its WAL/SHM sidecars as persistent ForMemo data.
        let localStoreURL = URL(fileURLWithPath: Persistence.diagnosticsCurrentStoreURL)
        let localStoreURLs = [
            localStoreURL,
            URL(fileURLWithPath: localStoreURL.path + "-wal"),
            URL(fileURLWithPath: localStoreURL.path + "-shm")
        ]

        Task { @MainActor in
            let result = await Task.detached(priority: .utility) {
                Self.calculateFileStats(
                    activeAttachmentURLs: activeAttachmentURLs,
                    completedAttachmentURLs: completedAttachmentURLs,
                    documentAssetURLs: documentAssetURLs,
                    walletAssetRelativePaths: walletAssetRelativePaths,
                    walletAssetsDirectory: walletAssetsDirectory,
                    trashDirectories: trashDirectories,
                    usedStorageDirectories: usedStorageDirectories,
                    localStoreURLs: localStoreURLs
                )
            }.value

            guard !Task.isCancelled else { return }

            fileStats = result

            AppSettings.shared.diagnosticAttachmentFailure =
                activeAttachmentsCountValue > 0 &&
                result.activeAttachmentBytes == 0
        }
    }

    nonisolated private static func loyaltyCardLogosDirectoryURL() -> URL? {
        FileManager.default
            .urls(for: .documentDirectory, in: .userDomainMask)
            .first?
            .appendingPathComponent("LoyaltyCardLogos", isDirectory: true)
    }

    nonisolated private static func calculateFileStats(
        activeAttachmentURLs: [URL],
        completedAttachmentURLs: [URL],
        documentAssetURLs: [URL],
        walletAssetRelativePaths: [String],
        walletAssetsDirectory: URL?,
        trashDirectories: [URL],
        usedStorageDirectories: [URL],
        localStoreURLs: [URL]
    ) -> OverviewFileStats {
        OverviewFileStats(
            activeAttachmentBytes: totalFileSize(for: activeAttachmentURLs),
            completedAttachmentBytes: totalFileSize(for: completedAttachmentURLs),
            documentAssetBytes: totalFileSize(for: documentAssetURLs),
            recentlyDeletedBytes: trashDirectories.reduce(Int64(0)) { total, directory in
                total + folderSize(at: directory)
            },
            usedStorageBytes:
                fileSize(at: localStoreURLs[0])
                + usedStorageDirectories.reduce(Int64(0)) { total, directory in
                    total + regularFileFolderSize(at: directory)
                },
            walletAssetBytes: walletAssetRelativePaths.reduce(Int64(0)) { total, relativePath in
                guard let directory = walletAssetsDirectory else { return total }
                return total + fileSize(at: directory.appendingPathComponent(relativePath))
            }
        )
    }

    nonisolated private static func regularFileFolderSize(at directory: URL) -> Int64 {
        let fm = FileManager.default

        guard let enumerator = fm.enumerator(
            at: directory,
            includingPropertiesForKeys: [
                .isRegularFileKey,
                .fileSizeKey
            ],
            options: [.skipsHiddenFiles]
        ) else {
            return 0
        }

        var total: Int64 = 0

        for case let fileURL as URL in enumerator {
            guard
                let values = try? fileURL.resourceValues(
                    forKeys: [
                        .isRegularFileKey,
                        .fileSizeKey
                    ]
                ),
                values.isRegularFile == true,
                let size = values.fileSize
            else {
                continue
            }

            total += Int64(size)
        }

        return total
    }

    nonisolated private static func fileSize(at url: URL) -> Int64 {
        guard
            let values = try? url.resourceValues(forKeys: [.isRegularFileKey, .fileSizeKey]),
            values.isRegularFile == true,
            let size = values.fileSize
        else {
            return 0
        }

        return Int64(size)
    }

    nonisolated private static func totalFileSize(for urls: [URL]) -> Int64 {
        urls.reduce(Int64(0)) { total, url in
            guard
                let size = try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize
            else {
                return total
            }

            return total + Int64(size)
        }
    }

    nonisolated private static func folderSize(at directory: URL) -> Int64 {
        let fm = FileManager.default

        guard let enumerator = fm.enumerator(
            at: directory,
            includingPropertiesForKeys: [.fileSizeKey],
            options: []
        ) else {
            return 0
        }

        var total: Int64 = 0

        for case let url as URL in enumerator {
            if let size = try? url
                .resourceValues(forKeys: [.fileSizeKey])
                .fileSize {
                total += Int64(size)
            }
        }

        return total
    }

    var activeAttachmentsCount: Int {
        activeAttachmentsCountValue
    }

    var completedAttachmentsCount: Int {
        let descriptor = FetchDescriptor<TaskAttachment>(
            predicate: #Predicate<TaskAttachment> {
                $0.task?.isCompleted == true
            }
        )

        do {
            return try modelContext.fetchCount(descriptor)
        } catch {
            AppLogger.persistence.error(
                "Overview completed attachment count failed: \(error.localizedDescription)"
            )
            return 0
        }
    }
    
    
    var body: some View {
        ZStack {
            AppGlassBackground()
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
//                    storageSection
                    tasksSection
                    documentsSection
                    notesSection
                    walletSection
                    tripsSection
                    recentlyDeletedSection
                    vaultSection
                }
                .padding()
            }
            .scrollContentBackground(.hidden)
            .background(Color.clear)
        }
        .navigationTitle("Overview")
        .navigationBarTitleDisplayMode(.inline)
        .scrollEdgeEffectHidden(true, for: .top)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    refreshActiveTasksCount()
                    refreshCompletedTasksCount()
                    refreshOverdueTasksCount()
                    refreshRecurringTasksCount()
                    refreshActiveWithLocationCount()
                    refreshActiveAttachmentsCount()
                    refreshFileStats()
                } label: {
                    Image(systemName: "arrow.clockwise")
                }
                .accessibilityLabel(String(localized: "Refresh"))
            }
        }
        .contentMargins(.bottom, 70, for: .scrollContent)
        .onAppear {
            refreshActiveTasksCount()
            refreshCompletedTasksCount()
            refreshOverdueTasksCount()
            refreshRecurringTasksCount()
            refreshActiveWithLocationCount()
            refreshActiveAttachmentsCount()
            refreshFileStats()
        }
        .onChange(of: activeAttachmentsCount) { _, _ in
            refreshFileStats()
        }
        .onChange(of: completedAttachmentsCount) { _, _ in
            refreshFileStats()
        }
        .onChange(of: documentAssets.count) { _, _ in
            refreshFileStats()
        }
        .onChange(of: walletAssetSignature) { _, _ in
            refreshFileStats()
        }
        .onChange(of: deletedItems.count) { _, _ in
            refreshFileStats()
        }
    }
}

// MARK: - Proprietà Calcolate (Ottimizzate per performance)
private extension OverviewView {
    
    @MainActor
    private func refreshActiveTasksCount() {
        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted
            }
        )

        do {
            activeTasksCount = try modelContext.fetchCount(descriptor)
        } catch {
            activeTasksCount = 0
            AppLogger.persistence.error(
                "Overview active task count failed: \(error.localizedDescription)"
            )
        }
    }
    
    @MainActor
    private func refreshCompletedTasksCount() {
        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                $0.isCompleted
            }
        )

        do {
            completedTasksCountValue = try modelContext.fetchCount(descriptor)
        } catch {
            completedTasksCountValue = 0
            AppLogger.persistence.error(
                "Overview completed task count failed: \(error.localizedDescription)"
            )
        }
    }
    
    
    @MainActor
    private func refreshOverdueTasksCount() {
        let now = Date()

        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.deadLine != nil &&
                $0.deadLine! < now
            }
        )

        do {
            overdueTasksCountValue = try modelContext.fetchCount(descriptor)
        } catch {
            overdueTasksCountValue = 0
            AppLogger.persistence.error(
                "Overview overdue task count failed: \(error.localizedDescription)"
            )
        }
    }
    
    
    var documentAssetsCount: Int {
        documentAssets.count
    }

    var documentAssetsSize: String {
        formattedSize(bytes: fileStats.documentAssetBytes)
    }
    
    var walletAssetsCount: Int {
       
            walletAssets.filter { $0.kind != .logo }.count
        }
    

    private var walletAssetSignature: String {
        walletAssets
            .map {
                "\($0.id.uuidString)|\($0.relativePath)|\($0.modifiedAt.timeIntervalSinceReferenceDate)"
            }
            .sorted()
            .joined(separator: ";")
    }

    var walletAssetsSize: String {
        formattedSize(bytes: fileStats.walletAssetBytes)
    }
    
    var walletLogosCount: Int {
        walletAssets.filter { $0.kind == .logo }.count
    }

    var walletGalleryImagesCount: Int {
        walletAssets.filter { $0.kind == .gallery }.count
    }


    // Calcolo scadenze centralizzato senza istanziare Date() nei loop
    var activeWithAttachmentsCount: Int {
        activeWithAttachmentsCountValue
    }

    var completedWithAttachmentsCount: Int {
        let descriptor = FetchDescriptor<TaskAttachment>(
            predicate: #Predicate<TaskAttachment> {
                $0.task?.isCompleted == true
            }
        )

        do {
            let attachments = try modelContext.fetch(descriptor)

            return Set(
                attachments.compactMap { $0.task?.id }
            ).count

        } catch {
            AppLogger.persistence.error(
                "Overview completed tasks with attachments count failed: \(error.localizedDescription)"
            )
            return 0
        }
    }

    var expiringDocumentsCount: Int {
        let now = Date()
        guard let limit = Calendar.current.date(byAdding: .day, value: 30, to: now) else { return 0 }
        return documents.filter { document in
            guard let expiry = document.expiryDate else { return false }
            return expiry >= now && expiry <= limit
        }.count
    }

    private func tripItems(for trip: TripList) -> [TripItemData] {
        trip.sections.flatMap(\.items)
    }
    
    // Calcolo dei Trip ottimizzato riducendo le allocazioni di memoria
    var tripsInProgressCount: Int {
        trips.filter { trip in
            let items = tripItems(for: trip)
            guard !items.isEmpty else { return false }
            return items.contains { $0.isChecked } && items.contains { !$0.isChecked }
        }.count
    }

    var tripsCompletedCount: Int {
        trips.filter { trip in
            let items = tripItems(for: trip)
            return !items.isEmpty && items.allSatisfy(\.isChecked)
        }.count
    }

    var tripsNotStartedCount: Int {
        trips.filter { trip in
            let items = tripItems(for: trip)
            return !items.isEmpty && items.allSatisfy { !$0.isChecked }
        }.count
    }
}

// MARK: - Sezioni UI
private extension OverviewView {
//    var storageSection: some View {
////        VStack(alignment: .leading, spacing: 12) {
////            Text("Storage")
////                .font(.headline)
////                .foregroundStyle(.primary)
////            Divider()
////                .overlay(.white.opacity(0.12))
////            VStack(alignment: .leading, spacing: 10) {
////                LabeledContent("ForMemo") {
////                    Text(usedStorage)
////                }
////            }
////        }
////        .padding(16)
////        .background(
////            RoundedRectangle(cornerRadius: 16, style: .continuous)
////                .fill(.regularMaterial)
////                .shadow(color: .black.opacity(0.10), radius: 12, y: 6)
////                .shadow(color: .white.opacity(0.08), radius: 1, y: -1)
////        )
////        .overlay {
////            RoundedRectangle(cornerRadius: 16)
////                .stroke(.white.opacity(0.10), lineWidth: 1)
////        }
//    }

    var tasksSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Tasks")
                .font(.headline)
                .foregroundStyle(.primary)
            Divider()
                .overlay(.white.opacity(0.12))
            VStack(alignment: .leading, spacing: 10) {
                LabeledContent("Active") { Text("\(activeTasksCount)") }
                LabeledContent("Overdue") { Text("\(overdueTasksCountValue)") }
                LabeledContent("Recurring") { Text("\(recurringTasksCountValue)") }
                LabeledContent("With location") { Text("\(activeWithLocationCountValue)") }
                LabeledContent("Tasks with attachments") {
                    Text("\(activeWithAttachmentsCount)")
                }
                LabeledContent("Attachments") {
                    Text("\(activeAttachmentsCount)")
                }
                LabeledContent("Attachment storage") {
                    Text(activeAttachmentsSize)
                }

                LabeledContent("Completed") {
                    Text("\(completedTasksCountValue)")
                }
                LabeledContent("Completed tasks with attachments") {
                    Text("\(completedWithAttachmentsCount)")
                }
                LabeledContent("Completed attachments") {
                    Text("\(completedAttachmentsCount)")
                }
                LabeledContent("Completed attachment storage") {
                    Text(completedAttachmentsSize)
                }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.regularMaterial)
                .shadow(color: .black.opacity(0.10), radius: 12, y: 6)
                .shadow(color: .white.opacity(0.08), radius: 1, y: -1)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(.white.opacity(0.10), lineWidth: 1)
        }
    }

    var documentsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Documents")
                .font(.headline)
                .foregroundStyle(.primary)
            Divider()
                .overlay(.white.opacity(0.12))
            VStack(alignment: .leading, spacing: 10) {
                LabeledContent("Documents") { Text("\(documents.count)") }
                LabeledContent("Images/Files") {
                    Text("\(documentAssetsCount)")
                }
                    LabeledContent("Storage") {
                        Text(documentAssetsSize)
                    
                }
                LabeledContent("Expiring in 30 days") { Text("\(expiringDocumentsCount)") }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.regularMaterial)
                .shadow(color: .black.opacity(0.10), radius: 12, y: 6)
                .shadow(color: .white.opacity(0.08), radius: 1, y: -1)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(.white.opacity(0.10), lineWidth: 1)
        }
    }
    var notesSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Notes")
                .font(.headline)
                .foregroundStyle(.primary)

            Divider()
                .overlay(.white.opacity(0.12))

            VStack(alignment: .leading, spacing: 10) {
                LabeledContent("Notes") {
                    Text("\(activeNotesCount)")
                }

                LabeledContent("Archived") {
                    Text("\(archivedNotesCount)")
                }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.regularMaterial)
                .shadow(color: .black.opacity(0.10), radius: 12, y: 6)
                .shadow(color: .white.opacity(0.08), radius: 1, y: -1)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(.white.opacity(0.10), lineWidth: 1)
        }
    }
    
    var walletSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Wallet")
                .font(.headline)
                .foregroundStyle(.primary)

            Divider()
                .overlay(.white.opacity(0.12))

            VStack(alignment: .leading, spacing: 10) {
                LabeledContent("Cards") {
                    Text("\(cardsOnly.count)")
                }

                LabeledContent("Tickets") {
                    Text("\(tickets.count)")
                }

                LabeledContent("Logos Images") {
                    Text("\(walletLogosCount)")
                }

                LabeledContent("Images") {
                    Text("\(walletAssetsCount)")
                }

                LabeledContent("Storage") {
                    Text(walletAssetsSize)
                }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.regularMaterial)
                .shadow(color: .black.opacity(0.10), radius: 12, y: 6)
                .shadow(color: .white.opacity(0.08), radius: 1, y: -1)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(.white.opacity(0.10), lineWidth: 1)
        }
    }

    
    var vaultSection: some View {
        VStack(alignment: .leading, spacing: 12) {

            Text("Vault")
                .font(.headline)

            Divider()

            VStack(alignment: .leading, spacing: 10) {

                LabeledContent("Credentials") {
                    Text("\(activeVaultItems.count)")
                }

                LabeledContent("Recently Deleted") {
                    Text("\(deletedVaultItems.count)")
                }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.regularMaterial)
                .shadow(color: .black.opacity(0.10), radius: 12, y: 6)
                .shadow(color: .white.opacity(0.08), radius: 1, y: -1)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(.white.opacity(0.10), lineWidth: 1)
        }
    }
    
    var tripsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Checklists")
                .font(.headline)
                .foregroundStyle(.primary)
            Divider()
                .overlay(.white.opacity(0.12))
            VStack(alignment: .leading, spacing: 10) {
                LabeledContent("Checklists") { Text("\(trips.count)") }
                LabeledContent("In progress") { Text("\(tripsInProgressCount)") }
                LabeledContent("Completed") { Text("\(tripsCompletedCount)") }
                LabeledContent("Not started") { Text("\(tripsNotStartedCount)") }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.regularMaterial)
                .shadow(color: .black.opacity(0.10), radius: 12, y: 6)
                .shadow(color: .white.opacity(0.08), radius: 1, y: -1)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(.white.opacity(0.10), lineWidth: 1)
        }
    }
    
    var recentlyDeletedSection: some View {

        VStack(alignment: .leading, spacing: 12) {

            Text("Recently Deleted")
                .font(.headline)

            Divider()

            VStack(alignment: .leading, spacing: 10) {

                LabeledContent("Items") {
                    Text("\(recentlyDeletedItemsCount)")
                }

                LabeledContent("Storage") {
                    Text(recentlyDeletedStorage)
                }
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(.regularMaterial)
                .shadow(color: .black.opacity(0.10), radius: 12, y: 6)
                .shadow(color: .white.opacity(0.08), radius: 1, y: -1)
        )
        .overlay {
            RoundedRectangle(cornerRadius: 16)
                .stroke(.white.opacity(0.10), lineWidth: 1)
        }
    }
}
