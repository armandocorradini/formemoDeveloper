import SwiftUI

struct BackgroundCustomizationView: View {

    @Environment(AppSettings.self)
    private var settings
    @Environment(\.dismiss) private var dismiss

    private var color1: Binding<Color> {
        Binding(
            get: {
                Color(hex: settings.backgroundColor1Hex) ?? defaultBackColor1
            },
            set: {
                settings.backgroundColor1Hex =
                    $0.toHex() ?? settings.backgroundColor1Hex
            }
        )
    }

    private var color2: Binding<Color> {
        Binding(
            get: {
                Color(hex: settings.backgroundColor2Hex) ?? defaultBackColor2
            },
            set: {
                settings.backgroundColor2Hex =
                    $0.toHex() ?? settings.backgroundColor2Hex
            }
        )
    }

    private let presets: [(String, Color, Color)] = [
        
        ("Default", defaultBackColor1, defaultBackColor2),
        ("System Black/White", .black, .white),
        ("Custom", defaultBackColor1, defaultBackColor2),
        ("Graphite",
         Color(red: 0.11, green: 0.11, blue: 0.12),
         Color(red: 0.18, green: 0.18, blue: 0.20)),

        ("Carbon", Color(red: 0.18, green: 0.18, blue: 0.20), Color(red: 0.32, green: 0.34, blue: 0.38)),

        ("Storm", Color(red: 0.18, green: 0.22, blue: 0.32), Color(red: 0.42, green: 0.48, blue: 0.62)),

        ("Slate", Color(red: 0.22, green: 0.25, blue: 0.30), Color(red: 0.45, green: 0.48, blue: 0.55)),

        ("Titanium",
         Color(red: 0.96, green: 0.96, blue: 0.97),
         Color(red: 0.90, green: 0.91, blue: 0.93)),

        ("Pearl", Color(red: 0.96, green: 0.96, blue: 0.98), Color(red: 0.84, green: 0.86, blue: 0.90)),

        ("Night", Color(red: 0.12, green: 0.16, blue: 0.35), Color.black),

        ("Midnight", Color.black, Color(red: 0.08, green: 0.15, blue: 0.35)),

        ("Ocean", Color(red: 0.08, green: 0.18, blue: 0.38), Color(red: 0.00, green: 0.55, blue: 0.80)),

        ("Sapphire", Color(red: 0.05, green: 0.20, blue: 0.55), Color(red: 0.20, green: 0.50, blue: 0.95)),

        ("Arctic", Color(red: 0.00, green: 0.30, blue: 0.40), Color(red: 0.55, green: 0.80, blue: 0.95)),

        ("Sky", Color(red: 0.60, green: 0.82, blue: 1.00), Color(red: 0.88, green: 0.95, blue: 1.00)),

        ("Ice", Color(red: 0.70, green: 0.90, blue: 1.00), Color(red: 0.85, green: 0.97, blue: 1.00)),

        ("Galaxy", Color(red: 0.15, green: 0.10, blue: 0.40), Color(red: 0.45, green: 0.20, blue: 0.65)),

        ("Aurora", Color(red: 0.00, green: 0.45, blue: 0.50), Color(red: 0.35, green: 0.15, blue: 0.65)),

        ("Lavender", Color(red: 0.40, green: 0.22, blue: 0.60), Color(red: 0.20, green: 0.25, blue: 0.55)),

        ("Amethyst", Color(red: 0.45, green: 0.25, blue: 0.70), Color(red: 0.70, green: 0.50, blue: 0.95)),

        ("Plum", Color(red: 0.35, green: 0.10, blue: 0.45), Color(red: 0.65, green: 0.25, blue: 0.75)),

        ("Lavender Light", Color(red: 0.85, green: 0.80, blue: 0.98), Color(red: 0.78, green: 0.88, blue: 1.00)),

        ("Forest", Color(red: 0.05, green: 0.28, blue: 0.12), Color(red: 0.18, green: 0.55, blue: 0.25)),

        ("Emerald", Color(red: 0.00, green: 0.40, blue: 0.25), Color(red: 0.00, green: 0.55, blue: 0.45)),

        ("Olive", Color(red: 0.38, green: 0.42, blue: 0.12), Color(red: 0.65, green: 0.72, blue: 0.25)),
        
        ("Tropical", Color(red: 0.00, green: 0.65, blue: 0.55), Color(red: 0.10, green: 0.85, blue: 0.75)),

        ("Lagoon", Color(red: 0.00, green: 0.45, blue: 0.55), Color(red: 0.20, green: 0.85, blue: 0.80)),

        ("Mint", Color(red: 0.65, green: 0.92, blue: 0.82), Color(red: 0.80, green: 0.98, blue: 0.92)),

        ("Cherry", Color(red: 0.55, green: 0.05, blue: 0.15), Color(red: 0.95, green: 0.20, blue: 0.35)),

        ("Ruby", Color(red: 0.55, green: 0.08, blue: 0.18), Color(red: 0.90, green: 0.25, blue: 0.35)),

        ("Rose", Color(red: 0.65, green: 0.15, blue: 0.35), Color(red: 0.90, green: 0.25, blue: 0.45)),

        ("Coral", Color(red: 0.95, green: 0.45, blue: 0.40), Color(red: 1.00, green: 0.70, blue: 0.60)),

        ("Fire", Color(red: 0.70, green: 0.12, blue: 0.10), Color(red: 0.95, green: 0.45, blue: 0.10)),

        ("Copper", Color(red: 0.60, green: 0.35, blue: 0.20), Color(red: 0.85, green: 0.55, blue: 0.30)),

        ("Desert", Color(red: 0.78, green: 0.62, blue: 0.38), Color(red: 0.95, green: 0.82, blue: 0.58)),

        ("Sand", Color(red: 0.85, green: 0.76, blue: 0.60), Color(red: 0.68, green: 0.60, blue: 0.48)),

        ("Sunflower", Color(red: 0.95, green: 0.70, blue: 0.10), Color(red: 1.00, green: 0.90, blue: 0.35)),

        ("Sunset", Color(red: 1.00, green: 0.70, blue: 0.55), Color(red: 1.00, green: 0.82, blue: 0.78)),
        ("No Background", .clear, .clear),
        
        
    ]

    private var backgroundPatternBinding: Binding<AppBackgroundPattern> {
        Binding(
            get: {
                settings.backgroundPattern
            },
            set: {
                settings.backgroundPattern = $0
            }
        )
    }
    
    @ViewBuilder
    private var backgroundLayer: some View {
        ZStack {
            if settings.backgroundStyle == .system {
                Color(.systemBackground)
                    .ignoresSafeArea()

            } else if settings.backgroundStyle == .theme {
                Color.black
                    .opacity(0)
                    .background(Color(.systemBackground))
                    .ignoresSafeArea()

            } else {
                LinearGradient(
                    colors: [
                        Color(hex: settings.backgroundColor1Hex) ?? defaultBackColor1,
                        Color(hex: settings.backgroundColor2Hex) ?? defaultBackColor2
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                Rectangle()
                    .fill(.ultraThinMaterial)
                    .ignoresSafeArea()
            }
        }
        .ignoresSafeArea()
    }
    
    @ViewBuilder
    private var patternLayer: some View {
        GeometryReader { proxy in
            if let assetName = settings.backgroundPattern.assetName {
                Image(assetName)
                    .renderingMode(.template)
                    .resizable()
                    .scaledToFill()
                    .frame(
                        width: proxy.size.width,
                        height: proxy.size.width * 2.20,
                        alignment: .top
                    )
                    .clipped()
                    .foregroundStyle(.primary)
                    .opacity(settings.backgroundPatternOpacity)
                    .allowsHitTesting(false)
            }
        }
        .allowsHitTesting(false)
        .ignoresSafeArea()
    }
    
    private var patternOpacityBinding: Binding<Double> {
        Binding(
            get: { settings.backgroundPatternOpacity },
            set: { settings.backgroundPatternOpacity = $0 }
        )
    }
    
    var body: some View {
        let color1Hex = settings.backgroundColor1Hex
        let color2Hex = settings.backgroundColor2Hex
        ZStack {
            backgroundLayer
            patternLayer
        Form {

                Section("Presets") {

                    ScrollView(.horizontal, showsIndicators: false) {

                        HStack(alignment: .top, spacing: 14) {

                            let selectedColor1 = Color(hex: color1Hex) ?? defaultBackColor1
                            let selectedColor2 = Color(hex: color2Hex) ?? defaultBackColor2
                            
                            let isNoBackground = settings.backgroundStyle == .system
                            let isThemeBackground = settings.backgroundStyle == .theme

                            let isDefault =
                                settings.backgroundStyle == .gradient &&
                                selectedColor1.toHex() == defaultBackColor1.toHex() &&
                                selectedColor2.toHex() == defaultBackColor2.toHex()

                            let matchesPreset =
                                settings.backgroundStyle == .gradient &&
                                presets.contains {
                                    $0.0 != "No Background" &&
                                    $0.0 != "Custom" &&
                                    color1Hex == ($0.1.toHex() ?? "") &&
                                    color2Hex == ($0.2.toHex() ?? "")
                                }

                            let shouldShowCustom =
                                !isNoBackground &&
                                !isThemeBackground &&
                                !isDefault &&
                                !matchesPreset

                            let visiblePresets = presets.filter {
                                shouldShowCustom || $0.0 != "Custom"
                            }

                            ForEach(Array(visiblePresets.enumerated()), id: \.offset) { item in

                                let preset = item.element
                                let localizedName = localizedPresetName(preset.0)

                                let isSelected: Bool = {

                                    if preset.0 == "No Background" {
                                        return isNoBackground
                                    }

                                    if preset.0 == "System Black/White" {
                                        return isThemeBackground
                                    }

                                    if isThemeBackground {
                                        return false
                                    }

                                    guard settings.backgroundStyle == .gradient else {
                                        return false
                                    }

                                    if preset.0 == "Default" {
                                        return isDefault
                                    }

                                    if preset.0 == "Custom" {
                                        return shouldShowCustom
                                    }

                                    return color1Hex == (preset.1.toHex() ?? "") &&
                                           color2Hex == (preset.2.toHex() ?? "")
                                }()

                                Button {
                                    if preset.0 == "No Background" {
                                        settings.backgroundStyle = .system
                                    } else if preset.0 == "System Black/White" {
                                        settings.backgroundStyle = .theme
                                        settings.backgroundColor1Hex = Color.black.toHex() ?? settings.backgroundColor1Hex
                                        settings.backgroundColor2Hex = Color.white.toHex() ?? settings.backgroundColor2Hex
                                    } else {
                                        settings.backgroundStyle = .gradient

                                        settings.backgroundColor1Hex =
                                            preset.1.toHex() ?? settings.backgroundColor1Hex

                                        settings.backgroundColor2Hex =
                                            preset.2.toHex() ?? settings.backgroundColor2Hex
                                    }
                                } label: {

                                    VStack(spacing: 6) {

                                        ZStack {

                                            RoundedRectangle(
                                                cornerRadius: 22,
                                                style: .continuous
                                            )
                                            .fill(
                                                LinearGradient(
                                                    colors: preset.0 == "Custom"
                                                        ? [selectedColor1, selectedColor2]
                                                        : [preset.1, preset.2],
                                                    startPoint: .topLeading,
                                                    endPoint: .bottomTrailing
                                                )
                                            )
//XXXXX
                                            VStack {

                                                Capsule()
                                                    .fill(.black.opacity(0.25))
                                                    .frame(width: 18, height: 4)

                                                Spacer()
                                            }
                                            .padding(.top, 6)
                                        }
                                        .frame(width: 52, height: 100)
                                        .overlay {
                                            RoundedRectangle(cornerRadius: 22)
                                                .stroke(
                                                    isSelected
                                                        ? Color.accentColor
                                                        : (preset.0 == "No Background"
                                                            ? Color.primary.opacity(0.28)
                                                            : Color.clear),
                                                    lineWidth: isSelected ? 3 : 1
                                                )
                                        }

                                        Text(localizedName)
                                            .font(.caption2)
                                            .foregroundStyle(.primary)
                                            .lineLimit(1)
                                    }
                                }
                                .buttonStyle(.plain)
                                .contentShape(Rectangle())
                            }
                        }
                        .padding(.horizontal, 4)
                    }
                }
                Section("Pattern") {
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 12) {
                            patternButton(
                                pattern: .none,
                                title: "None"
                            )
                            
                            patternButton(
                                pattern: .balanced,
                                title: "Balanced"
                            )
                            
                            patternButton(
                                pattern: .dense,
                                title: "Dense"
                            )
                            patternButton(
                                pattern: .packed,
                                title: "Packed"
                            )
                            
                            patternButton(
                                pattern: .saturated,
                                title: "Saturated"
                            )
                            patternButton(
                                pattern: .essential,
                                title: "Essential"
                            )

                            patternButton(
                                pattern: .organizer,
                                title: "Organizer"
                            )

                            patternButton(
                                pattern: .geometric,
                                title: "Geometric"
                            )

                            patternButton(
                                pattern: .notes,
                                title: "Notes"
                            )
                            patternButton(
                                pattern: .flow,
                                title: "Flow"
                            )
                            patternButton(
                                pattern: .minimal,
                                title: "Minimal"
                            )
                            patternButton(
                                pattern: .sea,
                                title: "Sea"
                            )
                            patternButton(
                                pattern: .mountain,
                                title: "Mountain"
                            )
                            patternButton(
                                pattern: .countryside,
                                title: "Countryside"
                            )
                            patternButton(
                                pattern: .space,
                                title: "Space"
                            )

                        }
                        .padding(.vertical, 4)
                    }

                    if settings.backgroundPattern != .none {
                        VStack(spacing: 6) {
                            HStack {
                                Text("Opacity")

                                Spacer()

                                Text(
                                    settings.backgroundPatternOpacity,
                                    format: .percent.precision(.fractionLength(1))
                                )
                                .foregroundStyle(.secondary)
                                .monospacedDigit()
                            }

                            Slider(
                                value: patternOpacityBinding,
                                in: 0...0.30,
                                step: 0.001
                            )
                        }
                    }
                }
                Section("Customize colors") {

                    ColorPicker("Top color", selection: color1)


                    ColorPicker("Bottom color", selection: color2)
                }


                Section {

                    Text("Changes are applied immediately throughout the app.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                }

            }
        .listStyle(.insetGrouped)
            .contentMargins(.bottom, 70, for: .scrollContent)
            .scrollContentBackground(.hidden)
            .background(Color.clear)
        }
        .navigationBarBackButtonHidden(true)
        .navigationTitle("Background")
        .navigationBarTitleDisplayMode(.inline)
        .scrollEdgeEffectHidden(true, for: .top)
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "chevron.left")
                }
                
            }
        }
    }
    
    private func localizedPresetName(_ key: String) -> String {

        switch key {

        case "Default": return String(localized: "Default")
        case "Ocean": return String(localized: "Ocean")
        case "Aurora": return String(localized: "Aurora")
        case "Night": return String(localized: "Night")
        case "Emerald": return String(localized: "Emerald")
        case "Lavender": return String(localized: "Lavender")
        case "Fire": return String(localized: "Fire")
        case "Rose": return String(localized: "Rose")
        case "Midnight": return String(localized: "Midnight")
        case "Arctic": return String(localized: "Arctic")
        case "Galaxy": return String(localized: "Galaxy")
        case "Carbon": return String(localized: "Carbon")
        case "Sky": return String(localized: "Sky")
        case "Sand": return String(localized: "Sand")
        case "Sunset": return String(localized: "Sunset")
        case "Mint": return String(localized: "Mint")
        case "Pearl": return String(localized: "Pearl")
        case "Lavender Light": return String(localized: "Lavender Light")
        case "Ruby": return String(localized: "Ruby")
        case "Ice": return String(localized: "Ice")
        case "Copper": return String(localized: "Copper")
        case "Tropical": return String(localized: "Tropical")
        case "Amethyst": return String(localized: "Amethyst")
        case "Slate": return String(localized: "Slate")
        case "Forest": return String(localized: "Forest")
        case "Sapphire": return String(localized: "Sapphire")
        case "Cherry": return String(localized: "Cherry")
        case "Desert": return String(localized: "Desert")
        case "Lagoon": return String(localized: "Lagoon")
        case "Plum": return String(localized: "Plum")
        case "Sunflower": return String(localized: "Sunflower")
        case "Storm": return String(localized: "Storm")
        case "Coral": return String(localized: "Coral")
        case "Olive": return String(localized: "Olive")
        case "Custom": return String(localized: "Custom")
        case "Titanium": return String(localized: "Titanium")
        case "Graphite": return String(localized: "Graphite")
        case "No Background": return String(localized: "No Background")
        case "System Black/White": return String(localized: "System Black/White")
        default:
            return key
        }
    }
    
    @ViewBuilder
    private func patternButton(
        pattern: AppBackgroundPattern,
        title: LocalizedStringKey
    ) -> some View {
        let isSelected = settings.backgroundPattern == pattern

        Button {
            settings.backgroundPattern = pattern
        } label: {
            VStack(spacing: 6) {
                ZStack {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(.regularMaterial)

                    if let assetName = pattern.assetName {
                        Image(assetName)
                            .renderingMode(.template)
                            .resizable()
                            .scaledToFill()
                            .foregroundStyle(.primary)
                            .opacity(0.65)
                            .clipped()
                    } else {
                        Image(systemName: "nosign")
                            .font(.title2)
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(width: 92, height: 64)
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay {
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(
                            isSelected ? Color.accentColor : .clear,
                            lineWidth: 2
                        )
                }

                Text(title)
                    .font(.caption)
                    .foregroundStyle(.primary)
            }
        }
        .buttonStyle(.plain)
    }
    
}
