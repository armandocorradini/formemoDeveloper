@preconcurrency import AuthenticationServices
import SwiftUI
import EventKit
import SwiftData
import CoreData
import CoreLocation
import os

enum SoundPickerContext: Identifiable {
    case task
    case location

    var id: String {
        switch self {
        case .task:
            return "task"
        case .location:
            return "location"
        }
    }
}

private enum SettingsCategory: String, CaseIterable, Identifiable {
    case general = "General"
    case appearance = "Appearance"
    case activity = "Activity"
    case notifications = "Notifications"
    case siri = "Siri & Shortcuts"
    case data = "Data Management"
    case help = "Help"
    case info = "About"
    var id: String { rawValue }

    var title: String {
        switch self {
        case .general: String(localized: "General")
        case .appearance: String(localized: "Appearance")
        case .activity: String(localized: "Recurrences and deletion")
        case .notifications: String(localized: "Notifications & Alarms")
        case .siri: String(localized: "Siri & Shortcuts")
        case .data: String(localized: "Data Management")
        case .help: String(localized: "Help")
        case .info: String(localized: "About")
        }
    }

    var localizedSubtitle: String {
        switch self {
        case .general: String(localized: "Language, permissions and navigation")
        case .appearance: String(localized: "Theme, backgrounds and tabs")
        case .activity: String(localized: "Recurrences and deletion tasks")
        case .notifications: String(localized: "Alerts, sounds and alarms")
        case .siri: String(localized: "Siri and Shortcuts preferences")
        case .data: String(localized: "Import, export, backup and storage")
        case .help: String(localized: "Guides, FAQ and diagnostics")
        case .info: String(localized: "Account, privacy and app information")
        }
    }

    var symbol: String {
        switch self {
        case .general: "gearshape"
        case .appearance: "paintpalette"
        case .activity: "checklist"
        case .notifications: "bell.badge"
        case .siri: "waveform"
        case .data: "externaldrive"
        case .help: "questionmark.circle"
        case .info: "info.circle"
        }
    }
    var subtitle: String {
        switch self {
        case .general: "Language, permissions and navigation"
        case .appearance: "Theme, backgrounds and tabs"
        case .activity: "Startup, deadlines and task behavior"
        case .notifications: "Alerts, sounds and alarms"
        case .siri: "Siri and Shortcuts preferences"
        case .data: "Import, export, backup and storage"
        case .help: "Guides, FAQ and diagnostics"
        case .info: "Account, privacy and app information"
        }
    }
}

struct SettingsView: View {
    
    @Environment(\.modelContext) private var modelContext
    @Environment(AppSettings.self)
    private var settings
    
    @State private var selectedCategory: SettingsCategory? = nil
#if DEBUG
    @State private var hasTestData: Bool = false
    @State private var areTestTasksCompleted: Bool = false
    @State private var debugKeepGenerateMode: Bool = false
#endif
    @State private var showQuickGuide = false
    @State private var showFAQ = false
    @State private var showCustomizationView = false
    @State private var showDataManagement = false
    @State private var showSiri = false
    @State private var showRecentlyDeleted = false
    @State private var showDeleteAllAlert = false


    @AppStorage("siriShortConfirmation")
    private var siriShortConfirmation: Bool = false

    
    private var autoDeleteCompletedAttachments: Bool {
        get { settings.autoDeleteCompletedAttachments }
        set { settings.autoDeleteCompletedAttachments = newValue }
    }

    private var attachmentRetentionDays: Int {
        get { settings.attachmentRetentionDays }
        set { settings.attachmentRetentionDays = newValue }
    }

    private var recentlyDeletedRetentionDays: Int {
        get { settings.recentlyDeletedRetentionDays }
        set { settings.recentlyDeletedRetentionDays = newValue }
    }
    
    @State private var isNotificationEnabled: Bool = false
    @Environment(\.scenePhase) private var scenePhase
    @State private var soundPickerContext: SoundPickerContext?
    @State private var showDisclaimer = false

    private var privacyPolicyURL: URL? {
        URL(string: "https://armandocorradini.github.io/formemo/privacy.html")
    }
    
    @State private var showOpenSourceLicenses = false
    
    @AppStorage("notificationSoundName")
    private var notificationSoundName: String = ""
    @AppStorage("locationNotificationSoundName")
    private var locationNotificationSoundName: String = ""

    private var locationRadius: Int {
        get { settings.locationRadius }
        set { settings.locationRadius = newValue }
    }
    
    private var backgroundColor1Hex: String {
        settings.backgroundColor1Hex
    }

    private var backgroundColor2Hex: String {
        settings.backgroundColor2Hex
    }
    @State private var showLocationPermissionAlert = false
    @State private var showImportReminders = false
    @State private var locationAuthorizationStatus: CLAuthorizationStatus = CLLocationManager().authorizationStatus

    func checkNotificationStatus() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            Task { @MainActor in
                self.isNotificationEnabled =
                settings.authorizationStatus == .authorized
                || settings.authorizationStatus == .provisional
            }
        }
    }
    private var startupTabDisplayName: String {
        switch settings.startupTab {
        case -1:
            return String(localized: "Automatic")
        case AppTab.dashboard.rawValue:
            return String(localized: "Dashboard")
        case AppTab.tasks.rawValue:
            return String(localized: "list_tab")
        case AppTab.today.rawValue:
            return settings.taskWeekDays == 1
                ? String(localized: "today_tab")
                : String(localized: "\(settings.taskWeekDays) days_tab")
        case AppTab.calendar.rawValue:
            return String(localized: "Calendar")
        case AppTab.agenda.rawValue:
            return String(localized: "Agenda")
        case AppTab.wallet.rawValue:
            return String(localized: "Wallet")
        case AppTab.trips.rawValue:
            return String(localized: "Checklists")
        case AppTab.documents.rawValue:
            return String(localized: "Documents")
        case AppTab.notes.rawValue:
            return String(localized: "Notes")
        case AppTab.map.rawValue:
            return String(localized: "Map")
        case AppTab.forecast.rawValue:
            return String(localized: "Weather Forecast")
        case AppTab.vault.rawValue:
            return String(localized: "Vault")
        default:
            return String(localized: "Automatic")
        }
    }

    private var settingsRowChevron: some View {
        Image(systemName: "chevron.right")
            .font(.system(size: 14, weight: .semibold))
            .foregroundStyle(.tertiary)
            .padding(.trailing, 4)
            .allowsHitTesting(false)
    }

    @ViewBuilder
    private func settingsCategoryRow(_ category: SettingsCategory) -> some View {
        Button {
            withAnimation(.snappy) { selectedCategory = category }
        } label: {
            HStack(spacing: 14) {
                Image(systemName: category.symbol)
                    .font(.system(size: 20, weight: .medium))
                    .foregroundStyle(.blue)
                    .frame(width: 30)
                VStack(alignment: .leading, spacing: 3) {
                    Text(category.title).foregroundStyle(.primary)
                    Text(category.localizedSubtitle).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.footnote.weight(.semibold)).foregroundStyle(.tertiary)
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
    }

    var body: some View {
        let _ = backgroundColor1Hex
        let _ = backgroundColor2Hex
        let iconWidth: CGFloat = 28
        NavigationStack {
            ZStack {
                AppGlassBackground()
                List {
                    
                    if selectedCategory == nil {
                        Section {
                            ForEach([SettingsCategory.general, .appearance]) { category in
                                settingsCategoryRow(category)
                            }
                        }
                        .listRowBackground(Color(.systemBackground).opacity(0.3))

                        Section {
                            ForEach([SettingsCategory.activity, .notifications, .siri]) { category in
                                settingsCategoryRow(category)
                            }
                        }
                        .listRowBackground(Color(.systemBackground).opacity(0.3))

                        Section {
                            ForEach([SettingsCategory.data, .help, .info]) { category in
                                settingsCategoryRow(category)
                            }
                        }
                        .listRowBackground(Color(.systemBackground).opacity(0.3))
                    }
                    if selectedCategory == .info {
                    // MARK: - Account
                    Section("Account and info") {
                        HStack(spacing: 12){
                            Image(systemName: "person.circle").foregroundStyle(.blue)
                                .frame(width: iconWidth)
                            Text("Signed in with Apple ID")
                                .foregroundStyle(.secondary)
                            Spacer()
                        }
                        Button {
                            showDisclaimer = true
                        } label: {
                            Label {
                                Text("Disclaimer")
                                    .tint(.primary)
                            } icon: {
                                Image(systemName: "exclamationmark.shield")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .overlay(alignment: .trailing) { settingsRowChevron }
                        .sheet(isPresented: $showDisclaimer) {
                            DisclaimerView()
                        }

                        if let privacyPolicyURL {
                            Link(destination: privacyPolicyURL) {
                                Label {
                                    Text("Privacy Policy")
                                        .tint(.blue)
                                } icon: {
                                    Image(systemName: "hand.raised")
                                        .foregroundStyle(.blue)
                                        .frame(width: iconWidth)
                                }
                            }
                        }
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                    
                    }

                    if selectedCategory == .help {
                    Section {
                        Button {
                            showQuickGuide = true
                        } label: {
                            Label {
                                Text("Quick Guide")
                                    .tint(.primary)
                            } icon: {
                                Image(systemName: "questionmark.circle")
                                    .foregroundStyle(.blue)
                                .frame(width: iconWidth)}
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .overlay(alignment: .trailing) { settingsRowChevron }
                        Button {
                            showFAQ = true
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "text.book.closed")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                Text("FAQ")
                                    .tint(.primary)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .overlay(alignment: .trailing) { settingsRowChevron }
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                    }

                    if selectedCategory == .general {
                    // MARK: - General
                    Section {
                        NavigationLink {
                            StartupTabSelectionView()
                        } label: {
                            VStack(alignment: .leading, spacing: 6) {
                                HStack(spacing: 12) {
                                    Image(systemName: "arrowshape.turn.up.right")
                                        .foregroundStyle(.blue)
                                        .frame(width: iconWidth)

                                    Text("Open at launch")
                                        .foregroundStyle(.primary)

                                    Spacer()

                                    Text(startupTabDisplayName)
                                        .foregroundStyle(.blue)
                                        .opacity(0.7)
                                }

                                Text("Choose which tab ForMemo opens when you launch the app.")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                    .fixedSize(horizontal: false, vertical: true)
                                    .padding(.leading, iconWidth + 12)
                            }
                        }
                        Button {
                            if let url = URL(string: UIApplication.openSettingsURLString) {
                                UIApplication.shared.open(url)
                            }
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "lock.shield")
                                    .font(.system(size: 21, weight: .semibold))
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                
                                Text("Permissions")
                                    .tint(.primary)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .overlay(alignment: .trailing) { settingsRowChevron }
                        
                        Button {
                            openLanguageSettings()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "globe")
                                    .frame(width: iconWidth)
                                Text("Language")
                                    .tint(.primary)
                                Spacer()
                                Text(Locale.current.localizedString(forIdentifier: Locale.current.identifier) ?? "")
                                    .foregroundStyle(.blue).opacity(0.7)
                            }
                        }
//                        .frame(maxWidth: .infinity, alignment: .leading)
//                        .overlay(alignment: .trailing) { settingsRowChevron }
                        LabeledContent {
                            Picker(
                                "",
                                selection: Binding(
                                    get: { settings.navigationApp },
                                    set: { settings.navigationApp = $0 }
                                )
                            ) {
                                ForEach(NavigationApp.availableApps){ app in
                                    Text(app.title).tag(app)
                                }
                            }
                            .pickerStyle(.menu)
                            .labelsHidden()
                            .opacity(0.7)
                        } label: {
                            Label("Navigation app", systemImage: "iphone.badge.location")
                        }
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                    }

                    if selectedCategory == .appearance {
                    // MARK: - Appearance
                    Section {
                        NavigationLink {
                            BackgroundCustomizationView()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "paintpalette")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                
                                Text("Background")
                                    .foregroundStyle(.primary)
                            }
                        }

                        HStack(spacing: 12){
                            Image(systemName: "paintbrush")
                                .foregroundStyle(.blue)
                                .frame(width: iconWidth)
                            
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Theme")
                                
                                Text("Optimized for Dark Mode")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            
                            Spacer()
                            
                            Picker(
                                "",
                                selection: Binding(
                                    get: { settings.selectedTheme },
                                    set: { settings.selectedTheme = $0 }
                                )
                            ) {
                                ForEach(AppTheme.allCases) { theme in
                                    Text(theme.description).tag(theme)
                                }
                            }
                            .foregroundStyle(.blue)
                            .pickerStyle(.menu)
                            .opacity(0.7)
                        }
                        
                        Button {
                            showCustomizationView = true
                        } label: {
                            Label {
                                Text("Customize Task List")
                                    .tint(.primary)
                            } icon: {
                                Image(systemName: "list.bullet.circle")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .overlay(alignment: .trailing) { settingsRowChevron }
                        
                        NavigationLink {
                            TabBarCustomizationView()
                        } label: {
                            Label {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Customize Tab Bar")

                                    Text("Choose the order of all sections")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            } icon: {
                                Image(systemName: "rectangle.3.group")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                            }
                        }
                        
                        NavigationLink {
                            TabVisibilitySettingsView()
                        } label: {
                            Label {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Tab Visibility")
                                    Text("Choose which tabs appear in tab bar")
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                            } icon: {
                                Image(systemName: "square.on.square.dashed")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                            }
                        }
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                    
                    }

                    if selectedCategory == .activity {
                    // MARK: - Recurring Tasks
                    Section {
                        Stepper(
                            "Maximum occurrences: \(settings.maximumOccurrencesPerOperation)",
                            value: Binding(
                                get: { settings.maximumOccurrencesPerOperation },
                                set: { settings.maximumOccurrencesPerOperation = $0 }
                            ),
                            in: 50...1_000,
                            step: 50
                        )

                        Stepper(
                            "Ask for confirmation above: \(settings.confirmationThreshold)",
                            value: Binding(
                                get: { settings.confirmationThreshold },
                                set: { settings.confirmationThreshold = $0 }
                            ),
                            in: 10...settings.maximumOccurrencesPerOperation,
                            step: 10
                        )
                        .disabled(settings.maximumOccurrencesPerOperation < 10)
                    } header: {
                        Text("Recurrences")
                    } footer: {
                        Text("For a single operation, ForMemo creates up to the selected maximum number of future occurrences. It asks for confirmation when the operation exceeds the confirmation threshold.")
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))

                        Section {
                            Toggle(
                                "Confirm task deletion",
                                isOn: Binding(
                                    get: { settings.confirmTaskDeletion },
                                    set: { settings.confirmTaskDeletion = $0 }
                                )
                            )
                        } header: {
                            Text("Deletion")
                        } footer: {
                            Text("When enabled, you'll be asked to confirm before deleting a task.")
                        }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))

                    }

                    if selectedCategory == .notifications {
                    // MARK: - Notifications
                    Section {
                        Button {
                            openNotificationSettings()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: isNotificationEnabled ? "bell.badge" : "bell.badge.slash")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                Text("Notifications & Alarms")
                                    .tint(.primary)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .overlay(alignment: .trailing) { settingsRowChevron }
                        
                        NavigationLink {
                            NotificationView()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "clock.badge")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                
                                Text("Scheduled Notifications")
                                    .tint(.primary)
                            }
                        }
                        
                        NavigationLink {
                            OtherSettingsView()
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "app.badge.checkmark")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                Text("Global Notifications and Badges")
                                    .foregroundStyle(.primary)
                            }
                        }
                        
                        Button {
                            soundPickerContext = .task
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "music.note")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                
                                Text("Sound")
                                    .foregroundStyle(.primary)
                                
                                Spacer()
                                
                                Text(notificationSoundName.isEmpty ? "Default" : notificationSoundName)
                                    .foregroundStyle(.secondary)
                            }
                        }
//                        .frame(maxWidth: .infinity, alignment: .leading)
//                        .overlay(alignment: .trailing) { settingsRowChevron }
                        .buttonStyle(.plain)
                        .disabled(!isNotificationEnabled)
                        
                        
                        Group {
                            Toggle(
                                "Location Reminders",
                                isOn: Binding(
                                    get: { settings.locationRemindersEnabled },
                                    set: handleLocationReminderToggle
                                )
                            )
                            
                            
                            if settings.locationRemindersEnabled {
                                VStack(alignment: .leading, spacing: 8) {
                                    
                                    HStack(spacing: 12) {
                                        Image(systemName: "location.circle")
                                            .foregroundStyle(.blue)
                                            .frame(width: iconWidth)
                                        
                                        Text("Trigger Distance")
                                            .foregroundStyle(.primary)
                                    }
                                    HStack{
                                        Spacer()
                                        Text(String(localized:"\(locationRadius)     meters"))
                                        Stepper(
                                            "",
                                            value: Binding(
                                                get: { settings.locationRadius },
                                                set: { settings.locationRadius = $0 }
                                            ),
                                            in: 100...500,
                                            step: 50
                                        )
                                        .labelsHidden()
                                    }
                                }
                                Button {
                                    soundPickerContext = .location
                                } label: {
                                    HStack(spacing: 12) {
                                        Image(systemName: "sensor.tag.radiowaves.forward")
                                            .foregroundStyle(.blue)
                                            .frame(width: iconWidth)
                                        
                                        Text("Location sound")
                                            .foregroundStyle(.primary)
                                        
                                        Spacer()
                                        
                                        Text(locationNotificationSoundName.isEmpty ? "Default" : locationNotificationSoundName)
                                            .foregroundStyle(.secondary)
                                    }
                                }
//                                .frame(maxWidth: .infinity, alignment: .leading)
//                        .overlay(alignment: .trailing) { settingsRowChevron }
                                .buttonStyle(.plain)
                                .disabled(!isNotificationEnabled)
                            }
                        }
                        .alert("Enable Location Access", isPresented: $showLocationPermissionAlert) {
                            Button("Open Settings") {
                                if let url = URL(string: UIApplication.openSettingsURLString) {
                                    UIApplication.shared.open(url)
                                }
                            }
                            Button("Cancel", role: .cancel) { }
                        } message: {
                            Text("Location reminders require \"Always Allow\" location access. Please enable it in Settings.")
                        }
                        
#if DEBUG
                        Button {
                            Task {
                                let center = UNUserNotificationCenter.current()
                                let requests: [UNNotificationRequest] =
                                await center.pendingNotificationRequests()
                                
                                print("🔔 DEBUG NOTIFICATIONS START ------------------")
                                
                                var seenDates: [Date: [String]] = [:]
                                
                                for req in requests {
                                    
                                    let id = req.identifier
                                    let title = req.content.title
                                    let body = req.content.body
                                    
                                    var pipelineInfo: [String] = []
                                    
                                    if id.contains(".global") {
                                        pipelineInfo.append("Prossimo: GLOBAL")
                                        pipelineInfo.append("Poi: REMINDER → DEADLINE")
                                    } else if id.contains(".reminder") {
                                        pipelineInfo.append("Prossimo: REMINDER")
                                        pipelineInfo.append("Poi: DEADLINE")
                                    } else if id.contains(".deadline") {
                                        pipelineInfo.append("Prossimo: DEADLINE")
                                        pipelineInfo.append("GLOBAL non valida o passata")
                                    } else if id.contains(".snooze") {
                                        pipelineInfo.append("Prossimo: SNOOZE")
                                    }
                                    
                                    
                                    var triggerInfo = "unknown"
                                    
                                    if let t = req.trigger as? UNCalendarNotificationTrigger,
                                       let next = t.nextTriggerDate() {
                                        let formatter = DateFormatter()
                                        formatter.dateStyle = .medium
                                        formatter.timeStyle = .short
                                        triggerInfo = "📅 \(formatter.string(from: next))"
                                        seenDates[next, default: []].append(id)
                                    } else if let t = req.trigger as? UNTimeIntervalNotificationTrigger {
                                        triggerInfo = "⏱ in \(Int(t.timeInterval))s"
                                    } else if let t = req.trigger as? UNLocationNotificationTrigger {
                                        let region = t.region
                                        if let circular = region as? CLCircularRegion {
                                            let name = region.identifier.isEmpty ? "unknown" : region.identifier
                                            triggerInfo = "📍 \(name) | lat: \(circular.center.latitude), lon: \(circular.center.longitude), radius: \(Int(circular.radius))m"
                                        } else {
                                            let name = region.identifier.isEmpty ? "unknown" : region.identifier
                                            triggerInfo = "📍 \(name) | location trigger"
                                        }
                                    }
                                    
                                    var type = "❓ UNKNOWN"
                                    
                                    if id.contains(".deadline") {
                                        type = "⏰ DEADLINE"
                                    } else if id.contains(".global") {
                                        type = "⏱️ GLOBAL"
                                    } else if id.contains(".reminder") {
                                        type = "🔔 REMINDER"
                                    } else if id.contains(".snooze") {
                                        type = "⏲️ SNOOZE"
                                    } else if title.contains("Manca") || title.contains("days") {
                                        type = "⏱️ GLOBAL"
                                    }
                                    
                                    print("🔎 RAW ID:", id)
                                    
                                    print("""
ID: \(id)
Tipo: \(type)
Titolo: \(title)
Task: \(body)
Attivazione: \(triggerInfo)
➡️ Notifica attiva (PROSSIMA per il task)
📊 Pipeline:
\(pipelineInfo.joined(separator: "\n"))
------------------
""")
                                }
                                
                                print("🔍 COLLISIONS ------------------")
                                for (date, ids) in seenDates where ids.count > 1 {
                                    print("⚠️ Same trigger date:", date)
                                    ids.forEach { print("   -> \($0)") }
                                }
                                print("🔍 END COLLISIONS --------------")
                                
                                print("🔔 DEBUG NOTIFICATIONS END --------------------")
                            }
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "waveform.path.ecg.magnifyingglass")
                                    .foregroundStyle(.red)
                                    .frame(width: iconWidth)
                                
                                Text("Debug Notifications")
                                    .foregroundStyle(.red)
                            }
                        }
#endif
                    }
                    footer: {
                        Text("Notifications must be enabled in system settings to receive alerts and sounds.")
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                    
                    }

                    if selectedCategory == .siri {
                    Section {
                        
                        Button {
                            showSiri = true
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "waveform.circle")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                Text("Use with Siri")
                                    .foregroundStyle(.primary)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 14, weight: .semibold))
                                    .foregroundStyle(.tertiary)
                            }
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        
                        Toggle(isOn: Binding(
                            get: { settings.siriAutoReminderEnabled },
                            set: { settings.siriAutoReminderEnabled = $0 }
                        )) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Add reminders automatically")

                                Text("Automatically add a reminder when creating a task with Siri.")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        
                        Toggle(isOn: $siriShortConfirmation) {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Short confirmation")
                                Text("Siri replies briefly after creating a task.")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                    
                    }

                    if selectedCategory == .data {
                    Section {
                        Toggle(
                            "Auto-delete attachments",
                            isOn: Binding(
                                get: { settings.autoDeleteCompletedAttachments },
                                set: { settings.autoDeleteCompletedAttachments = $0 }
                            )
                        )
                        
                        Stepper(
                            "Delete after \(attachmentRetentionDays) days",
                            value: Binding(
                                get: { settings.attachmentRetentionDays },
                                set: { settings.attachmentRetentionDays = $0 }
                            ),
                            in: 1...90,
                            step: 1
                        )
                        .disabled(!autoDeleteCompletedAttachments)
                        .foregroundStyle(autoDeleteCompletedAttachments ? .primary : .secondary)
                        
                        Button(role: .destructive) {
                            showDeleteAllAlert = true
                        } label: {
                            Text("Delete all attachments now")
                        }
                        .alert(
                            "Are you sure? This cannot be undone.",
                            isPresented: $showDeleteAllAlert
                        ) {
                            Button("Cancel", role: .cancel) { }
                            
                            Button("Delete", role: .destructive) {
                                do {
                                    try AttachmentMaintenanceManager.shared
                                        .deleteAllCompletedTaskAttachments(context: modelContext)

                                    NotificationCenter.default.post(
                                        name: .attachmentsShouldRefresh,
                                        object: nil
                                    )
                                } catch {
                                    AppLogger.persistence.error(
                                        "Manual attachment cleanup failed: \(error.localizedDescription)"
                                    )
                                }
                            }
                        } message: {
                            Text("This permanently removes all attachments. This action cannot be undone.")
                        }
                    }
                    header: {
                        Text("Completed Tasks")
                    } footer: {
                        Text("Attachments of completed tasks are automatically removed after the selected period. To-do tasks are not affected.")
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                        
                    Section {
                        NavigationLink {
                            OverviewView()
                        } label: {
                            Label {
                                Text("Overview")
                                    .tint(.primary)
                            } icon: {
                                Image(systemName: "line.3.horizontal.button.angledtop.vertical.right")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                            }
                        }
                        
                        NavigationLink {
                            ImportExportSettingsView()
                        } label: {
                            Label {
                                Text("Import & Export")
                                    .tint(.primary)
                            } icon: {
                                Image(systemName: "arrow.left.arrow.right")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                            }
                        }

                        NavigationLink {
                            BackupRestoreView()
                        } label: {
                            Label {
                                Text("Backup & Restore")
                                    .tint(.primary)
                            } icon: {
                                Image(systemName: "externaldrive.badge.icloud")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                            }
                        }

                        Button {
                            showRecentlyDeleted = true
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "clock.arrow.circlepath")
                                    .foregroundStyle(.blue)
                                    .frame(width: iconWidth)
                                Text("Recently Deleted")
                                    .tint(.primary)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .overlay(alignment: .trailing) { settingsRowChevron }

                        Stepper(
                            "Delete after \(recentlyDeletedRetentionDays) days",
                            value: Binding(
                                get: { settings.recentlyDeletedRetentionDays },
                                set: { settings.recentlyDeletedRetentionDays = $0 }
                            ),
                            in: 1...90,
                            step: 1
                        )
                        .foregroundStyle(.secondary)
                    }
                        header: {
                            Text("Data Management")}
                    footer: {
                        Text("Items in Recently Deleted are permanently removed after the selected period. You can restore them before that.")
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                        
                        
                        
                    Section {
                        Button(role: .destructive) {
                            showDataManagement = true
                        } label: {
                            HStack(spacing: 12) {
                                Image(systemName: "trash.circle")
                                    .foregroundStyle(.red)
                                    .frame(width: iconWidth)
                                
                                Text("Erase all Data")
                                    .foregroundStyle(.red)
                            }
                        }
                    } footer: {
                        Text("This permanently deletes all ForMemo content from this device and its iCloud database, including tasks, notes, checklists, trips, documents, attachments, cards, tickets, vault items, and recently deleted items. The deletion will sync to your other devices. App settings and preferences are not reset. This action cannot be undone.")
                    }
                    

                    }

                    if selectedCategory == .help {
                    Section {
                        NavigationLink {
                            ExportDiagnosticsView()
                        } label: {
                            Label {
                                Text("Diagnostics")
                                    .foregroundStyle(.primary)
                            } icon: {
                                Image(systemName: "waveform.path.ecg.magnifyingglass")
                                    .foregroundStyle(.orange)
                                    .frame(width: iconWidth)
                            }
                        }
                    }
                    
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                    
                    }

                    if selectedCategory == .info {
                    Section {
                            VStack(alignment: .leading, spacing: 6) {
                                Button {
                                    showOpenSourceLicenses = true
                                } label: {
                                    Label {
                                        Text("Open Source Licenses")
                                    } icon: {
                                        Image(systemName: "scroll")
                                            .foregroundStyle(.blue)
                                    }
                                }
                                .frame(maxWidth: .infinity, alignment: .leading)
                        .overlay(alignment: .trailing) { settingsRowChevron }
                                .tint(.primary)

                                Text("ForMemo uses ZXing-C++ for barcode and QR code scanning and generation.")
                                    .font(.footnote)
                                    .foregroundStyle(.secondary)
                            }
                            .sheet(isPresented: $showOpenSourceLicenses) {
                                OpenSourceLicensesView()
                            }

                        VStack(alignment: .leading, spacing: 6) {
                            Link(destination: URL(string: "https://open-meteo.com/")!) {
                                Label {
                                    Text("Weather Data")
                                        .tint(.blue)
                                } icon: {
                                    Image(systemName: "cloud.sun")
                                        .foregroundStyle(.blue)
                                }
                            }
//                            .foregroundStyle(.primary)

                            Text("Weather data provided by Open-Meteo.")
                                .font(.footnote)
                                .foregroundStyle(.secondary)
                        }
                    } header: {
                        Text("About")
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))

                    
                    
                    }
#if DEBUG
                    if selectedCategory == nil {
                    Section("Debug") {
                        Toggle("Always Generate", isOn: $debugKeepGenerateMode)
                        Button {
                            withAnimation(.none) {
                                if debugKeepGenerateMode {
                                    DebugTools.generateTasks(context: modelContext)
                                } else if !hasTestData {
                                    DebugTools.generateTasks(context: modelContext)
                                } else if !areTestTasksCompleted {
                                    DebugTools.completeTasks(context: modelContext)
                                } else {
                                    DebugTools.deleteTasks(context: modelContext)
                                }
                            }
                            hasTestData = DebugTools.hasTestTasks(context: modelContext)
                            areTestTasksCompleted = DebugTools.areTestTasksCompleted(context: modelContext)
                        } label: {
                            if debugKeepGenerateMode {
                                Text("Genera")
                            } else if !hasTestData {
                                Text("Genera")
                            } else if !areTestTasksCompleted {
                                Text("Completa")
                            } else {
                                Text("Elimina")
                            }
                        }
                        NavigationLink {
                            PerformanceBenchmarkView()
                        } label: {
                            Label("Performance Benchmark", systemImage: "speedometer")
                        }
                        NavigationLink {
                            DebugDiagnosticsView()
                        } label: {
                            Label("Diagnostica e test automatici", systemImage: "stethoscope")
                        }
                        
                        Button(role: .destructive) {
                            DebugTools.resetPreferences()
                            
                            UIApplication.shared.perform(#selector(NSXPCConnection.suspend))
                            
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                                exit(0)
                            }
                        } label: {
                            Text("Reset Preferences")
                                .foregroundStyle(.red)
                        }
                    }
                    .listRowBackground(Color(.systemBackground).opacity(0.3))
                    .onAppear {
                        hasTestData = DebugTools.hasTestTasks(context: modelContext)
                        areTestTasksCompleted = DebugTools.areTestTasksCompleted(context: modelContext)
                    }
                    }
#endif
                }
            }
            .listSectionSpacing(22)// spazio tra le sezioni
            .contentMargins(.top, 20, for: .scrollContent)//spazio tra navigationtitle e la prima sezione
            
            .contentMargins(.bottom, 70, for: .scrollContent)

            .scrollContentBackground(.hidden)
            .scrollEdgeEffectHidden(true, for: .top)
            .task {
                cleanupRecentlyDeleted()
                checkNotificationStatus()
            }
            .navigationTitle(selectedCategory?.title ?? String(localized: "Settings"))

            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                if selectedCategory != nil {
                    ToolbarItem(placement: .topBarLeading) {
                        Button {
                            withAnimation(.snappy) { selectedCategory = nil }
                        } label: {
                            Label("Settings", systemImage: "chevron.left")
                        }
                    }
                }
            }
            .onAppear {
                checkNotificationStatus()
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active {
                    checkNotificationStatus()
                    cleanupRecentlyDeleted()
                    syncLocationPermission()
                    syncVaultWithAutoFill()
                }
            }
            .onReceive(
                NotificationCenter.default.publisher(
                    for: .locationPermissionChanged
                )
            ) { _ in
                syncLocationPermission()
            }
            .fullScreenCover(item: $soundPickerContext) { context in
                NotificationSoundPickerView(context: context)
            }
            .fullScreenCover(isPresented: $showQuickGuide) {
                AppQuickGuideView()
            }
            .fullScreenCover(isPresented: $showFAQ) {
                NavigationStack {
                    FAQView()
                }
            }
            .fullScreenCover(isPresented: $showDataManagement) {
                ResetAppView()
            }
            .fullScreenCover(isPresented: $showCustomizationView) {
                NavigationStack {TaskListAppearanceView()}
            }
            .fullScreenCover(isPresented: $showSiri) {
                NavigationStack {
                    ShortList()
                }
            }
            .fullScreenCover(isPresented: $showImportReminders) {
                RemindersImportView()
            }
            .fullScreenCover(isPresented: $showRecentlyDeleted) {
                NavigationStack {
                    RecentlyDeletedView()
                }
            }
            .id(backgroundColor1Hex + backgroundColor2Hex)
        }
        
    }
    // MARK: - Helpers
    private func syncLocationPermission() {
        let status = CLLocationManager().authorizationStatus

        locationAuthorizationStatus = status

        let hasPermission =
            status == .authorizedAlways
        settings.locationRemindersEnabled = hasPermission

        let hasWeatherPermission =
            status == .authorizedAlways || status == .authorizedWhenInUse
        if !hasWeatherPermission {
            settings.showWeatherForecast = false
            WeatherManager.shared.locationPermissionWasRevoked()
        }
    }
    
    private func handleLocationReminderToggle(_ newValue: Bool) {

        if !newValue {
            settings.locationRemindersEnabled = false
            return
        }

        let status = CLLocationManager().authorizationStatus

        switch status {

        case .authorizedAlways:
            settings.locationRemindersEnabled = true

        case .notDetermined:
            LocationReminderManager.shared.requestPermissionIfNeeded()
            settings.locationRemindersEnabled = false

        case .authorizedWhenInUse:
            showLocationPermissionAlert = true
            settings.locationRemindersEnabled = false

        case .denied, .restricted:
            showLocationPermissionAlert = true
            settings.locationRemindersEnabled = false

        @unknown default:
            settings.locationRemindersEnabled = false
        }
    }
    
    
    private func openNotificationSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }
    private func openLanguageSettings() {
        if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
        }
    }

    @MainActor
    private func cleanupRecentlyDeleted() {
        let cleanupStart = Date()
        DebugLog.writeAttachmentEvent("")
        DebugLog.writeAttachmentEvent("════════════════════════════════════")
        DebugLog.writeAttachmentEvent("SETTINGS CLEANUP START")

        guard let cutoff = Calendar.current.date(
            byAdding: .day,
            value: -recentlyDeletedRetentionDays,
            to: .now
        ) else {
            return
        }

        DebugLog.writeAttachmentEvent("Retention policy applied")
        DebugLog.writeAttachmentEvent("Cleanup cutoff calculated")

        let descriptor = FetchDescriptor<DeletedItem>(
            predicate: #Predicate { $0.deletedAt <= cutoff }
        )

        guard let items = try? modelContext.fetch(descriptor) else {
            return
        }

        DebugLog.writeAttachmentEvent(
            "Expired deleted items detected: \(items.count)"
        )

        let loopStart = Date()

        for item in items {

            if let trashName = item.trashFileName {

                let trashURL: URL?

                switch item.type {

                case "attachment":
                    trashURL = TaskAttachment.trashFileURL(
                        trashFileName: trashName
                    )

                case "walletAsset":
                    trashURL = WalletAssetStore.trashFileURL(
                        trashFileName: trashName
                    )

                case "documentAsset":
                    trashURL = DocumentAssetStore.trashFileURL(
                        trashFileName: trashName
                    )

                default:
                    trashURL = nil
                }

                if let trashURL {
                    DebugLog.writeAttachmentEvent(
                        "Removing expired trash asset"
                    )

                    try? FileManager.default.removeItem(
                        at: trashURL
                    )
                }
            }

            modelContext.delete(item)
        }

        DebugLog.writeAttachmentEvent(
            "Cleanup loop completed: \(String(format: "%.3f", Date().timeIntervalSince(loopStart))) s"
        )

        let saveStart = Date()
        
        try? modelContext.save()
        
        DebugLog.writeAttachmentEvent(
            "Cleanup save completed: \(String(format: "%.3f", Date().timeIntervalSince(saveStart))) s"
        )

        DebugLog.writeAttachmentEvent(
            "SETTINGS CLEANUP TOTAL: \(String(format: "%.3f", Date().timeIntervalSince(cleanupStart))) s"
        )
    }



    private func syncVaultWithAutoFill() {
        ASCredentialIdentityStore.shared.getState { state in
            Task { @MainActor in
                if state.isEnabled {
                    settings.showVault = true
                }
            }
        }
    }
    
}

// MARK: - Tab Visibility Settings
struct TabVisibilitySettingsView: View {
    @Environment(AppSettings.self) private var settings
    @Environment(\.dismiss) private var dismiss
    @State private var showWeatherPermissionAlert = false
    @State private var showAutoFillDisableAlert = false
    @State private var showStartupTabVisibilityAlert = false
    @State private var startupTabVisibilityAlertName = ""

    private let iconWidth: CGFloat = 28

    var body: some View {
        List {
            Section {
                startupProtectedToggle(tag: AppTab.dashboard.rawValue) {
                    Toggle(isOn: Binding(
                        get: { settings.showDashboardTab },
                        set: { updateTabVisibility($0, tag: AppTab.dashboard.rawValue) { settings.showDashboardTab = $0 } }
                    )) {
                        tabLabel("Dashboard", icon: "rectangle.grid.3x1")
                    }
                }

                startupProtectedToggle(tag: AppTab.today.rawValue) {
                    Toggle(isOn: Binding(
                        get: { settings.showWeekTab },
                        set: { updateTabVisibility($0, tag: AppTab.today.rawValue) { settings.showWeekTab = $0 } }
                    )) {
                        Label {
                            Text(settings.taskWeekDays == 1
                                 ? String(localized: "today_tab")
                                 : String(localized: "\(settings.taskWeekDays) days_tab"))
                        } icon: {
                            Image(systemName: "calendar.day.timeline.right")
                                .foregroundStyle(.blue)
                                .frame(width: iconWidth)
                        }
                    }
                }

                startupProtectedToggle(tag: AppTab.map.rawValue) {
                    Toggle(isOn: Binding(
                        get: { settings.showMapTab },
                        set: { updateTabVisibility($0, tag: AppTab.map.rawValue) { settings.showMapTab = $0 } }
                    )) {
                        tabLabel("Map", icon: "map")
                    }
                }

                startupProtectedToggle(tag: AppTab.tasks.rawValue) {
                    Toggle(isOn: Binding(
                        get: { settings.showTasksTab },
                        set: { updateTabVisibility($0, tag: AppTab.tasks.rawValue) { settings.showTasksTab = $0 } }
                    )) {
                        tabLabel("Task", icon: "checklist")
                    }
                }

                startupProtectedToggle(tag: AppTab.agenda.rawValue) {
                    Toggle(isOn: Binding(
                        get: { settings.showDayTab },
                        set: { updateTabVisibility($0, tag: AppTab.agenda.rawValue) { settings.showDayTab = $0 } }
                    )) {
                        tabLabel("Agenda", icon: "book.pages")
                    }
                }

                startupProtectedToggle(tag: AppTab.forecast.rawValue) {
                    Toggle(isOn: Binding(
                        get: { settings.showWeatherForecast },
                        set: { updateTabVisibility($0, tag: AppTab.forecast.rawValue) { updateWeatherVisibility(to: $0) } }
                    )) {
                        tabLabel("Weather Forecast", icon: "cloud.sun")
                    }
                    .alert("Location Access Required", isPresented: $showWeatherPermissionAlert) {
                        Button("Open Settings") {
                            if let url = URL(string: UIApplication.openSettingsURLString) {
                                UIApplication.shared.open(url)
                            }
                        }
                        Button("Cancel", role: .cancel) {}
                    } message: {
                        Text("Weather Forecast requires location access. Enable location access in Settings, then return to ForMemo to turn it on.")
                    }
                }

                startupProtectedToggle(tag: AppTab.vault.rawValue) {
                    Toggle(isOn: Binding(
                        get: { settings.showVault },
                        set: { updateTabVisibility($0, tag: AppTab.vault.rawValue) { updateVaultVisibility(to: $0) } }
                    )) {
                        tabLabel("Vault", icon: "key.shield")
                    }
                    .alert("Disable AutoFill first", isPresented: $showAutoFillDisableAlert) {
                        Button("OK", role: .cancel) {}
                    } message: {
                        Text("To hide the Vault, first go to Settings > General > AutoFill & Passwords and turn off AutoFill Passwords and Passkeys. Then return here and turn off Vault.")
                    }
                }

                Toggle(isOn: Binding(
                    get: { settings.showSearchTab },
                    set: { settings.showSearchTab = $0 }
                )) {
                    tabLabel("Search", icon: "magnifyingglass")
                }
            } header: {
                Text("Tabs")
            } footer: {
                Text("Choose which tabs are shown in the navigation bar and More menu.")
            }
        }
        .alert("Startup Tab Cannot Be Hidden", isPresented: $showStartupTabVisibilityAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            if settings.startupTab == -1 {
                Text("\(startupTabVisibilityAlertName) can be opened automatically at launch. Choose a specific startup tab in General before hiding it.")
            } else {
                Text("\(startupTabVisibilityAlertName) is set as the startup tab. Choose another startup tab in General before hiding it.")
            }
        }
        .scrollContentBackground(.hidden)
        .background { AppGlassBackground() }
        .navigationTitle("Tab Visibility")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .confirmationAction) {
                Button("Done") { dismiss() }
            }
        }
    }

    @ViewBuilder
    private func startupProtectedToggle<Content: View>(
        tag: Int,
        @ViewBuilder content: () -> Content
    ) -> some View {
        let isStartupTab = isStartupProtected(tag)
        ZStack {
            content()
                .disabled(isStartupTab)
                .opacity(isStartupTab ? 0.55 : 1)

            if isStartupTab {
                Button {
                    startupTabVisibilityAlertName = startupTabName(for: tag)
                    showStartupTabVisibilityAlert = true
                } label: {
                    Color.clear
                        .contentShape(Rectangle())
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(Text("\(startupTabName(for: tag)) is the startup tab"))
            }
        }
    }

    private func tabLabel(_ title: LocalizedStringKey, icon: String) -> some View {
        Label {
            Text(title)
        } icon: {
            Image(systemName: icon)
                .foregroundStyle(.blue)
                .frame(width: iconWidth)
        }
    }

    private func isStartupProtected(_ tag: Int) -> Bool {
        if settings.startupTab == tag {
            return true
        }

        // Automatic startup chooses Dashboard when content exists, otherwise List.
        // Keep both possible destinations visible until a specific startup tab is selected.
        return settings.startupTab == -1
            && (tag == AppTab.dashboard.rawValue || tag == AppTab.tasks.rawValue)
    }

    private func updateTabVisibility(_ newValue: Bool, tag: Int, apply: (Bool) -> Void) {
        if !newValue && isStartupProtected(tag) {
            startupTabVisibilityAlertName = startupTabName(for: tag)
            showStartupTabVisibilityAlert = true
            return
        }
        apply(newValue)
    }

    private func startupTabName(for tag: Int) -> String {
        switch tag {
        case AppTab.dashboard.rawValue: return String(localized: "Dashboard")
        case AppTab.tasks.rawValue: return String(localized: "Task")
        case AppTab.today.rawValue: return String(localized: "\(settings.taskWeekDays) days")
        case AppTab.map.rawValue: return String(localized: "Map")
        case AppTab.agenda.rawValue: return String(localized: "Agenda")
        case AppTab.forecast.rawValue: return String(localized: "Weather Forecast")
        case AppTab.vault.rawValue: return String(localized: "Vault")
        default: return String(localized: "Tab")
        }
    }

    private func updateWeatherVisibility(to isVisible: Bool) {
        guard isVisible else {
            settings.showWeatherForecast = false
            WeatherManager.shared.disableForecast()
            return
        }

        let status = CLLocationManager().authorizationStatus
        let hasWeatherPermission = status == .authorizedAlways || status == .authorizedWhenInUse
        guard hasWeatherPermission else {
            settings.showWeatherForecast = false
            WeatherManager.shared.disableForecast()
            showWeatherPermissionAlert = true
            return
        }

        settings.showWeatherForecast = true
        Task { await WeatherManager.shared.refresh() }
    }

    private func updateVaultVisibility(to isVisible: Bool) {
        guard !isVisible else {
            settings.showVault = true
            return
        }

        ASCredentialIdentityStore.shared.getState { state in
            Task { @MainActor in
                if state.isEnabled {
                    showAutoFillDisableAlert = true
                } else {
                    settings.showVault = false
                }
            }
        }
    }
}

// MARK: - App Theme
enum AppTheme: Int, CaseIterable, Identifiable {
    case system = 0, light = 1, dark = 2
    var id: Int { rawValue }
    var description: String {
        switch self {
        case .system: return String(localized: "System")
        case .light: return String(localized: "Light")
        case .dark: return String(localized: "Dark")
        }
    }
}

extension AppTheme {
    var colorScheme: ColorScheme? {
        switch self {
        case .system: return nil
        case .light: return .light
        case .dark: return .dark
        }
    }
}
