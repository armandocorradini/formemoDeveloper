import SwiftUI
import Observation

enum AppBackgroundStyle: String, Codable {
    case system
    case gradient
    case theme
}

enum AppBackgroundPattern: String, Codable {
    case none
    case time
    case essential
    case organizer
    case geometric
    case notes
    case flow
    case minimal
    case balanced
    case dense
    case packed
    case saturated
    case sea
    case mountain
    case countryside
    case space
    case solarsystem
    case blackhole
    case pets
    case alice
    case love
    
    var assetName: String? {
        switch self {
        case .none:
            return nil
        case .time:
            return "TimePattern"
        case .essential:
            return "EssentialPattern"
        case .organizer:
            return "OrganizerPattern"
        case .geometric:
            return "GeometricPattern"
        case .notes:
            return "NotesPattern"
        case .flow:
            return "FlowPattern"
        case .minimal:
            return "MinimalPattern"
        case .balanced:
            return "BalancedPattern"
        case .dense:
            return "DensePattern"
        case .packed:
            return "PackedPattern"
        case .saturated:
            return "SaturatedPattern"
        case .sea:
            return "SeaPattern"
        case .mountain:
            return "MountainPattern"
        case .countryside:
            return "CountrysidePattern"
        case .space:
            return "SpacePattern"
        case .solarsystem:
            return "SolarSystemPattern"
        case .blackhole:
            return "BlackHolePattern"
        case .pets:
            return "PetsPattern"
        case .alice:
            return "AlicePattern"
        case .love:
            return "LovePattern"
        }
    }

    var localizedName: String {
        switch self {
        case .none:
            return String(localized: "None")
        case .time:
            return String(localized: "Time")
        case .essential:
            return String(localized: "Essential")
        case .organizer:
            return String(localized: "Organizer")
        case .geometric:
            return String(localized: "Geometric")
        case .notes:
            return String(localized: "Notes")
        case .flow:
            return String(localized: "Flow")
        case .minimal:
            return String(localized: "Minimal")
        case .balanced:
            return String(localized: "Balanced")
        case .dense:
            return String(localized: "Dense")
        case .packed:
            return String(localized: "Packed")
        case .saturated:
            return String(localized: "Saturated")
        case .sea:
            return String(localized: "Sea")
        case .mountain:
            return String(localized: "Mountain")
        case .countryside:
            return String(localized: "Countryside")
        case .space:
            return String(localized: "Space")
        case .solarsystem:
            return String(localized: "Solar System")
        case .blackhole:
            return String(localized: "Black Hole")
        case .pets:
            return String(localized: "Pets")
        case .alice:
            return String(localized: "Alice")
        case .love:
            return String(localized: "Love")
        }
    }
}


enum WalletViewStyle: String, Codable {
    case list
    case cards
}

@Observable
@MainActor
final class AppSettings {
    
    static let shared = AppSettings()
    
    private let backupExcludedKeys: Set<String> = [
        "deletedTaskFingerprints",
        "deletedRecurrenceOccurrences",
        "deletedRecurrenceFutureOccurrences"
    ]
    
    func exportSettings() -> [String: Any] {
        
        let dictionary = UserDefaults.standard.dictionaryRepresentation()
        
        return dictionary.filter { key, _ in
            !backupExcludedKeys.contains(key)
        }
    }
    
    func importSettings(from dictionary: [String: Any]) {
        
        let defaults = UserDefaults.standard
        
        for (key, value) in dictionary {
            guard !backupExcludedKeys.contains(key) else {
                continue
            }
            
            defaults.set(value, forKey: key)
        }
        
        defaults.synchronize()
        reloadFromUserDefaults()
    }

    @MainActor
    private func loadFromUserDefaults(_ defaults: UserDefaults) {
        iconStyle = TaskIconStyle(
            rawValue: defaults.string(forKey: TaskListAppearanceKeys.iconStyle) ?? ""
        ) ?? .polychrome

        showBadge = defaults.object(forKey: TaskListAppearanceKeys.showBadge) as? Bool ?? true
        showAttachments = defaults.object(forKey: TaskListAppearanceKeys.showAttachments) as? Bool ?? true
        showLocation = defaults.object(forKey: TaskListAppearanceKeys.showLocation) as? Bool ?? true
        showPriority = defaults.object(forKey: TaskListAppearanceKeys.showPriority) as? Bool ?? true
        showBadgeOnlyWithPriority = defaults.object(forKey: TaskListAppearanceKeys.showBadgeOnlyWithPriority) as? Bool ?? true
        highlightEnabled = defaults.object(forKey: "tasklist.highlightEnabled") as? Bool ?? true
        highlightColorHex = defaults.string(forKey: "tasklist.highlightColor") ?? (Color.red.toHex() ?? "")
        
        tabBarCustomizationIconColorHex =
            defaults.string(forKey: "tabBarCustomizationIconColor") ?? (Color.blue.toHex() ?? "")
        
        showTodayExpiredLabel = defaults.object(forKey: TaskListAppearanceKeys.showTodayExpiredLabel) as? Bool ?? true
        selectedTaskRowStyle = defaults.object(forKey: "selectedTaskRowStyle") as? Int ?? 0
        surfaceCornerRadius = defaults.object(forKey: "surfaceCornerRadius") as? Double ?? 22

        surfaceBorder = SurfaceBorderStyle(
            rawValue: defaults.integer(forKey: "surfaceBorder")
        ) ?? .hairline

        surfaceMaterial = SurfaceMaterialStyle(
            rawValue: defaults.integer(forKey: "surfaceMaterial")
        ) ?? .standard
        
        taskRowVerticalPadding = defaults.object(forKey: "taskRowVerticalPadding") as? Double ?? 0
        
        
        dueIconEffectRaw = defaults.string(forKey: "dueIconEffect") ?? DueIconEffect.blink.rawValue
        
        let rawValue = defaults.string(forKey: "TaskListStyle")
        taskListStyle = TaskListStyle(rawValue: rawValue ?? TaskListStyle.grouped.rawValue) ?? .plain
        
        let walletViewRawValue = defaults.string(forKey: "WalletViewStyle")
        walletViewStyle = WalletViewStyle(
            rawValue: walletViewRawValue ?? WalletViewStyle.cards.rawValue
        ) ?? .cards
        
        let savedTimelineInterval = defaults.object(forKey: "dayTimelineIntervalMinutes") as? Int ?? 30
        dayTimelineIntervalMinutes = [30, 60, 120, 180].contains(savedTimelineInterval) ? savedTimelineInterval : 30
        dayEmptySlotHeight = defaults.object(forKey: "dayEmptySlotHeight") as? Double ?? 24
        dayHideEmptyNightHours = defaults.object(forKey: "dayHideEmptyNightHours") as? Bool ?? false
        dayHideCompletedTasks = defaults.object(forKey: "dayHideCompletedTasks") as? Bool ?? true
        calendarHideCompletedTasks = defaults.object(forKey: "calendarHideCompletedTasks") as? Bool ?? true
        showDateEveryRow = defaults.object(forKey: "TaskListShowDateEveryRow") as? Bool ?? false
        confirmTaskDeletion = defaults.object(forKey: "confirmTaskDeletion") as? Bool ?? true
        taskWeekDays = defaults.object(forKey: "TaskWeekDays") as? Int ?? 3
        startupTab = defaults.object(forKey: "startupTab") as? Int ?? 1
        notificationLeadTimeDays = defaults.object(forKey: "notificationLeadTimeDays") as? Int ?? 1
        showWeatherForecast = defaults.object(forKey: "showWeatherForecast") as? Bool ?? true
        tabOrder = Self.normalizedTabOrder(
            defaults.array(forKey: "tabOrder") as? [Int] ?? AppTab.defaultOrder.map(\.rawValue)
        )
        
        showVault = defaults.object(forKey: "showVault") as? Bool ?? true
        showDashboardTab = defaults.object(forKey: "showDashboardTab") as? Bool ?? true
        showSearchTab = defaults.object(forKey: "showSearchTab") as? Bool ?? true
        let savedTabBarVisibleItemCount = defaults.object(forKey: "tabBarVisibleItemCount") as? Int ?? 5
        tabBarVisibleItemCount = [5, 6, 7].contains(savedTabBarVisibleItemCount)
            ? savedTabBarVisibleItemCount
            : 5
        showWeekTab = defaults.object(forKey: "showWeekTab") as? Bool ?? true
        showMapTab = defaults.object(forKey: "showMapTab") as? Bool ?? true
        showTasksTab = defaults.object(forKey: "showTasksTab") as? Bool ?? true
        showDayTab = defaults.object(forKey: "showDayTab") as? Bool ?? true
        
        showDashboardTomorrow = defaults.object(forKey: "showDashboardTomorrow") as? Bool ?? true
        showDashboardContinue = defaults.object(forKey: "showDashboardContinue") as? Bool ?? true
        siriAutoReminderEnabled = defaults.object(forKey: "siriAutoReminderEnabled") as? Bool ?? true
        navigationAppID = defaults.string(forKey: "navigationApp") ?? "apple"
        backgroundStyle = AppBackgroundStyle(
            rawValue: defaults.string(forKey: "backgroundStyle") ?? ""
        ) ?? .gradient

        backgroundColor1Hex = defaults.string(forKey: "backgroundColor1Hex") ?? (defaultBackColor1.toHex() ?? "")
        backgroundColor2Hex = defaults.string(forKey: "backgroundColor2Hex") ?? (defaultBackColor2.toHex() ?? "")
        backgroundPattern = AppBackgroundPattern(
            rawValue: defaults.string(forKey: "backgroundPattern") ?? ""
        ) ?? .none
        backgroundPatternOpacity =
            defaults.object(forKey: "backgroundPatternOpacity") as? Double ?? 0.025
        badgeMode = defaults.object(forKey: "badgeMode") as? Int ?? 1
        showAppBadge = defaults.object(forKey: "showAppBadge") as? Bool ?? true
        selectedTheme = AppTheme(rawValue: defaults.integer(forKey: "selectedTheme")) ?? .system
        maximumOccurrencesPerOperation = RecurrenceGenerationConfiguration.maximumOccurrencesPerOperation
        confirmationThreshold = RecurrenceGenerationConfiguration.confirmationThreshold
        autoDeleteCompletedAttachments = defaults.object(forKey: "autoDeleteCompletedAttachments") as? Bool ?? true
        attachmentRetentionDays = defaults.object(forKey: "attachmentRetentionDays") as? Int ?? 30
        recentlyDeletedRetentionDays = defaults.object(forKey: "recentlyDeletedRetentionDays") as? Int ?? 30
        locationRemindersEnabled = defaults.object(forKey: "locationRemindersEnabled") as? Bool ?? false
        locationRadius = defaults.object(forKey: "locationRadius") as? Int ?? 150
        vaultAutoLockInterval = defaults.object(forKey: "vaultAutoLockInterval") as? Int ?? 120
        vaultClipboardClearInterval = defaults.object(forKey: "vaultClipboardClearInterval") as? Int ?? 90
//        vaultRequireFaceID = defaults.object(forKey: "vaultRequireFaceID") as? Bool ?? true
        vaultAutoHidePasswords = defaults.object(forKey: "vaultAutoHidePasswords") as? Bool ?? true
    }

    @MainActor
    func reloadFromUserDefaults() {
        let defaults = UserDefaults.standard
        loadFromUserDefaults(defaults)
    }
    
    // MARK: - Day View alias Agenda

    var dayTimelineIntervalMinutes: Int {
        didSet {
            let normalized = [30, 60, 120, 180].contains(dayTimelineIntervalMinutes) ? dayTimelineIntervalMinutes : 30
            if dayTimelineIntervalMinutes != normalized {
                dayTimelineIntervalMinutes = normalized
                return
            }
            UserDefaults.standard.set(dayTimelineIntervalMinutes, forKey: "dayTimelineIntervalMinutes")
        }
    }

    var dayEmptySlotHeight: Double {
        didSet {
            let normalized = min(max(dayEmptySlotHeight, 44), 80)
            if dayEmptySlotHeight != normalized {
                dayEmptySlotHeight = normalized
                return
            }
            UserDefaults.standard.set(dayEmptySlotHeight, forKey: "dayEmptySlotHeight")
        }
    }

    var dayHideEmptyNightHours: Bool {
        didSet {
            UserDefaults.standard.set(dayHideEmptyNightHours, forKey: "dayHideEmptyNightHours")
        }
    }

    var dayHideCompletedTasks: Bool {
        didSet {
            UserDefaults.standard.set(dayHideCompletedTasks, forKey: "dayHideCompletedTasks")
        }
    }

    var calendarHideCompletedTasks: Bool {
        didSet {
            UserDefaults.standard.set(calendarHideCompletedTasks, forKey: "calendarHideCompletedTasks")
        }
    }

    // MARK: - Task List Appearance
    
    var iconStyle: TaskIconStyle {
        didSet {
            UserDefaults.standard.set(
                iconStyle.rawValue,
                forKey: TaskListAppearanceKeys.iconStyle
            )
        }
    }
    
    var showBadge: Bool {
        didSet {
            UserDefaults.standard.set(
                showBadge,
                forKey: TaskListAppearanceKeys.showBadge
            )
        }
    }
    
    var showAttachments: Bool {
        didSet {
            UserDefaults.standard.set(
                showAttachments,
                forKey: TaskListAppearanceKeys.showAttachments
            )
        }
    }
    
    var showLocation: Bool {
        didSet {
            UserDefaults.standard.set(
                showLocation,
                forKey: TaskListAppearanceKeys.showLocation
            )
        }
    }
    
    var showPriority: Bool {
        didSet {
            UserDefaults.standard.set(
                showPriority,
                forKey: TaskListAppearanceKeys.showPriority
            )
        }
    }
    
    var showBadgeOnlyWithPriority: Bool {
        didSet {
            UserDefaults.standard.set(
                showBadgeOnlyWithPriority,
                forKey: TaskListAppearanceKeys.showBadgeOnlyWithPriority
            )
        }
    }
    
    var highlightEnabled: Bool {
        didSet {
            UserDefaults.standard.set(
                highlightEnabled,
                forKey: "tasklist.highlightEnabled"
            )
        }
    }
    
    var highlightColorHex: String {
        didSet {
            UserDefaults.standard.set(
                highlightColorHex,
                forKey: "tasklist.highlightColor"
            )
        }
    }
    
    var tabBarCustomizationIconColorHex: String {
        didSet {
            UserDefaults.standard.set(
                tabBarCustomizationIconColorHex,
                forKey: "tabBarCustomizationIconColor"
            )
        }
    }
    
    var showTodayExpiredLabel: Bool {
        didSet {
            UserDefaults.standard.set(
                showTodayExpiredLabel,
                forKey: TaskListAppearanceKeys.showTodayExpiredLabel
            )
        }
    }
    
    var selectedTaskRowStyle: Int {
        didSet {
            UserDefaults.standard.set(
                selectedTaskRowStyle,
                forKey: "selectedTaskRowStyle"
            )
        }
    }
    
    var surfaceCornerRadius: Double {
        didSet {
            UserDefaults.standard.set(
                surfaceCornerRadius,
                forKey: "surfaceCornerRadius"
            )
        }
    }

    var surfaceBorder: SurfaceBorderStyle {
        didSet {
            UserDefaults.standard.set(
                surfaceBorder.rawValue,
                forKey: "surfaceBorder"
            )
        }
    }

    var surfaceMaterial: SurfaceMaterialStyle {
        didSet {
            UserDefaults.standard.set(
                surfaceMaterial.rawValue,
                forKey: "surfaceMaterial"
            )
        }
    }
    var taskRowVerticalPadding: Double {
        didSet {
            UserDefaults.standard.set(
                taskRowVerticalPadding,
                forKey: "taskRowVerticalPadding"
            )
        }
    }
    var dueIconEffectRaw: String {
        didSet {
            UserDefaults.standard.set(
                dueIconEffectRaw,
                forKey: "dueIconEffect"
            )
        }
    }
    var dueIconEffect: DueIconEffect {
        get {
            DueIconEffect(rawValue: dueIconEffectRaw) ?? .blink
        }
        set {
            dueIconEffectRaw = newValue.rawValue
        }
    }
    
    var taskListStyle: TaskListStyle {
        didSet {
            UserDefaults.standard.set(
                taskListStyle.rawValue,
                forKey: "TaskListStyle"
            )
        }
    }
    
    var walletViewStyle: WalletViewStyle {
        didSet {
            UserDefaults.standard.set(
                walletViewStyle.rawValue,
                forKey: "WalletViewStyle"
            )
        }
    }
    
    var showDateEveryRow: Bool {
        didSet {
            UserDefaults.standard.set(
                showDateEveryRow,
                forKey: "TaskListShowDateEveryRow"
            )
        }
    }
    
    var confirmTaskDeletion: Bool {
        didSet {
            UserDefaults.standard.set(
                confirmTaskDeletion,
                forKey: "confirmTaskDeletion"
            )
        }
    }

    
    var taskWeekDays: Int {
        didSet {
            UserDefaults.standard.set(
                taskWeekDays,
                forKey: "TaskWeekDays"
            )
        }
    }
    
    var startupTab: Int {
        didSet {
            UserDefaults.standard.set(
                startupTab,
                forKey: "startupTab"
            )
        }
    }
    
    
    //migrato
    var notificationLeadTimeDays: Int {
        didSet {
            UserDefaults.standard.set(
                notificationLeadTimeDays,
                forKey: "notificationLeadTimeDays"
            )
        }
    }
    
    var showWeatherForecast: Bool {
        didSet {
            UserDefaults.standard.set(
                showWeatherForecast,
                forKey: "showWeatherForecast"
            )
        }
    }

    var showVault: Bool {
        didSet {
            UserDefaults.standard.set(
                showVault,
                forKey: "showVault"
            )
        }
    }
    
    var showDashboardTab: Bool {
        didSet { UserDefaults.standard.set(showDashboardTab, forKey: "showDashboardTab") }
    }

    var showSearchTab: Bool {
        didSet { UserDefaults.standard.set(showSearchTab, forKey: "showSearchTab") }
    }

    var showWeekTab: Bool {
        didSet { UserDefaults.standard.set(showWeekTab, forKey: "showWeekTab") }
    }

    var showMapTab: Bool {
        didSet { UserDefaults.standard.set(showMapTab, forKey: "showMapTab") }
    }

    var showTasksTab: Bool {
        didSet { UserDefaults.standard.set(showTasksTab, forKey: "showTasksTab") }
    }

    var showDayTab: Bool {
        didSet { UserDefaults.standard.set(showDayTab, forKey: "showDayTab") }
    }

    var showDashboardTomorrow: Bool {
        didSet {
            UserDefaults.standard.set(
                showDashboardTomorrow,
                forKey: "showDashboardTomorrow"
            )
        }
    }

    var showDashboardContinue: Bool {
        didSet {
            UserDefaults.standard.set(
                showDashboardContinue,
                forKey: "showDashboardContinue"
            )
        }
    }
    
    var siriAutoReminderEnabled: Bool {
        didSet {
            UserDefaults.standard.set(
                siriAutoReminderEnabled,
                forKey: "siriAutoReminderEnabled"
            )
        }
    }
    
    var navigationAppID: String {
        didSet {
            UserDefaults.standard.set(
                navigationAppID,
                forKey: "navigationApp"
            )
        }
    }
    
    var navigationApp: NavigationApp {
        get {
            NavigationApp.app(for: navigationAppID)
        }
        set {
            navigationAppID = newValue.id
        }
    }
    var backgroundStyle: AppBackgroundStyle {
        didSet {
            UserDefaults.standard.set(
                backgroundStyle.rawValue,
                forKey: "backgroundStyle"
            )
        }
    }
    
    var backgroundColor1Hex: String {
        didSet {
            UserDefaults.standard.set(
                backgroundColor1Hex,
                forKey: "backgroundColor1Hex"
            )
        }
    }
    
    var backgroundColor2Hex: String {
        didSet {
            UserDefaults.standard.set(
                backgroundColor2Hex,
                forKey: "backgroundColor2Hex"
            )
        }
    }
    
    var backgroundPattern: AppBackgroundPattern {
        didSet {
            UserDefaults.standard.set(
                backgroundPattern.rawValue,
                forKey: "backgroundPattern"
            )
        }
    }
    
    var backgroundPatternOpacity: Double {
        didSet {
            UserDefaults.standard.set(
                backgroundPatternOpacity,
                forKey: "backgroundPatternOpacity"
            )
        }
    }
    
    var diagnosticAttachmentFailure = false
    
    var badgeMode: Int {
        didSet {
            UserDefaults.standard.set(
                badgeMode,
                forKey: "badgeMode"
            )
        }
    }
    
    var showAppBadge: Bool {
        didSet {
            UserDefaults.standard.set(
                showAppBadge,
                forKey: "showAppBadge"
            )
        }
    }
    
    var selectedTheme: AppTheme {
        didSet {
            UserDefaults.standard.set(
                selectedTheme.rawValue,
                forKey: "selectedTheme"
            )
        }
    }
    
    var maximumOccurrencesPerOperation: Int {
        didSet {
            let normalized = min(max(maximumOccurrencesPerOperation, 1), 1_000)
            if maximumOccurrencesPerOperation != normalized {
                maximumOccurrencesPerOperation = normalized
                return
            }
            RecurrenceGenerationConfiguration.setMaximumOccurrencesPerOperation(normalized)
            if confirmationThreshold > normalized {
                confirmationThreshold = normalized
            }
        }
    }

    var confirmationThreshold: Int {
        didSet {
            let normalized = min(max(confirmationThreshold, 1), maximumOccurrencesPerOperation)
            if confirmationThreshold != normalized {
                confirmationThreshold = normalized
                return
            }
            RecurrenceGenerationConfiguration.setConfirmationThreshold(normalized)
        }
    }

    var autoDeleteCompletedAttachments: Bool {
        didSet {
            UserDefaults.standard.set(
                autoDeleteCompletedAttachments,
                forKey: "autoDeleteCompletedAttachments"
            )
        }
    }
    
    var attachmentRetentionDays: Int {
        didSet {
            UserDefaults.standard.set(
                attachmentRetentionDays,
                forKey: "attachmentRetentionDays"
            )
        }
    }
    
    var recentlyDeletedRetentionDays: Int {
        didSet {
            UserDefaults.standard.set(
                recentlyDeletedRetentionDays,
                forKey: "recentlyDeletedRetentionDays"
            )
        }
    }
    
    var locationRemindersEnabled: Bool {
        didSet {
            UserDefaults.standard.set(
                locationRemindersEnabled,
                forKey: "locationRemindersEnabled"
            )
        }
    }
    
    var locationRadius: Int {
        didSet {
            UserDefaults.standard.set(
                locationRadius,
                forKey: "locationRadius"
            )
        }
    }

    var vaultAutoLockInterval: Int {
        didSet {
            UserDefaults.standard.set(vaultAutoLockInterval, forKey: "vaultAutoLockInterval")
        }
    }

    var vaultClipboardClearInterval: Int {
        didSet {
            UserDefaults.standard.set(vaultClipboardClearInterval, forKey: "vaultClipboardClearInterval")
        }
    }

    var vaultAutoHidePasswords: Bool {
        didSet {
            UserDefaults.standard.set(vaultAutoHidePasswords, forKey: "vaultAutoHidePasswords")
        }
    }

    var tabOrder: [Int] {
        didSet {
            UserDefaults.standard.set(tabOrder, forKey: "tabOrder")
        }
    }

    var tabBarVisibleItemCount: Int {
        didSet {
            let normalized = [5, 6, 7].contains(tabBarVisibleItemCount) ? tabBarVisibleItemCount : 5
            if tabBarVisibleItemCount != normalized {
                tabBarVisibleItemCount = normalized
                return
            }
            UserDefaults.standard.set(tabBarVisibleItemCount, forKey: "tabBarVisibleItemCount")
        }
    }

    var orderedTabs: [AppTab] {
        Self.normalizedTabOrder(tabOrder).compactMap(AppTab.init(rawValue:))
    }

    private static func normalizedTabOrder(_ order: [Int]) -> [Int] {
        let knownTabs = Set(AppTab.allCases.map(\.rawValue))
        let validOrder = order.filter(knownTabs.contains)
        let missingTabs = AppTab.defaultOrder.map(\.rawValue).filter { !validOrder.contains($0) }
        return validOrder + missingTabs
    }
    
    
    private init() {
        iconStyle = .polychrome
        showBadge = true
        showAttachments = true
        showLocation = true
        showPriority = true
        showBadgeOnlyWithPriority = true
        highlightEnabled = true
        highlightColorHex = Color.red.toHex() ?? ""
        tabBarCustomizationIconColorHex = Color.blue.toHex() ?? ""
        showTodayExpiredLabel = true
        selectedTaskRowStyle = 0
        surfaceCornerRadius = 22
        surfaceBorder = .hairline
        surfaceMaterial = .standard
        taskRowVerticalPadding = 0
        
        dueIconEffectRaw = DueIconEffect.blink.rawValue
        taskListStyle = .plain
        walletViewStyle = .cards
        dayTimelineIntervalMinutes = 30
        dayEmptySlotHeight = 24
        dayHideEmptyNightHours = false
        dayHideCompletedTasks = false
        calendarHideCompletedTasks = false
        showDateEveryRow = false
        confirmTaskDeletion = true
        taskWeekDays = 3
        startupTab = 1
        notificationLeadTimeDays = 1
        showWeatherForecast = true
        showVault = true
        showDashboardTab = true
        showSearchTab = true
        showWeekTab = true
        showMapTab = true
        showTasksTab = true
        showDayTab = true
        showDashboardTomorrow = true
        showDashboardContinue = true
        siriAutoReminderEnabled = true
        navigationAppID = "apple"
        backgroundStyle = .gradient
        backgroundColor1Hex = defaultBackColor1.toHex() ?? ""
        backgroundColor2Hex = defaultBackColor2.toHex() ?? ""
        backgroundPattern = .none
        backgroundPatternOpacity = 0.08
        badgeMode = 1
        showAppBadge = true
        selectedTheme = .system
        maximumOccurrencesPerOperation = RecurrenceGenerationConfiguration.defaultMaximumOccurrencesPerOperation
        confirmationThreshold = RecurrenceGenerationConfiguration.defaultConfirmationThreshold
        autoDeleteCompletedAttachments = true
        attachmentRetentionDays = 30
        recentlyDeletedRetentionDays = 30
        locationRemindersEnabled = false
        locationRadius = 150
        vaultAutoLockInterval = 120
        vaultClipboardClearInterval = 90
//        vaultRequireFaceID = true
        vaultAutoHidePasswords = true
        tabOrder = AppTab.defaultOrder.map(\.rawValue)
        tabBarVisibleItemCount = 5

        loadFromUserDefaults(.standard)
        
    }
}
