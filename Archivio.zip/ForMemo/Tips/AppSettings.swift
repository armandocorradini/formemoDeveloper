import SwiftUI
import Observation

enum AppBackgroundStyle: String, Codable {
    case system
    case gradient
    case theme
}

enum AppBackgroundPattern: String, Codable {
    case none
    case essential
    case organizer
    case geometric
    case notes
    case flow
    case minimal
    case balanced
    case dense
    case packed
    case saturated
    case sea
    case mountain
    case countryside
    case space
    
    var assetName: String? {
        switch self {
        case .none:
            return nil
        case .essential:
            return "EssentialPattern"
        case .organizer:
            return "OrganizerPattern"
        case .geometric:
            return "GeometricPattern"
        case .notes:
            return "NotesPattern"
        case .flow:
            return "FlowPattern"
        case .minimal:
            return "MinimalPattern"
        case .balanced:
            return "BalancedPattern"
        case .dense:
            return "DensePattern"
        case .packed:
            return "PackedPattern"
        case .saturated:
            return "SaturatedPattern"
        case .sea:
            return "SeaPattern"
        case .mountain:
            return "MountainPattern"
        case .countryside:
            return "CountrysidePattern"
        case .space:
            return "SpacePattern"
        }
    }

    var localizedName: String {
        switch self {
        case .none:
            return String(localized: "None")
        case .essential:
            return String(localized: "Essential")
        case .organizer:
            return String(localized: "Organizer")
        case .geometric:
            return String(localized: "Geometric")
        case .notes:
            return String(localized: "Notes")
        case .flow:
            return String(localized: "Flow")
        case .minimal:
            return String(localized: "Minimal")
        case .balanced:
            return String(localized: "Balanced")
        case .dense:
            return String(localized: "Dense")
        case .packed:
            return String(localized: "Packed")
        case .saturated:
            return String(localized: "Saturated")
        case .sea:
            return String(localized: "Sea")
        case .mountain:
            return String(localized: "Mountain")
        case .countryside:
            return String(localized: "Countryside")
        case .space:
            return String(localized: "Space")
        }
    }
}


enum WalletViewStyle: String, Codable {
    case list
    case cards
}

@Observable
@MainActor
final class AppSettings {
    
    static let shared = AppSettings()
    
    private let backupExcludedKeys: Set<String> = []
    
    func exportSettings() -> [String: Any] {
        
        let dictionary = UserDefaults.standard.dictionaryRepresentation()
        
        return dictionary.filter { key, _ in
            !backupExcludedKeys.contains(key)
        }
    }
    
    func importSettings(from dictionary: [String: Any]) {
        
        let defaults = UserDefaults.standard
        
        for (key, value) in dictionary {
            guard !backupExcludedKeys.contains(key) else {
                continue
            }
            
            defaults.set(value, forKey: key)
        }
        
        defaults.synchronize()
        reloadFromUserDefaults()
    }

    @MainActor
    private func loadFromUserDefaults(_ defaults: UserDefaults) {
        iconStyle = TaskIconStyle(
            rawValue: defaults.string(forKey: TaskListAppearanceKeys.iconStyle) ?? ""
        ) ?? .polychrome

        showBadge = defaults.object(forKey: TaskListAppearanceKeys.showBadge) as? Bool ?? true
        showAttachments = defaults.object(forKey: TaskListAppearanceKeys.showAttachments) as? Bool ?? true
        showLocation = defaults.object(forKey: TaskListAppearanceKeys.showLocation) as? Bool ?? true
        showPriority = defaults.object(forKey: TaskListAppearanceKeys.showPriority) as? Bool ?? true
        showBadgeOnlyWithPriority = defaults.object(forKey: TaskListAppearanceKeys.showBadgeOnlyWithPriority) as? Bool ?? true
        highlightEnabled = defaults.object(forKey: "tasklist.highlightEnabled") as? Bool ?? true
        highlightColorHex = defaults.string(forKey: "tasklist.highlightColor") ?? (Color.red.toHex() ?? "")
        
        tabBarCustomizationIconColorHex =
            defaults.string(forKey: "tabBarCustomizationIconColor") ?? (Color.blue.toHex() ?? "")
        
        showTodayExpiredLabel = defaults.object(forKey: TaskListAppearanceKeys.showTodayExpiredLabel) as? Bool ?? true
        selectedTaskRowStyle = defaults.object(forKey: "selectedTaskRowStyle") as? Int ?? 0
        surfaceCornerRadius = defaults.object(forKey: "surfaceCornerRadius") as? Double ?? 22

        surfaceBorder = SurfaceBorderStyle(
            rawValue: defaults.integer(forKey: "surfaceBorder")
        ) ?? .hairline

        surfaceMaterial = SurfaceMaterialStyle(
            rawValue: defaults.integer(forKey: "surfaceMaterial")
        ) ?? .standard
        
        taskRowVerticalPadding = defaults.object(forKey: "taskRowVerticalPadding") as? Double ?? 0
        
        
        dueIconEffectRaw = defaults.string(forKey: "dueIconEffect") ?? DueIconEffect.blink.rawValue
        
        let rawValue = defaults.string(forKey: "TaskListStyle")
        taskListStyle = TaskListStyle(rawValue: rawValue ?? TaskListStyle.grouped.rawValue) ?? .plain
        
        let walletViewRawValue = defaults.string(forKey: "WalletViewStyle")
        walletViewStyle = WalletViewStyle(
            rawValue: walletViewRawValue ?? WalletViewStyle.cards.rawValue
        ) ?? .cards
        
        showDateEveryRow = defaults.object(forKey: "TaskListShowDateEveryRow") as? Bool ?? false
        confirmTaskDeletion = defaults.object(forKey: "confirmTaskDeletion") as? Bool ?? true
        keepRecurringTaskHistory = defaults.object(
            forKey: "keepRecurringTaskHistory"
        ) as? Bool ?? true
        
        taskWeekDays = defaults.object(forKey: "TaskWeekDays") as? Int ?? 3
        startupTab = defaults.object(forKey: "startupTab") as? Int ?? 1
        notificationLeadTimeDays = defaults.object(forKey: "notificationLeadTimeDays") as? Int ?? 1
        showWeatherForecast = defaults.object(forKey: "showWeatherForecast") as? Bool ?? true
        tabOrder = Self.normalizedTabOrder(
            defaults.array(forKey: "tabOrder") as? [Int] ?? AppTab.defaultOrder.map(\.rawValue)
        )
        
        showVault = defaults.object(forKey: "showVault") as? Bool ?? true
        
        showDashboardTomorrow = defaults.object(forKey: "showDashboardTomorrow") as? Bool ?? true
        showDashboardContinue = defaults.object(forKey: "showDashboardContinue") as? Bool ?? true
        siriAutoReminderEnabled = defaults.object(forKey: "siriAutoReminderEnabled") as? Bool ?? true
        navigationAppID = defaults.string(forKey: "navigationApp") ?? "apple"
        backgroundStyle = AppBackgroundStyle(
            rawValue: defaults.string(forKey: "backgroundStyle") ?? ""
        ) ?? .gradient

        backgroundColor1Hex = defaults.string(forKey: "backgroundColor1Hex") ?? (defaultBackColor1.toHex() ?? "")
        backgroundColor2Hex = defaults.string(forKey: "backgroundColor2Hex") ?? (defaultBackColor2.toHex() ?? "")
        backgroundPattern = AppBackgroundPattern(
            rawValue: defaults.string(forKey: "backgroundPattern") ?? ""
        ) ?? .none
        backgroundPatternOpacity =
            defaults.object(forKey: "backgroundPatternOpacity") as? Double ?? 0.025
        badgeMode = defaults.object(forKey: "badgeMode") as? Int ?? 1
        showAppBadge = defaults.object(forKey: "showAppBadge") as? Bool ?? true
        selectedTheme = AppTheme(rawValue: defaults.integer(forKey: "selectedTheme")) ?? .system
        autoDeleteCompletedAttachments = defaults.object(forKey: "autoDeleteCompletedAttachments") as? Bool ?? true
        attachmentRetentionDays = defaults.object(forKey: "attachmentRetentionDays") as? Int ?? 30
        recentlyDeletedRetentionDays = defaults.object(forKey: "recentlyDeletedRetentionDays") as? Int ?? 30
        locationRemindersEnabled = defaults.object(forKey: "locationRemindersEnabled") as? Bool ?? false
        locationRadius = defaults.object(forKey: "locationRadius") as? Int ?? 150
        vaultAutoLockInterval = defaults.object(forKey: "vaultAutoLockInterval") as? Int ?? 120
        vaultClipboardClearInterval = defaults.object(forKey: "vaultClipboardClearInterval") as? Int ?? 90
//        vaultRequireFaceID = defaults.object(forKey: "vaultRequireFaceID") as? Bool ?? true
        vaultAutoHidePasswords = defaults.object(forKey: "vaultAutoHidePasswords") as? Bool ?? true
    }

    @MainActor
    func reloadFromUserDefaults() {
        let defaults = UserDefaults.standard
        loadFromUserDefaults(defaults)
    }
    
    // MARK: - Task List Appearance
    
    var iconStyle: TaskIconStyle {
        didSet {
            UserDefaults.standard.set(
                iconStyle.rawValue,
                forKey: TaskListAppearanceKeys.iconStyle
            )
        }
    }
    
    var showBadge: Bool {
        didSet {
            UserDefaults.standard.set(
                showBadge,
                forKey: TaskListAppearanceKeys.showBadge
            )
        }
    }
    
    var showAttachments: Bool {
        didSet {
            UserDefaults.standard.set(
                showAttachments,
                forKey: TaskListAppearanceKeys.showAttachments
            )
        }
    }
    
    var showLocation: Bool {
        didSet {
            UserDefaults.standard.set(
                showLocation,
                forKey: TaskListAppearanceKeys.showLocation
            )
        }
    }
    
    var showPriority: Bool {
        didSet {
            UserDefaults.standard.set(
                showPriority,
                forKey: TaskListAppearanceKeys.showPriority
            )
        }
    }
    
    var showBadgeOnlyWithPriority: Bool {
        didSet {
            UserDefaults.standard.set(
                showBadgeOnlyWithPriority,
                forKey: TaskListAppearanceKeys.showBadgeOnlyWithPriority
            )
        }
    }
    
    var highlightEnabled: Bool {
        didSet {
            UserDefaults.standard.set(
                highlightEnabled,
                forKey: "tasklist.highlightEnabled"
            )
        }
    }
    
    var highlightColorHex: String {
        didSet {
            UserDefaults.standard.set(
                highlightColorHex,
                forKey: "tasklist.highlightColor"
            )
        }
    }
    
    var tabBarCustomizationIconColorHex: String {
        didSet {
            UserDefaults.standard.set(
                tabBarCustomizationIconColorHex,
                forKey: "tabBarCustomizationIconColor"
            )
        }
    }
    
    var showTodayExpiredLabel: Bool {
        didSet {
            UserDefaults.standard.set(
                showTodayExpiredLabel,
                forKey: TaskListAppearanceKeys.showTodayExpiredLabel
            )
        }
    }
    
    var selectedTaskRowStyle: Int {
        didSet {
            UserDefaults.standard.set(
                selectedTaskRowStyle,
                forKey: "selectedTaskRowStyle"
            )
        }
    }
    
    var surfaceCornerRadius: Double {
        didSet {
            UserDefaults.standard.set(
                surfaceCornerRadius,
                forKey: "surfaceCornerRadius"
            )
        }
    }

    var surfaceBorder: SurfaceBorderStyle {
        didSet {
            UserDefaults.standard.set(
                surfaceBorder.rawValue,
                forKey: "surfaceBorder"
            )
        }
    }

    var surfaceMaterial: SurfaceMaterialStyle {
        didSet {
            UserDefaults.standard.set(
                surfaceMaterial.rawValue,
                forKey: "surfaceMaterial"
            )
        }
    }
    var taskRowVerticalPadding: Double {
        didSet {
            UserDefaults.standard.set(
                taskRowVerticalPadding,
                forKey: "taskRowVerticalPadding"
            )
        }
    }
    var dueIconEffectRaw: String {
        didSet {
            UserDefaults.standard.set(
                dueIconEffectRaw,
                forKey: "dueIconEffect"
            )
        }
    }
    var dueIconEffect: DueIconEffect {
        get {
            DueIconEffect(rawValue: dueIconEffectRaw) ?? .blink
        }
        set {
            dueIconEffectRaw = newValue.rawValue
        }
    }
    
    var taskListStyle: TaskListStyle {
        didSet {
            UserDefaults.standard.set(
                taskListStyle.rawValue,
                forKey: "TaskListStyle"
            )
        }
    }
    
    var walletViewStyle: WalletViewStyle {
        didSet {
            UserDefaults.standard.set(
                walletViewStyle.rawValue,
                forKey: "WalletViewStyle"
            )
        }
    }
    
    var showDateEveryRow: Bool {
        didSet {
            UserDefaults.standard.set(
                showDateEveryRow,
                forKey: "TaskListShowDateEveryRow"
            )
        }
    }
    
    var confirmTaskDeletion: Bool {
        didSet {
            UserDefaults.standard.set(
                confirmTaskDeletion,
                forKey: "confirmTaskDeletion"
            )
        }
    }
    
    var recurringTaskOptions: RecurringTaskOptions {
        RecurringTaskOptions(
            keepHistory: keepRecurringTaskHistory
        )
    }
    
    
    var keepRecurringTaskHistory: Bool {
        didSet {
            UserDefaults.standard.set(
                keepRecurringTaskHistory,
                forKey: "keepRecurringTaskHistory"
            )
        }
    }
    
    var taskWeekDays: Int {
        didSet {
            UserDefaults.standard.set(
                taskWeekDays,
                forKey: "TaskWeekDays"
            )
        }
    }
    
    var startupTab: Int {
        didSet {
            UserDefaults.standard.set(
                startupTab,
                forKey: "startupTab"
            )
        }
    }
    
    
    //migrato
    var notificationLeadTimeDays: Int {
        didSet {
            UserDefaults.standard.set(
                notificationLeadTimeDays,
                forKey: "notificationLeadTimeDays"
            )
        }
    }
    
    var showWeatherForecast: Bool {
        didSet {
            UserDefaults.standard.set(
                showWeatherForecast,
                forKey: "showWeatherForecast"
            )
        }
    }

    var showVault: Bool {
        didSet {
            UserDefaults.standard.set(
                showVault,
                forKey: "showVault"
            )
        }
    }
    
    var showDashboardTomorrow: Bool {
        didSet {
            UserDefaults.standard.set(
                showDashboardTomorrow,
                forKey: "showDashboardTomorrow"
            )
        }
    }

    var showDashboardContinue: Bool {
        didSet {
            UserDefaults.standard.set(
                showDashboardContinue,
                forKey: "showDashboardContinue"
            )
        }
    }
    
    var siriAutoReminderEnabled: Bool {
        didSet {
            UserDefaults.standard.set(
                siriAutoReminderEnabled,
                forKey: "siriAutoReminderEnabled"
            )
        }
    }
    
    var navigationAppID: String {
        didSet {
            UserDefaults.standard.set(
                navigationAppID,
                forKey: "navigationApp"
            )
        }
    }
    
    var navigationApp: NavigationApp {
        get {
            NavigationApp.app(for: navigationAppID)
        }
        set {
            navigationAppID = newValue.id
        }
    }
    var backgroundStyle: AppBackgroundStyle {
        didSet {
            UserDefaults.standard.set(
                backgroundStyle.rawValue,
                forKey: "backgroundStyle"
            )
        }
    }
    
    var backgroundColor1Hex: String {
        didSet {
            UserDefaults.standard.set(
                backgroundColor1Hex,
                forKey: "backgroundColor1Hex"
            )
        }
    }
    
    var backgroundColor2Hex: String {
        didSet {
            UserDefaults.standard.set(
                backgroundColor2Hex,
                forKey: "backgroundColor2Hex"
            )
        }
    }
    
    var backgroundPattern: AppBackgroundPattern {
        didSet {
            UserDefaults.standard.set(
                backgroundPattern.rawValue,
                forKey: "backgroundPattern"
            )
        }
    }
    
    var backgroundPatternOpacity: Double {
        didSet {
            UserDefaults.standard.set(
                backgroundPatternOpacity,
                forKey: "backgroundPatternOpacity"
            )
        }
    }
    
    var diagnosticAttachmentFailure = false
    
    var badgeMode: Int {
        didSet {
            UserDefaults.standard.set(
                badgeMode,
                forKey: "badgeMode"
            )
        }
    }
    
    var showAppBadge: Bool {
        didSet {
            UserDefaults.standard.set(
                showAppBadge,
                forKey: "showAppBadge"
            )
        }
    }
    
    var selectedTheme: AppTheme {
        didSet {
            UserDefaults.standard.set(
                selectedTheme.rawValue,
                forKey: "selectedTheme"
            )
        }
    }
    
    var autoDeleteCompletedAttachments: Bool {
        didSet {
            UserDefaults.standard.set(
                autoDeleteCompletedAttachments,
                forKey: "autoDeleteCompletedAttachments"
            )
        }
    }
    
    var attachmentRetentionDays: Int {
        didSet {
            UserDefaults.standard.set(
                attachmentRetentionDays,
                forKey: "attachmentRetentionDays"
            )
        }
    }
    
    var recentlyDeletedRetentionDays: Int {
        didSet {
            UserDefaults.standard.set(
                recentlyDeletedRetentionDays,
                forKey: "recentlyDeletedRetentionDays"
            )
        }
    }
    
    var locationRemindersEnabled: Bool {
        didSet {
            UserDefaults.standard.set(
                locationRemindersEnabled,
                forKey: "locationRemindersEnabled"
            )
        }
    }
    
    var locationRadius: Int {
        didSet {
            UserDefaults.standard.set(
                locationRadius,
                forKey: "locationRadius"
            )
        }
    }

    var vaultAutoLockInterval: Int {
        didSet {
            UserDefaults.standard.set(vaultAutoLockInterval, forKey: "vaultAutoLockInterval")
        }
    }

    var vaultClipboardClearInterval: Int {
        didSet {
            UserDefaults.standard.set(vaultClipboardClearInterval, forKey: "vaultClipboardClearInterval")
        }
    }

    var vaultAutoHidePasswords: Bool {
        didSet {
            UserDefaults.standard.set(vaultAutoHidePasswords, forKey: "vaultAutoHidePasswords")
        }
    }

    var tabOrder: [Int] {
        didSet {
            UserDefaults.standard.set(tabOrder, forKey: "tabOrder")
        }
    }

    var orderedTabs: [AppTab] {
        Self.normalizedTabOrder(tabOrder).compactMap(AppTab.init(rawValue:))
    }

    private static func normalizedTabOrder(_ order: [Int]) -> [Int] {
        let knownTabs = Set(AppTab.allCases.map(\.rawValue))
        let validOrder = order.filter(knownTabs.contains)
        let missingTabs = AppTab.defaultOrder.map(\.rawValue).filter { !validOrder.contains($0) }
        return validOrder + missingTabs
    }
    
    
    private init() {
        iconStyle = .polychrome
        showBadge = true
        showAttachments = true
        showLocation = true
        showPriority = true
        showBadgeOnlyWithPriority = true
        highlightEnabled = true
        highlightColorHex = Color.red.toHex() ?? ""
        tabBarCustomizationIconColorHex = Color.blue.toHex() ?? ""
        showTodayExpiredLabel = true
        selectedTaskRowStyle = 0
        surfaceCornerRadius = 22
        surfaceBorder = .hairline
        surfaceMaterial = .standard
        taskRowVerticalPadding = 0
        
        dueIconEffectRaw = DueIconEffect.blink.rawValue
        taskListStyle = .plain
        walletViewStyle = .cards
        showDateEveryRow = false
        confirmTaskDeletion = true
        keepRecurringTaskHistory = true
        taskWeekDays = 3
        startupTab = 1
        notificationLeadTimeDays = 1
        showWeatherForecast = true
        showVault = true
        showDashboardTomorrow = true
        showDashboardContinue = true
        siriAutoReminderEnabled = true
        navigationAppID = "apple"
        backgroundStyle = .gradient
        backgroundColor1Hex = defaultBackColor1.toHex() ?? ""
        backgroundColor2Hex = defaultBackColor2.toHex() ?? ""
        backgroundPattern = .none
        backgroundPatternOpacity = 0.08
        badgeMode = 1
        showAppBadge = true
        selectedTheme = .system
        autoDeleteCompletedAttachments = true
        attachmentRetentionDays = 30
        recentlyDeletedRetentionDays = 30
        locationRemindersEnabled = false
        locationRadius = 150
        vaultAutoLockInterval = 120
        vaultClipboardClearInterval = 90
//        vaultRequireFaceID = true
        vaultAutoHidePasswords = true
        tabOrder = AppTab.defaultOrder.map(\.rawValue)

        loadFromUserDefaults(.standard)
        
    }
}
