import Foundation
import UIKit
import SwiftData
@preconcurrency import UserNotifications
import os
import AlarmKit

@MainActor
final class NotificationManager: NSObject {
    
    static let shared = NotificationManager()
    
    var modelContainer: ModelContainer?
    
    private var lastTasksSignature: String = ""
    private var rebuildTask: Task<Void, Never>?
    private var refreshGeneration: UInt64 = 0
    private var lastRebuild: Date = .distantPast
    private var pendingRefresh = false
  
    private var isAppLaunching = true

    private var requiresUpgradeNotificationRebuild = false

    private var cloudKitRefreshTask: Task<Void, Never>?
    private override init() {
        super.init()
    }
    
    // MARK: - Setup
    
    func configure() async {
        
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        
        _ = try? await center.requestAuthorization(options: [.alert, .sound, .badge])
        
        let actions = [
            UNNotificationAction(
                identifier: "OPEN_APP",
                title: String(localized: "Open \(appName)"),
                options: [.foreground]
            ),
            UNNotificationAction(
                identifier: "SNOOZE_5",
                title: String(localized: "Snooze 5 min")
            ),
            UNNotificationAction(
                identifier: "SNOOZE_15",
                title: String(localized: "Snooze 15 min")
            ),
            UNNotificationAction(
                identifier: "SNOOZE_30",
                title: String(localized: "Snooze 30 min")
            ),
            UNNotificationAction(
                identifier: "SNOOZE_60",
                title: String(localized: "Snooze 1 hour")
            )
        ]
        
        let category = UNNotificationCategory(
            identifier: "TASK_REMINDER",
            actions: actions,
            intentIdentifiers: [],
            options: [.customDismissAction]
        )
        
        center.setNotificationCategories([category])

        // 🔥 Rebuild all notifications after app update
        let currentBuild =
            Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? ""

        let lastBuild =
            UserDefaults.standard.string(forKey: "lastInstalledBuild")

        // 🔵 First version using this mechanism
        if lastBuild == nil {

            UserDefaults.standard.set(
                currentBuild,
                forKey: "lastInstalledBuild"
            )

        } else if lastBuild != currentBuild {

#if DEBUG
            print("🔔 Build changed: full notification rebuild")
#endif

            center.removeAllPendingNotificationRequests()

            self.lastTasksSignature = ""

            // 🔥 Delay rebuild until ModelContainer is available
            self.requiresUpgradeNotificationRebuild = true

            UserDefaults.standard.set(
                currentBuild,
                forKey: "lastInstalledBuild"
            )
        }

        await rebuildDocumentNotifications()

        // 🔵 Mark end of launch phase after short delay
        Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(300))
            self?.isAppLaunching = false
        }
    }
    
    // MARK: - PUBLIC REFRESH
    

    func refresh(force: Bool = false) {
        let now = Date()
        
        // 🔴 Throttle più morbido (evita drop di aggiornamenti reali)
        if !force && now.timeIntervalSince(lastRebuild) < 0.15 {
            return
        }


        guard let context = modelContainer?.mainContext else { return }

        // 🔥 First refresh after upgrade:
        // old AppStore versions may never have scheduled
        // deadline notifications for existing tasks.
        if requiresUpgradeNotificationRebuild {
            lastTasksSignature = ""
            requiresUpgradeNotificationRebuild = false
//            forceFullRefresh(using: context)
        }

        let tBadge = ContinuousClock.now

        let badge = computeBadgeCount(using: context)

        AppLogger.notifications.debug(
            "⏱️ REFRESH badge count: \(ContinuousClock.now - tBadge)"
        )

        let tLocationRefresh = ContinuousClock.now

        LocationReminderManager.shared.refreshMonitoring(using: context)

        AppLogger.notifications.debug(
            "⏱️ REFRESH location: \(ContinuousClock.now - tLocationRefresh)"
        )

        // 🔥 Badge immediato
        let showBadge = UserDefaults.standard.bool(forKey: "showAppBadge")
        applyBadge(showBadge ? badge : 0)

        // Prevent overlapping rebuilds. A forced refresh invalidates the previous
        // generation; only the newest generation may release the pending flag.
        if pendingRefresh && !force { return }
        let previousTask = rebuildTask
        previousTask?.cancel()

        refreshGeneration &+= 1
        let generation = refreshGeneration
        pendingRefresh = true

        rebuildTask = Task(priority: .utility) { [weak self] in
            guard let self else { return }

            do {
                try await Task.sleep(for: .milliseconds(force ? 150 : 400))
            } catch {
                // Cancellation is expected when a newer refresh supersedes this one.
            }

            // Serialize rebuilds: a previous UNUserNotificationCenter.add call may
            // still be in flight when its task is cancelled. Wait for it to finish
            // before taking the next pending-request snapshot.
            await previousTask?.value

            guard !Task.isCancelled, generation == self.refreshGeneration else {
                if generation == self.refreshGeneration {
                    self.pendingRefresh = false
                }
                return
            }

            guard let context = self.modelContainer?.mainContext else {
                if generation == self.refreshGeneration {
                    self.pendingRefresh = false
                }
                return
            }

#if DEBUG
            AppLogger.notifications.debug("Optimized refresh")
#endif
            let tSecondFetch = ContinuousClock.now
            guard let fetched = self.fetchNotificationTasks(using: context) else {
                if generation == self.refreshGeneration {
                    self.lastTasksSignature = ""
                    self.pendingRefresh = false
                }
                return
            }
            AppLogger.notifications.debug(
                "⏱️ REFRESH notification fetch: \(ContinuousClock.now - tSecondFetch)"
            )

            let tSignature = ContinuousClock.now
            let signature = self.signature(for: fetched)
            AppLogger.notifications.debug(
                "⏱️ REFRESH signature: \(ContinuousClock.now - tSignature)"
            )

            guard !Task.isCancelled, generation == self.refreshGeneration else {
                if generation == self.refreshGeneration {
                    self.pendingRefresh = false
                }
                return
            }

            if !force && signature == self.lastTasksSignature {
                self.pendingRefresh = false
                self.lastRebuild = Date()
                return
            }

            let rebuildSucceeded = await self.rebuild(
                fetched,
                expectedGeneration: generation
            )

            // Do not cache a signature for an incomplete rebuild. A later refresh
            // must be able to retry after a SwiftData or scheduling failure.
            if generation == self.refreshGeneration {
                self.pendingRefresh = false
                if rebuildSucceeded {
                    self.lastTasksSignature = signature
                    self.lastRebuild = Date()
                } else {
                    self.lastTasksSignature = ""
                }
            }
        }
    }

    func refreshAndWait(force: Bool = false) async {
        refresh(force: force)

        // A forced refresh may supersede the task we're currently awaiting.
        // Wait until the latest generation has completed.
        while true {
            let generation = refreshGeneration
            let task = rebuildTask
            await task?.value
            if generation == refreshGeneration && !pendingRefresh {
                return
            }
        }
    }

    func forceFullRefresh(using context: ModelContext) {
        refresh(force: true)
    }
    
    // MARK: - CloudKit Optimized Refresh (coalescing)

    func refreshFromCloudKit() {
        guard !isAppLaunching else { return }

        // Trailing debounce: each imported store change restarts the timer.
        // Rebuild only after the remote transaction burst has settled.
        cloudKitRefreshTask?.cancel()
        cloudKitRefreshTask = Task { [weak self] in
            guard let self else { return }

            do {
                try await Task.sleep(for: .seconds(30))
                try Task.checkCancellation()
            } catch {
                // A newer persistent-store event superseded this refresh.
                return
            }

            self.refresh(force: true)
            NotificationCenter.default.post(
                name: .cloudKitDidStabilize,
                object: nil
            )
        }
    }

    // MARK: - FETCH
    
    private func fetchTasks(using context: ModelContext) -> [TodoTask] {
        let now = Date()

        // Cleanup expired manual snooze
        let expiredSnoozeDescriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.manualSnoozeUntil != nil &&
                $0.manualSnoozeUntil! <= now
            }
        )

        if let expiredTasks = try? context.fetch(expiredSnoozeDescriptor) {
            for task in expiredTasks {
                task.manualSnoozeUntil = nil
            }
        }

        // Cleanup invalid reminder offset
        let zeroReminderDescriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.reminderOffsetMinutes == 0
            }
        )

        if let zeroReminderTasks = try? context.fetch(zeroReminderDescriptor) {
            for task in zeroReminderTasks {
                task.reminderOffsetMinutes = nil
            }
        }

        context.processPendingChanges()

        // Main notification fetch
        return (try? context.fetch(
            FetchDescriptor<TodoTask>(
                predicate: #Predicate<TodoTask> {
                    !$0.isCompleted
                }
            )
        )) ?? []
    }
    
    
    
    
    private func computeBadgeCount(using context: ModelContext) -> Int {
        let now = Date()

        let badgeMode = UserDefaults.standard.integer(forKey: "badgeMode")
        let leadDays = UserDefaults.standard.integer(
            forKey: "notificationLeadTimeDays"
        )

        let cutoffDate: Date

        if badgeMode == 0 || leadDays <= 0 {
            cutoffDate = now
        } else {
            cutoffDate = Calendar.current.date(
                byAdding: .day,
                value: leadDays,
                to: now
            ) ?? now
        }

        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.deadLine != nil &&
                $0.deadLine! <= cutoffDate
            }
        )

        return (try? context.fetchCount(descriptor)) ?? 0
    }
    
    
    private func fetchNotificationTasks(
        using context: ModelContext,
        fetchOperation: (() throws -> [TodoTask])? = nil
    ) -> [TodoTask]? {
        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                !$0.isDebugTask &&
                (
                    $0.deadLine != nil ||
                    $0.manualSnoozeUntil != nil ||
                    $0.snoozeUntil != nil
                )
            }
        )

        do {
            if let fetchOperation {
                return try fetchOperation()
            }
            return try context.fetch(descriptor)
        } catch {
            AppLogger.notifications.error(
                "Notification rebuild skipped because task fetch failed: \(error.localizedDescription)"
            )
            return nil
        }
    }
    
    
    
    // MARK: - SIGNATURE
    
    private func signature(for tasks: [TodoTask]) -> String {

        let alarmAuthorizationAvailable =
            ForMemoAlarmManager.shared.authorizationState() == .authorized

        guard !tasks.isEmpty else {
            return "EMPTY-alarmAuthorization:\(alarmAuthorizationAvailable)"
        }

        let body = tasks
            .sorted { $0.id.uuidString < $1.id.uuidString }
            .map {
                "\($0.id.uuidString)-\($0.title)-\($0.deadLine?.timeIntervalSince1970 ?? 0)-\($0.reminderOffsetMinutes ?? 0)-\($0.alarmEnabled)-\($0.snoozeUntil?.timeIntervalSince1970 ?? 0)-\($0.manualSnoozeUntil?.timeIntervalSince1970 ?? 0)"
            }
            .joined(separator: "|")

        return "\(tasks.count)-alarmAuthorization:\(alarmAuthorizationAvailable)-" + body
    }
    
    // MARK: - PURE LOGIC (Event Calculation)

    struct TaskEventCalculator {
        struct Event {
            let id: String
            let date: Date
            let type: String
        }

        /// Returns every future notification event for the task.
        ///
        /// Snooze is exclusive: while an active snooze exists, the snooze
        /// notification is the only event that may be pending for that task.
        static func allEvents(
            for task: TodoTask,
            now: Date,
            lead: NotificationLeadTime,
            alarmAuthorizationAvailable: Bool = true
        ) -> [Event] {
            guard let deadline = task.deadLine else {
                return []
            }

            if let manual = task.manualSnoozeUntil, manual > now {
                return [Event(
                    id: "task.\(task.id.uuidString).manualSnooze",
                    date: manual,
                    type: "manualSnooze"
                )]
            }

            if let snooze = task.snoozeUntil, snooze > now {
                return [Event(
                    id: "task.\(task.id.uuidString).snooze",
                    date: snooze,
                    type: "snooze"
                )]
            }
            
            guard deadline > now else {
                return []
            }

            var candidates: [Event] = []
            let calendar = Calendar.current

            if !lead.isNone,
               let globalDate = calendar.date(
                    byAdding: .day,
                    value: -lead.rawValue,
                    to: deadline
               ),
               globalDate > now,
               globalDate < deadline {
                candidates.append(Event(
                    id: "task.\(task.id.uuidString).global",
                    date: globalDate,
                    type: "global"
                ))
            }

            if let minutes = task.reminderOffsetMinutes,
               let reminderDate = calendar.date(
                    byAdding: .minute,
                    value: -minutes,
                    to: deadline
               ),
               reminderDate > now,
               reminderDate < deadline {
                candidates.append(Event(
                    id: "task.\(task.id.uuidString).reminder",
                    date: reminderDate,
                    type: "reminder"
                ))
            }

            if task.alarmEnabled && alarmAuthorizationAvailable {
                // AlarmKit is the user-facing deadline alert.
                // Keep one silent UN notification at the same time only to update
                // the app badge when the AlarmKit alarm fires.
                candidates.append(Event(
                    id: "task.\(task.id.uuidString).alarmBadge",
                    date: deadline,
                    type: "alarmBadge"
                ))
            } else {
                // AlarmKit authorization is unavailable: use the normal deadline
                // notification without changing the task's saved alarm setting.
                candidates.append(Event(
                    id: "task.\(task.id.uuidString).deadline",
                    date: deadline,
                    type: "deadline"
                ))
            }

            return candidates.sorted {
                if $0.date != $1.date {
                    return $0.date < $1.date
                }
                return $0.id < $1.id
            }
        }

        /// Compatibility helper used by existing callers/benchmarks.
        static func nextEvent(
            for task: TodoTask,
            now: Date,
            lead: NotificationLeadTime,
            alarmAuthorizationAvailable: Bool = true
        ) -> Event? {
            allEvents(
                for: task,
                now: now,
                lead: lead,
                alarmAuthorizationAvailable: alarmAuthorizationAvailable
            ).first
        }
    }

    // MARK: - NEXT TRIGGER (single source of truth)

    private func nextTrigger(
        for task: TodoTask,
        now: Date
    ) -> TaskEventCalculator.Event? {
        let lead = NotificationLeadTime(
            safeRawValue: UserDefaults.standard.integer(
                forKey: "notificationLeadTimeDays"
            )
        )

        return TaskEventCalculator.nextEvent(
            for: task,
            now: now,
            lead: lead,
            alarmAuthorizationAvailable:
                ForMemoAlarmManager.shared.authorizationState() == .authorized
        )
    }

    // MARK: - CHRONOLOGICAL QUEUE SELECTION

    /// Shared deterministic selection logic for production scheduling and diagnostics.
    /// This pure helper does not access or mutate notification services.
    static func selectChronologicalQueue<T>(
        from candidates: [T],
        limit: Int,
        date: (T) -> Date,
        id: (T) -> String
    ) -> [T] {
        guard limit > 0 else { return [] }

        let sorted = candidates.sorted { lhs, rhs in
            let lhsDate = date(lhs)
            let rhsDate = date(rhs)
            if lhsDate != rhsDate {
                return lhsDate < rhsDate
            }
            return id(lhs) < id(rhs)
        }
        return Array(sorted.prefix(limit))
    }

    // MARK: - REBUILD

    
    private func rebuild(
        _ tasks: [TodoTask],
        cleanupStale: Bool = true,
        syncBadge: Bool = true,
        expectedGeneration: UInt64? = nil,
        contextOverride: ModelContext? = nil,
        documentFetchOperation: (() throws -> [DocumentItem])? = nil,
        addOperation: ((UNNotificationRequest) async throws -> Void)? = nil
    ) async -> Bool {
        let rebuildStart = Date()
        let center = UNUserNotificationCenter.current()
        let now = Date()

        // Tasks and documents share one chronological queue. If document data
        // cannot be read, abort before removing or replacing any pending request.
        guard let context = contextOverride ?? modelContainer?.mainContext else {
            AppLogger.notifications.error(
                "Notification rebuild skipped because the model context is unavailable."
            )
            return false
        }

        let documents: [DocumentItem]
        do {
            if let documentFetchOperation {
                documents = try documentFetchOperation()
            } else {
                documents = try context.fetch(FetchDescriptor<DocumentItem>())
            }
        } catch {
            AppLogger.notifications.error(
                "Notification rebuild skipped because document fetch failed: \(error.localizedDescription)"
            )
            return false
        }

        let badgeIndex = TaskBadgePolicy.Index(tasks: tasks)
        let pending = await center.pendingNotificationRequests()
        var existing: [String: UNNotificationRequest] = [:]
        existing.reserveCapacity(pending.count)
        for request in pending {
            existing[request.identifier] = request
        }

        let lead = NotificationLeadTime(
            safeRawValue: UserDefaults.standard.integer(
                forKey: "notificationLeadTimeDays"
            )
        )

        struct ScheduledEvent {
            let id: String
            let date: Date
            let content: UNMutableNotificationContent
        }

        var candidates: [ScheduledEvent] = []
        candidates.reserveCapacity(tasks.count * 3)

        for task in tasks {
            guard !task.isCompleted, !task.isDebugTask else { continue }

            for event in TaskEventCalculator.allEvents(
                for: task,
                now: now,
                lead: lead,
                alarmAuthorizationAvailable:
                    ForMemoAlarmManager.shared.authorizationState() == .authorized
            ) {
                let content = taskNotificationContent(
                    for: task,
                    event: event,
                    badge: badgeIndex.count(at: event.date)
                )
                candidates.append(
                    ScheduledEvent(
                        id: event.id,
                        date: event.date,
                        content: content
                    )
                )
            }
        }

        // Documents are part of the same global chronological queue.
        for document in documents {
            guard document.notificationEnabled,
                  let expiryDate = document.expiryDate,
                  let triggerDate = Calendar.current.date(
                    byAdding: .day,
                    value: -document.notificationDaysBefore,
                    to: expiryDate
                  ),
                  triggerDate > now else {
                continue
            }

            let content = documentNotificationContent(title: document.name)
            candidates.append(
                ScheduledEvent(
                    id: "document.\(document.id.uuidString)",
                    date: triggerDate,
                    content: content
                )
            )
        }

        // Keep the existing global chronological queue and its 64-request limit.
        // Warnings are appended to real, user-visible notifications, so they do
        // not consume additional notification slots or alter delivery times.
        let selected = Self.selectChronologicalQueue(
            from: candidates,
            limit: 64,
            date: { $0.date },
            id: { $0.id }
        )

        let visibleSelected = selected.filter {
            ($0.content.userInfo["type"] as? String) != "alarmBadge"
        }
        let firstWarning = String(localized: "🟡 Open ForMemo to refresh alerts.")
        let secondWarning = String(localized: "🔴 Open ForMemo now: later alerts may be missed!")

        // Trigger warnings by global queue position, not by visible-notification count.
        // Attach each warning to the first visible notification at or after its
        // threshold. If none exists after that position, use the last visible one.
        let warningTargets: [(threshold: Int, warning: String)] = [
            (40, firstWarning),
            (50, secondWarning)
        ]

        for item in warningTargets where selected.count >= item.threshold {
            let startIndex = item.threshold - 1
            let target = selected[startIndex...].first(where: {
                ($0.content.userInfo["type"] as? String) != "alarmBadge"
            })

            if let target {
                appendQueueWarning(item.warning, to: target.content)
            } else if let lastVisible = visibleSelected.last {
                appendQueueWarning(item.warning, to: lastVisible.content)
            }
        }

        let selectedIDs = Set(selected.map(\.id))

        guard rebuildStart >= self.lastRebuild else { return false }
        guard expectedGeneration == nil || expectedGeneration == self.refreshGeneration else { return false }

        // Synchronize removals before additions.
        // This is important when the notification queue changes substantially
        // after a recurrence is created, migrated, changed, completed or deleted.
        if cleanupStale {
            guard expectedGeneration == nil || expectedGeneration == self.refreshGeneration else { return false }
            let managedPrefixes = ["task.", "document.", "queueWarning."]
            let staleIDs = existing.keys.filter { id in
                managedPrefixes.contains(where: { id.hasPrefix($0) }) &&
                !selectedIDs.contains(id)
            }

            if !staleIDs.isEmpty {
                center.removePendingNotificationRequests(
                    withIdentifiers: Array(staleIDs)
                )

                for id in staleIDs {
                    existing.removeValue(forKey: id)
                }
            }
        }

        var schedulingSucceeded = true
        for item in selected {
            guard expectedGeneration == nil || expectedGeneration == self.refreshGeneration else { return false }
            guard !Task.isCancelled || expectedGeneration == nil else { return false }
            let trigger = calendarTrigger(for: item.date)

            if let old = existing[item.id],
               notificationRequestMatches(
                    old,
                    content: item.content,
                    trigger: trigger
               ) {
                continue
            }

            let request = UNNotificationRequest(
                identifier: item.id,
                content: item.content,
                trigger: trigger
            )

            do {
                if let addOperation {
                    try await addOperation(request)
                } else {
                    try await center.add(request)
                }
                existing[item.id] = request
            } catch {
                schedulingSucceeded = false
                AppLogger.notifications.error(
                    "Notification scheduling failed [\(item.id)]: \(error.localizedDescription)"
                )
            }
            guard expectedGeneration == nil || expectedGeneration == self.refreshGeneration else { return false }
        }

        if syncBadge {
            let finalBadge = computeBadgeCount(from: tasks)
            let showBadge = UserDefaults.standard.bool(forKey: "showAppBadge")
            applyBadge(showBadge ? finalBadge : 0)
        }

        return schedulingSucceeded
    }

    private func calendarTrigger(for date: Date) -> UNCalendarNotificationTrigger {
        let components = Calendar.current.dateComponents(
            [.year, .month, .day, .hour, .minute, .second],
            from: date
        )
        return UNCalendarNotificationTrigger(
            dateMatching: components,
            repeats: false
        )
    }

    private func notificationRequestMatches(
        _ existing: UNNotificationRequest,
        content: UNNotificationContent,
        trigger: UNNotificationTrigger
    ) -> Bool {
        guard existing.content.title == content.title,
              existing.content.body == content.body,
              existing.content.sound?.description == content.sound?.description,
              existing.content.badge == content.badge else {
            return false
        }

        guard let oldTrigger = existing.trigger as? UNCalendarNotificationTrigger,
              let newTrigger = trigger as? UNCalendarNotificationTrigger else {
            return false
        }

        return oldTrigger.nextTriggerDate() == newTrigger.nextTriggerDate()
    }

    private func taskNotificationContent(
        for task: TodoTask,
        event: TaskEventCalculator.Event,
        badge: Int
    ) -> UNMutableNotificationContent {
        let content: UNMutableNotificationContent

        switch event.type {
        case "manualSnooze", "snooze":
            content = baseContent(task, title: String(localized: "⏲️ Snoozed"))

        case "reminder":
            let minutes = task.reminderOffsetMinutes ?? 0
            let title: String
            if minutes < 60 {
                title = minutes == 1
                    ? String(localized: "🔔 In 1 minute!")
                    : String(localized: "🔔 In \(minutes) minutes!")
            } else if minutes < 1440 {
                let hours = minutes / 60
                title = hours == 1
                    ? String(localized: "🔔 In 1 hour!")
                    : String(localized: "🔔 In \(hours) hours!")
            } else {
                let days = minutes / 1440
                title = days == 1
                    ? String(localized: "🔔 In 1 day!")
                    : String(localized: "🔔 In \(days) days!")
            }
            content = baseContent(task, title: title)

        case "global":
            let days = NotificationLeadTime(
                safeRawValue: UserDefaults.standard.integer(
                    forKey: "notificationLeadTimeDays"
                )
            ).rawValue
            let title = days == 1
                ? String(localized: "⏱️ In 1 day!")
                : String(localized: "⏱️ In \(days) days!")
            content = baseContent(task, title: title)

        case "deadline":
            content = baseContent(task, title: String(localized: "⏰ Overdue"))

        case "alarmBadge":
            // AlarmKit provides the actual alarm UI and sound.
            // This request exists only so iOS applies the badge at the deadline.
            content = UNMutableNotificationContent()

        default:
            content = baseContent(task, title: String(localized: "Reminder"))
        }

        content.badge = NSNumber(value: badge)
        content.userInfo["type"] = event.type
        return content
    }

    private func appendQueueWarning(
        _ warning: String,
        to content: UNMutableNotificationContent
    ) {
        let existingBody = content.body.trimmingCharacters(in: .whitespacesAndNewlines)
        content.body = existingBody.isEmpty
            ? warning
            : existingBody + "\n\n" + warning
    }

    private func documentNotificationContent(title: String) -> UNMutableNotificationContent {
        let content = UNMutableNotificationContent()
        content.title = String(localized: "Document Expiring")
        content.body = title

        let soundName = UserDefaults.standard.string(
            forKey: "notificationSoundName"
        ) ?? ""

        content.sound = soundName.isEmpty
            ? .default
            : UNNotificationSound(
                named: UNNotificationSoundName(rawValue: soundName)
            )

        return content
    }

#if DEBUG
    /// Exercises the production task-fetch guard with an injected fetch error.
    func debugRebuildAfterTaskFetch(
        using context: ModelContext,
        fetchOperation: @escaping () throws -> [TodoTask],
        addOperation: ((UNNotificationRequest) async throws -> Void)? = nil
    ) async -> Bool {
        guard let tasks = fetchNotificationTasks(
            using: context,
            fetchOperation: fetchOperation
        ) else {
            return false
        }

        return await rebuild(
            tasks,
            cleanupStale: false,
            syncBadge: false,
            contextOverride: context,
            addOperation: addOperation
        )
    }

    /// Runs the production rebuild against an isolated SwiftData context.
    func debugRebuild(
        tasks: [TodoTask],
        using context: ModelContext,
        documentFetchOperation: (() throws -> [DocumentItem])? = nil,
        addOperation: ((UNNotificationRequest) async throws -> Void)? = nil
    ) async -> Bool {
        await rebuild(
            tasks,
            cleanupStale: false,
            syncBadge: false,
            contextOverride: context,
            documentFetchOperation: documentFetchOperation,
            addOperation: addOperation
        )
    }

    func debugRebuild(tasks: [TodoTask]) async {
        _ = await rebuild(
            tasks,
            cleanupStale: false,
            syncBadge: false
        )
    }
#endif
    
    
    // MARK: - ACTIONS
    
    
    
    // MARK: - CONTENT (UI IDENTICA)
    
    private func baseContent(_ task: TodoTask, title: String) -> UNMutableNotificationContent {
        
        let c = UNMutableNotificationContent()
        
        c.title = title              // 🔥 UI ORIGINALE
        c.body = task.title         // 🔥 UI ORIGINALE
        
        let soundName = UserDefaults.standard.string(forKey: "notificationSoundName") ?? ""
        
        if soundName.isEmpty {
            c.sound = .default
        } else {
            c.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: soundName))
        }
        c.categoryIdentifier = "TASK_REMINDER"
        c.userInfo["taskID"] = task.id.uuidString
        
        return c
    }
    
    // MARK: - BADGE
    private func computeBadgeCount(at date: Date, tasks: [TodoTask]) -> Int {

        TaskBadgePolicy.badgeCount(
            tasks: tasks,
            referenceDate: date
        )
    }
    
    
    private func computeBadgeCount(from tasks: [TodoTask]) -> Int {

        TaskBadgePolicy.badgeCount(
            tasks: tasks,
            referenceDate: Date()
        )
    }
    
    private func applyBadge(_ count: Int) {
        
        UNUserNotificationCenter.current().setBadgeCount(count) { error in
#if DEBUG
            if let error {
                AppLogger.notifications.error("Badge error: \(error.localizedDescription)")
            }
#endif
        }
    }

    @MainActor
    func rebuildDocumentNotifications() async {
        // Documents participate in the same global chronological queue as tasks.
        refresh(force: true)
        await rebuildTask?.value
    }

    @MainActor
    func removeDocumentNotification(documentID: UUID) {
        let identifier = "document.\(documentID.uuidString)"
        let center = UNUserNotificationCenter.current()
        center.removePendingNotificationRequests(withIdentifiers: [identifier])
        center.removeDeliveredNotifications(withIdentifiers: [identifier])
    }

    @MainActor
    func scheduleDocumentNotification(
        id: UUID,
        title: String,
        triggerDate: Date
    ) async {
        guard triggerDate > Date() else { return }

        // Keep the existing public API, but never bypass the global queue.
        refresh(force: true)
        await rebuildTask?.value
    }
}

// MARK: - DELEGATE

extension NotificationManager: UNUserNotificationCenterDelegate {
    
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        return [.banner, .sound, .badge]
    }
    
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse
    ) async {
        
        let taskID = response.notification.request.content.userInfo["taskID"] as? String

        // 1️⃣ salva azione (come già fai)
        switch response.actionIdentifier {
            
        case "OPEN_APP":
            break // iOS apre già l'app automaticamente
            
        case "SNOOZE_5", "SNOOZE_15", "SNOOZE_30", "SNOOZE_60":
            if let container = self.modelContainer {
                let context = container.mainContext

                let interval: TimeInterval
                switch response.actionIdentifier {
                case "SNOOZE_5": interval = 300
                case "SNOOZE_15": interval = 900
                case "SNOOZE_30": interval = 1800
                case "SNOOZE_60": interval = 3600
                default: interval = 300
                }

                if let taskID,
                   let uuid = UUID(uuidString: taskID) {
                    let descriptor = FetchDescriptor<TodoTask>(
                        predicate: #Predicate<TodoTask> { $0.id == uuid }
                    )

                    if let task = try? context.fetch(descriptor).first {
                        let rawDate = Date().addingTimeInterval(interval)

                        let type = response.notification.request.content.userInfo["type"] as? String

                        // 🔵 Manual Snooze: completely independent from notification snooze.
                        // Never enforce the task deadline.
                        if type == "manualSnooze" {

                            task.manualSnoozeUntil = rawDate
                            task.snoozeUntil = nil
                        } else if let deadline = task.deadLine {

                            if type == "deadline" {

                                // ✅ Snooze from deadline is ALWAYS allowed
                                task.snoozeUntil = rawDate

                            } else {

                                // ❌ Existing notification snooze must not exceed the deadline
                                if rawDate >= deadline {

                                    let state = UIApplication.shared.applicationState

                                    if !self.isAppLaunching && state != .background {
                                        NotificationCenter.default.post(
                                            name: .snoozeRejectedDueToDeadline,
                                            object: nil
                                        )
                                    }

                                    let content = UNMutableNotificationContent()
                                    content.title = String(localized: "Snooze not scheduled")
                                    content.body = String(localized: "Snooze exceeds the deadline. No snooze notification will be scheduled. The deadline notification will still occur.")
                                    content.sound = .default

                                    let trigger = UNTimeIntervalNotificationTrigger(
                                        timeInterval: 5,
                                        repeats: false
                                    )

                                    let request = UNNotificationRequest(
                                        identifier: "snoozeRejected.\(UUID().uuidString)",
                                        content: content,
                                        trigger: trigger
                                    )

                                    try? await UNUserNotificationCenter.current().add(request)

                                } else {

                                    task.snoozeUntil = rawDate

                                }
                            }

                        } else {

                            task.snoozeUntil = rawDate

                        }

                        try? context.save()
                        context.processPendingChanges()
                    }
                }
            }
            
        default:
            break
        }
        
        // 2️⃣ Apply notification action changes immediately
        await MainActor.run {
            
            if let container = self.modelContainer {
                let context = container.mainContext
                
                let tNotificationActions = ContinuousClock.now

                NotificationActionProcessor.shared.processAll(using: context)

                AppLogger.notifications.debug(
                    "⏱️ ACTIVE NotificationActionProcessor: \(ContinuousClock.now - tNotificationActions)"
                )
                
                context.processPendingChanges()
                
                // Immediate badge refresh
                let tasks = self.fetchTasks(using: context)
                let badge = self.computeBadgeCount(from: tasks)
                let showBadge = UserDefaults.standard.bool(forKey: "showAppBadge")
                self.applyBadge(showBadge ? badge : 0)
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                NotificationManager.shared.refresh()
            }
            
            NotificationCenter.default.post(
                name: .attachmentsShouldRefresh,
                object: nil
            )
        }
    }
}

//# MARK: - Notification Extension

extension Notification.Name {
    static let snoozeClamped = Notification.Name("snoozeClamped")
    static let snoozeRejectedDueToDeadline = Notification.Name("snoozeRejectedDueToDeadline")
    static let cloudKitDidStabilize = Notification.Name("cloudKitDidStabilize")
}
