import Foundation
import UIKit
import SwiftData
@preconcurrency import UserNotifications
import os

@MainActor
final class NotificationManager: NSObject {
    
    static let shared = NotificationManager()
    
    var modelContainer: ModelContainer?
    
    private var lastTasksSignature: String = ""
    private var rebuildTask: Task<Void, Never>?
    private var lastRebuild: Date = .distantPast
    @MainActor
    private var pendingRefresh = false
  
    private var isAppLaunching = true

    private var requiresUpgradeNotificationRebuild = false

    private var cloudKitRefreshTask: Task<Void, Never>?
    private var lastCloudKitRefresh = Date.distantPast
    private override init() {
        super.init()
    }
    
    // MARK: - Setup
    
    func configure() async {
        
        let center = UNUserNotificationCenter.current()
        center.delegate = self
        
        _ = try? await center.requestAuthorization(options: [.alert, .sound, .badge])
        
        let actions = [
            UNNotificationAction(
                identifier: "OPEN_APP",
                title: String(localized: "Open \(appName)"),
                options: [.foreground]
            ),
            UNNotificationAction(
                identifier: "SNOOZE_5",
                title: String(localized: "Snooze 5 min")
            ),
            UNNotificationAction(
                identifier: "SNOOZE_15",
                title: String(localized: "Snooze 15 min")
            ),
            UNNotificationAction(
                identifier: "SNOOZE_30",
                title: String(localized: "Snooze 30 min")
            ),
            UNNotificationAction(
                identifier: "SNOOZE_60",
                title: String(localized: "Snooze 1 hour")
            )
        ]
        
        let category = UNNotificationCategory(
            identifier: "TASK_REMINDER",
            actions: actions,
            intentIdentifiers: [],
            options: [.customDismissAction]
        )
        
        center.setNotificationCategories([category])

        // 🔥 Rebuild all notifications after app update
        let currentBuild =
            Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? ""

        let lastBuild =
            UserDefaults.standard.string(forKey: "lastInstalledBuild")

        // 🔵 First version using this mechanism
        if lastBuild == nil {

            UserDefaults.standard.set(
                currentBuild,
                forKey: "lastInstalledBuild"
            )

        } else if lastBuild != currentBuild {

#if DEBUG
            print("🔔 Build changed: full notification rebuild")
#endif

            center.removeAllPendingNotificationRequests()

            self.lastTasksSignature = ""

            // 🔥 Delay rebuild until ModelContainer is available
            self.requiresUpgradeNotificationRebuild = true

            UserDefaults.standard.set(
                currentBuild,
                forKey: "lastInstalledBuild"
            )
        }

        await rebuildDocumentNotifications()

        // 🔵 Mark end of launch phase after short delay
        Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(300))
            self?.isAppLaunching = false
        }
    }
    
    // MARK: - PUBLIC REFRESH
    

    func refresh(force: Bool = false) {
        let now = Date()
        
        // 🔴 Throttle più morbido (evita drop di aggiornamenti reali)
        if !force && now.timeIntervalSince(lastRebuild) < 0.15 {
            return
        }


        guard let context = modelContainer?.mainContext else { return }

        // 🔥 First refresh after upgrade:
        // old AppStore versions may never have scheduled
        // deadline notifications for existing tasks.
        if requiresUpgradeNotificationRebuild {
            lastTasksSignature = ""
            requiresUpgradeNotificationRebuild = false
            forceFullRefresh(using: context)
        }

        let tasksInitial = fetchTasks(using: context)
        LocationReminderManager.shared.refreshMonitoring(tasks: tasksInitial)

        // 🔥 Badge immediato
        let badge = computeBadgeCount(from: tasksInitial)
        let showBadge = UserDefaults.standard.bool(forKey: "showAppBadge")
        applyBadge(showBadge ? badge : 0)

        // 🔥 Prevent overlapping rebuilds.
        // A force refresh must invalidate the current rebuild.
        if pendingRefresh {

            if force {
                rebuildTask?.cancel()
                pendingRefresh = false
            } else {
                return
            }
        }

        pendingRefresh = true

        rebuildTask?.cancel()

        rebuildTask = Task(priority: .utility) { [weak self] in

            guard let self else { return }

            try? await Task.sleep(for: .milliseconds(force ? 150 : 400))

            guard !Task.isCancelled else {

                await MainActor.run {
                    self.pendingRefresh = false
                }

                return
            }

            // --- MAIN ACTOR: fetch + signature ---
            var tasks: [TodoTask] = []
            var shouldRebuild = false

            await MainActor.run {
#if DEBUG
                AppLogger.notifications.debug("Optimized refresh")
#endif

                guard let context = self.modelContainer?.mainContext else {
                    return
                }

                let fetched = self.fetchTasks(using: context)
                let signature = self.signature(for: fetched)

                if !force && signature == self.lastTasksSignature {
                    self.pendingRefresh = false
                    return
                }

                self.lastTasksSignature = signature
                tasks = fetched
                shouldRebuild = true
            }

            // --- Notification rebuild ---
            if shouldRebuild {

                await self.rebuild(tasks)

            }

            // --- CLEANUP ---
            await MainActor.run {
                self.pendingRefresh = false
                self.lastRebuild = Date()
            }
        }
    }
    
    func forceFullRefresh(using context: ModelContext) {
        refresh(force: true)
    }
    
    // MARK: - CloudKit Optimized Refresh (coalescing)

func refreshFromCloudKit() {
    let now = Date()
    guard Date().timeIntervalSince(lastCloudKitRefresh) > 2 else {

        return

    }
    lastCloudKitRefresh = now
    
        guard !isAppLaunching else { return }

        cloudKitRefreshTask?.cancel()

        cloudKitRefreshTask = Task { [weak self] in

            guard let self else { return }

            try? await Task.sleep(for: .seconds(30))

            guard !Task.isCancelled else { return }

            await MainActor.run {
                self.lastCloudKitRefresh = Date()
                self.refresh(force: true)

                Task {
                    await self.rebuildDocumentNotifications()
                }

                NotificationCenter.default.post(
                    name: .cloudKitDidStabilize,
                    object: nil
                )
            }
        }
    }
    

    
    // MARK: - FETCH
    
    private func fetchTasks(using context: ModelContext) -> [TodoTask] {
        
        let tasks = (try? context.fetch(FetchDescriptor<TodoTask>(
            predicate: #Predicate { !$0.isCompleted }
        ))) ?? []
        var needsSave = false
        
        for task in tasks {
            // 🔴 Skip debug stress-test tasks (no notifications)
            if task.isDebugTask { continue }
            // (Snooze cleanup block removed)
            
            // 🔵 Cleanup expired manual snooze
            if let manual = task.manualSnoozeUntil,
               manual <= Date() {
                task.manualSnoozeUntil = nil
                needsSave = true
            }
            
            
            
            if task.reminderOffsetMinutes == 0 {
                task.reminderOffsetMinutes = nil
                needsSave = true
            }
        }
        
        if needsSave {
            context.processPendingChanges()
        }
        
        return tasks
    }
    
    // MARK: - SIGNATURE
    
    private func signature(for tasks: [TodoTask]) -> String {
        
        guard !tasks.isEmpty else { return "EMPTY" }
        
        let body = tasks
            .sorted { $0.id.uuidString < $1.id.uuidString }
            .map {
                "\($0.id.uuidString)-\($0.title)-\($0.deadLine?.timeIntervalSince1970 ?? 0)-\($0.reminderOffsetMinutes ?? 0)-\($0.snoozeUntil?.timeIntervalSince1970 ?? 0)-\($0.manualSnoozeUntil?.timeIntervalSince1970 ?? 0)"
            }
            .joined(separator: "|")
        
        return "\(tasks.count)-" + body
    }
    
    // MARK: - PURE LOGIC (Event Calculation)

    struct TaskEventCalculator {
        struct Event {
            let id: String
            let date: Date
            let type: String
        }

        static func nextEvent(for task: TodoTask, now: Date, lead: NotificationLeadTime) -> Event? {
            guard let deadline = task.deadLine else { return nil }

            // 🔵 Manual Snooze (independent from notification-action snooze)
            if let manual = task.manualSnoozeUntil,
               manual > now {
                return Event(
                    id: "task.\(task.id.uuidString).manualSnooze",
                    date: manual,
                    type: "manualSnooze"
                )
            }

            // 🔥 Existing notification snooze
            if let snooze = task.snoozeUntil,
               snooze > now {
                return Event(
                    id: "task.\(task.id.uuidString).snooze",
                    date: snooze,
                    type: "snooze"
                )
            }

            // 🔥 Existing logic
            if deadline <= now {
                return nil
            }

            var candidates: [Event] = []

            // 🔵 Global
            if !lead.isNone {
                let calendar = Calendar.current
                if let globalDate = calendar.date(byAdding: .day, value: -lead.rawValue, to: deadline),
                   globalDate > now {
                    candidates.append(Event(
                        id: "task.\(task.id.uuidString).global",
                        date: globalDate,
                        type: "global"
                    ))
                }
            }

            // 🔵 Reminder
            if let minutes = task.reminderOffsetMinutes,
               let reminderDate = Calendar.current.date(byAdding: .minute, value: -minutes, to: deadline),
               reminderDate > now {
                candidates.append(Event(
                    id: "task.\(task.id.uuidString).reminder",
                    date: reminderDate,
                    type: "reminder"
                ))
            }

            // 🔵 Deadline (always if future)
            let deadlineEvent = Event(
                id: "task.\(task.id.uuidString).deadline",
                date: deadline,
                type: "deadline"
            )

            // 🔥 Legacy fix:
            // old versions could schedule GLOBAL or REMINDER
            // exactly at deadline.
            // In that case ALWAYS prefer the dedicated deadline event.
            candidates.removeAll {
                ($0.type == "global" || $0.type == "reminder") &&
                abs($0.date.timeIntervalSince(deadline)) < 1
            }

            candidates.append(deadlineEvent)

            return candidates.min(by: { $0.date < $1.date })
        }
    }

    // MARK: - NEXT TRIGGER (single source of truth)

    private func nextTrigger(for task: TodoTask, now: Date) -> (id: String, date: Date, type: String)? {
        let lead = NotificationLeadTime(
            safeRawValue: UserDefaults.standard.integer(forKey: "notificationLeadTimeDays")
        )

        guard let event = TaskEventCalculator.nextEvent(for: task, now: now, lead: lead) else {
            return nil
        }

        return (event.id, event.date, event.type)
    }
    
    
    // MARK: - REBUILD
    
    private func rebuild(_ tasks: [TodoTask]) async {
        let rebuildStart = Date()
        let center = UNUserNotificationCenter.current()
        let now = Date()
       
        let requests = await center.pendingNotificationRequests()
        
        var existing: [String: UNNotificationRequest] = [:]
        for req in requests {
            existing[req.identifier] = req
        }
        
        var expectedIDs: Set<String> = []
        
        func addOrUpdate(
            id: String,
            content: UNNotificationContent,
            trigger: UNNotificationTrigger
        ) async {
            
            expectedIDs.insert(id)
            
            if let existingReq = existing[id] {
                
                // 🔥 controlla TUTTO, non solo body
                // 🔥 FIX: considera anche il trigger (data)

                var isSame = false

                if let oldTrigger = existingReq.trigger as? UNCalendarNotificationTrigger,
                   let newTrigger = trigger as? UNCalendarNotificationTrigger {
                    
                    isSame = oldTrigger.nextTriggerDate() == newTrigger.nextTriggerDate()
                }
                else if let oldTrigger = existingReq.trigger as? UNTimeIntervalNotificationTrigger,
                        let newTrigger = trigger as? UNTimeIntervalNotificationTrigger {
                    
                    isSame = abs(oldTrigger.timeInterval - newTrigger.timeInterval) < 1
                }

                if isSame &&
                   existingReq.content.body == content.body &&
                   existingReq.content.title == content.title {
                    return
                }
                
                center.removePendingNotificationRequests(withIdentifiers: [id])
            }
            
            let request = UNNotificationRequest(
                identifier: id,
                content: content,
                trigger: trigger
            )
            
            do {
                try await center.add(request)
            } catch {
            #if DEBUG
                AppLogger.notifications.error("Notification scheduling failed: \(error.localizedDescription)")
            #endif
            }
        }
        
        for task in tasks {
            
            guard !task.isCompleted else { continue }
            
            guard let next = nextTrigger(for: task, now: now) else {
                continue
            }
            let badgeAtTrigger = computeBadgeCount(at: next.date, tasks: tasks)

            let content: UNMutableNotificationContent
            
            switch next.type {
                
            case "manualSnooze":
                content = baseContent(
                    task,
                    title: String(localized: "⏲️ Snoozed")
                )
                
            case "snooze":
                content = baseContent(task, title: String(localized: "⏲️ Snoozed"))

            case "reminder":
                let minutes = task.reminderOffsetMinutes ?? 0
                let reminderTitle: String
                if minutes < 60 {
                    if minutes == 1 {
                        reminderTitle = String(localized: "🔔 In 1 minute!")
                    } else {
                        reminderTitle = String(localized: "🔔 In \(minutes) minutes!")
                    }
                } else if minutes < 1440 {
                    let hours = minutes / 60
                    if hours == 1 {
                        reminderTitle = String(localized: "🔔 In 1 hour!")
                    } else {
                        reminderTitle = String(localized: "🔔 In \(hours) hours!")
                    }
                } else {
                    let days = minutes / 1440
                    if days == 1 {
                        reminderTitle = String(localized: "🔔 In 1 day!")
                    } else {
                        reminderTitle = String(localized: "🔔 In \(days) days!")
                    }
                }
                content = baseContent(task, title: reminderTitle)

            case "global":
                let leadDays = NotificationLeadTime(
                    safeRawValue: UserDefaults.standard.integer(forKey: "notificationLeadTimeDays")
                ).rawValue
                
                let title: String
                if leadDays == 1 {
                    title = String(localized: "⏱️ In 1 day!")
                } else {
                    title = String(localized: "⏱️ In \(leadDays) days!")
                }
                content = baseContent(task, title: title)

            case "deadline":
                content = baseContent(task, title: String(localized: "⏰ Overdue"))

            default:
                content = baseContent(task, title: String(localized: "Reminder"))
            }
            content.badge = NSNumber(value: badgeAtTrigger)
            content.userInfo["type"] = next.type
            
            let rawInterval = next.date.timeIntervalSinceNow

            // 🔥 Prevent valid reminder/global notifications from being lost
            // when rebuild happens too close to the trigger time.
            // Instead of skipping them, reschedule with a small safe delay.
            let interval: TimeInterval

            if (next.type == "reminder" || next.type == "global") && rawInterval <= 2 {
                interval = 3
            } else {
                interval = max(rawInterval, 5)
            }

            // 🔥 Small stable stagger to reduce iOS notification stacking/grouping
            // when many different tasks fire at the exact same time.
            let spread = Double(abs(task.id.uuidString.hashValue % 3))
            let finalInterval = interval + spread
            let trigger = UNTimeIntervalNotificationTrigger(
                timeInterval: finalInterval,
                repeats: false
            )
            
            await addOrUpdate(
                id: next.id,
                content: content,
                trigger: trigger
            )
        }
        
        // Prevent stale rebuild cleanup
        guard rebuildStart >= self.lastRebuild else { return }
        
        let toRemove = existing.keys.filter { id in
            id.starts(with: "task.") && !expectedIDs.contains(id)
        }
        
        center.removePendingNotificationRequests(withIdentifiers: toRemove)

        // 🔥 FINAL SYNC: ensure badge always matches latest state
        let finalBadge = computeBadgeCount(from: tasks)
        let showBadge = UserDefaults.standard.bool(forKey: "showAppBadge")
        applyBadge(showBadge ? finalBadge : 0)
    }
    
    // MARK: - ACTIONS
    
    
    
    // MARK: - CONTENT (UI IDENTICA)
    
    private func baseContent(_ task: TodoTask, title: String) -> UNMutableNotificationContent {
        
        let c = UNMutableNotificationContent()
        
        c.title = title              // 🔥 UI ORIGINALE
        c.body = task.title         // 🔥 UI ORIGINALE
        
        let soundName = UserDefaults.standard.string(forKey: "notificationSoundName") ?? ""
        
        if soundName.isEmpty {
            c.sound = .default
        } else {
            c.sound = UNNotificationSound(named: UNNotificationSoundName(rawValue: soundName))
        }
        c.categoryIdentifier = "TASK_REMINDER"
        c.userInfo["taskID"] = task.id.uuidString
        
        return c
    }
    
    // MARK: - BADGE
    private func computeBadgeCount(at date: Date, tasks: [TodoTask]) -> Int {

        TaskBadgePolicy.badgeCount(
            tasks: tasks,
            referenceDate: date
        )
    }
    
    
    private func computeBadgeCount(from tasks: [TodoTask]) -> Int {

        TaskBadgePolicy.badgeCount(
            tasks: tasks,
            referenceDate: Date()
        )
    }
    
    private func applyBadge(_ count: Int) {
        
        UNUserNotificationCenter.current().setBadgeCount(count) { error in
#if DEBUG
            if let error {
                AppLogger.notifications.error("Badge error: \(error.localizedDescription)")
            }
#endif
        }
    }

    @MainActor
    func rebuildDocumentNotifications() async {

        guard let context = modelContainer?.mainContext else {
            return
        }

        let documents =
            (try? context.fetch(
                FetchDescriptor<DocumentItem>()
            )) ?? []

        for document in documents {

            removeDocumentNotification(
                documentID: document.id
            )

            guard document.notificationEnabled,
                  let expiryDate = document.expiryDate else {
                continue
            }

            let triggerDate = Calendar.current.date(
                byAdding: .day,
                value: -document.notificationDaysBefore,
                to: expiryDate
            )

            guard let triggerDate else {
                continue
            }


// documenti con reminder oltre 1 anno → non occupano slot di notifica;
// quando entreranno nell’orizzonte di 1 anno verranno schedulati automaticamente dai rebuild già presenti;
            
            let oneYearFromNow = Calendar.current.date(
                byAdding: .year,
                value: 1,
                to: Date()
            ) ?? .distantFuture

            guard triggerDate <= oneYearFromNow else {
                continue
            }
//
            
            
            await scheduleDocumentNotification(
                id: document.id,
                title: document.name,
                triggerDate: triggerDate
            )
        }
    }

    @MainActor
    func removeDocumentNotification(
        documentID: UUID
    ) {

        let identifier = "document.\(documentID.uuidString)"

        UNUserNotificationCenter.current()
            .removePendingNotificationRequests(
                withIdentifiers: [identifier]
            )

        UNUserNotificationCenter.current()
            .removeDeliveredNotifications(
                withIdentifiers: [identifier]
            )
    }

    @MainActor
    func scheduleDocumentNotification(
        id: UUID,
        title: String,
        triggerDate: Date
    ) async {

        guard triggerDate > Date() else { return }

        let content = UNMutableNotificationContent()

        content.title = String(localized: "Document Expiring")
        content.body = title

        let soundName =
            UserDefaults.standard.string(
                forKey: "notificationSoundName"
            ) ?? ""

        if soundName.isEmpty {
            content.sound = .default
        } else {
            content.sound = UNNotificationSound(
                named: UNNotificationSoundName(
                    rawValue: soundName
                )
            )
        }

        let interval = triggerDate.timeIntervalSinceNow

        guard interval > 1 else { return }

        let trigger = UNTimeIntervalNotificationTrigger(
            timeInterval: interval,
            repeats: false
        )

        let request = UNNotificationRequest(
            identifier: "document.\(id.uuidString)",
            content: content,
            trigger: trigger
        )

        try? await UNUserNotificationCenter.current()
            .add(request)
    }
}

// MARK: - DELEGATE

extension NotificationManager: UNUserNotificationCenterDelegate {
    
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        return [.banner, .sound, .badge]
    }
    
    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse
    ) async {
        
        guard let taskID = response.notification.request.content.userInfo["taskID"] as? String else { return }
        
        
        // 1️⃣ salva azione (come già fai)
        switch response.actionIdentifier {
            
        case UNNotificationDefaultActionIdentifier:
            // 🔥 TAP sulla notifica → completa task
            UserDefaults.standard.set(taskID, forKey: "completeTaskFromNotification")
            
        case "OPEN_APP":
            break // iOS apre già l'app automaticamente
            
        case "SNOOZE_5", "SNOOZE_15", "SNOOZE_30", "SNOOZE_60":
            if let container = self.modelContainer {
                let context = container.mainContext

                let interval: TimeInterval
                switch response.actionIdentifier {
                case "SNOOZE_5": interval = 300
                case "SNOOZE_15": interval = 900
                case "SNOOZE_30": interval = 1800
                case "SNOOZE_60": interval = 3600
                default: interval = 300
                }

                if let uuid = UUID(uuidString: taskID) {
                    let descriptor = FetchDescriptor<TodoTask>(
                        predicate: #Predicate { $0.id == uuid }
                    )

                    if let task = try? context.fetch(descriptor).first {
                        let rawDate = Date().addingTimeInterval(interval)

                        let type = response.notification.request.content.userInfo["type"] as? String

                        // 🔵 Manual Snooze: completely independent from notification snooze.
                        // Never enforce the task deadline.
                        if type == "manualSnooze" {

                            task.manualSnoozeUntil = rawDate
                            task.snoozeUntil = nil
                        } else if let deadline = task.deadLine {

                            if type == "deadline" {

                                // ✅ Snooze from deadline is ALWAYS allowed
                                task.snoozeUntil = rawDate

                            } else {

                                // ❌ Existing notification snooze must not exceed the deadline
                                if rawDate >= deadline {

                                    let state = UIApplication.shared.applicationState

                                    if !self.isAppLaunching && state != .background {
                                        NotificationCenter.default.post(
                                            name: .snoozeRejectedDueToDeadline,
                                            object: nil
                                        )
                                    }

                                    let content = UNMutableNotificationContent()
                                    content.title = String(localized: "Snooze not scheduled")
                                    content.body = String(localized: "Snooze exceeds the deadline. No snooze notification will be scheduled. The deadline notification will still occur.")
                                    content.sound = .default

                                    let trigger = UNTimeIntervalNotificationTrigger(
                                        timeInterval: 5,
                                        repeats: false
                                    )

                                    let request = UNNotificationRequest(
                                        identifier: "snoozeRejected.\(UUID().uuidString)",
                                        content: content,
                                        trigger: trigger
                                    )

                                    try? await UNUserNotificationCenter.current().add(request)

                                } else {

                                    task.snoozeUntil = rawDate

                                }
                            }

                        } else {

                            task.snoozeUntil = rawDate

                        }

                        try? context.save()
                        context.processPendingChanges()
                    }
                }
            }
            
        default:
            break
        }
        
        // 2️⃣ Apply notification action changes immediately
        await MainActor.run {
            
            if let container = self.modelContainer {
                let context = container.mainContext
                
                NotificationActionProcessor.shared.processAll(using: context)
                context.processPendingChanges()
                
                // Immediate badge refresh
                let tasks = self.fetchTasks(using: context)
                let badge = self.computeBadgeCount(from: tasks)
                let showBadge = UserDefaults.standard.bool(forKey: "showAppBadge")
                self.applyBadge(showBadge ? badge : 0)
            }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                NotificationManager.shared.refresh()
            }
            
            NotificationCenter.default.post(
                name: .attachmentsShouldRefresh,
                object: nil
            )
        }
    }
}

//# MARK: - Notification Extension

extension Notification.Name {
    static let snoozeClamped = Notification.Name("snoozeClamped")
    static let snoozeRejectedDueToDeadline = Notification.Name("snoozeRejectedDueToDeadline")
    static let cloudKitDidStabilize = Notification.Name("cloudKitDidStabilize")
}
