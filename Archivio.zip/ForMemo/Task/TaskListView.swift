import SwiftUI
import SwiftData
import PhotosUI
import Observation
import WeatherKit
import CoreLocation
import os

extension Notification.Name {

  static let taskDidChange = Notification.Name("taskDidChange")
}

// MARK: - TaskTagFilter

enum TaskTagFilter: Hashable, Identifiable {

  case all

  case none

  case tag(TaskMainTag)

  var id: String {

    switch self {

    case .all:

      return "all"

    case .none:

      return "none"

    case .tag(let tag):

      return tag.rawValue

    }

  }

}

// MARK: - TaskListView

struct TaskListView: View {

  @Environment(\.modelContext) private var modelContext

  @Environment(AppSettings.self) private var settings

  @Environment(\.scenePhase) private var scenePhase



//  @State private var todoQuery: [TodoTask] = []
  @State private var draftTask: TodoTask?
    @State private var completedQuery: [TodoTask] = []
    
  private struct SelectedWeatherDay: Identifiable {

    let date: Date

    var id: Date { date }

  }

  @State private var searchText = ""

  @State private var debouncedSearchText = ""

  @State private var showCompleted = false

  @State private var showNewTask = false

  @State private var showQuickGuide = false

  @State private var showWeatherForecast = false

  @State private var selectedWeatherDay: SelectedWeatherDay?

  @State private var selectedTagFilter: TaskTagFilter = .all

  @State private var selectedPriorityFilter: TaskPriority? = nil

  @State private var selectedPeriodFilter: TaskPeriodFilter? = nil

    @State private var databaseIsEmpty: Bool?
    
    @State private var legacyRecurrenceTask: TodoTask?


  private var listStyleChoice: TaskListStyle {

    settings.taskListStyle

  }

  private var listStyleBinding: Binding<TaskListStyle> {

    Binding(

      get: { settings.taskListStyle },

      set: { settings.taskListStyle = $0 }

    )

  }

  private var showDateEveryRow: Bool {

    settings.showDateEveryRow

  }

  private var showDateEveryRowBinding: Binding<Bool> {

    Binding(

      get: { settings.showDateEveryRow },

      set: { settings.showDateEveryRow = $0 }

    )

  }

  private var confirmTaskDeletion: Bool {

    settings.confirmTaskDeletion

  }

  @State private var taskPendingDeletion: TodoTask?

  @State private var filteredTodoTasksCache: [TodoTask] = []
    @State private var activeOverdueOffset = 0
    @State private var activeFutureOffset = 0
    @State private var activeNoDeadlineOffset = 0
    @State private var activeHasMore = true
    @State private var activeFetchNow = Date()
    @State private var isLoadingMoreActive = false
    @State private var activeListRefreshInProgress = false
    @State private var activeFetchGeneration = 0
    @State private var activePaginationTask: Task<Void, Never>?
    @State private var activeTaskCount = 0
    @State private var completedTaskCount = 0
    @State private var completedOffset = 0
    @State private var completedHasMore = true
    @State private var isLoadingMoreCompleted = false
    
    @State private var isDeletingRecurrence = false
    
    
  private enum ActiveTaskFetchPhase: Sendable {

    case overdue

    case future

    case noDeadline

  }

    private func activeTaskPredicate(
        phase: ActiveTaskFetchPhase,
        now: Date,
        periodStart: Date,
        periodEnd: Date,
        hasPeriodRange: Bool,
        noDeadlineOnly: Bool,
        hasSearch: Bool,
        searchValue: String
    ) -> Predicate<TodoTask> {

    let hasPriorityFilter = selectedPriorityFilter != nil

    let priorityValue = selectedPriorityFilter?.rawValue ?? 0

    let isNoTagFilter: Bool

    let hasTagFilter: Bool

    let tagValue: String

    switch selectedTagFilter {

    case .all:

      isNoTagFilter = false

      hasTagFilter = false

      tagValue = ""

    case .none:

      isNoTagFilter = true

      hasTagFilter = false

      tagValue = ""

    case .tag(let tag):

      isNoTagFilter = false

      hasTagFilter = true

      tagValue = tag.rawValue

    }

    switch phase {

    case .overdue:

      return #Predicate<TodoTask> {

        !$0.isCompleted &&
          (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
        !noDeadlineOnly &&

        $0.deadLine != nil &&

        $0.deadLine! < now &&

        (

          !hasPeriodRange ||

          (

            $0.deadLine! >= periodStart &&

            $0.deadLine! < periodEnd

          )

        ) &&

        (

          !hasPriorityFilter ||

          $0.priorityRaw == priorityValue

        ) &&

        (

          (isNoTagFilter && $0.mainTagRaw == nil) ||

          (

            !isNoTagFilter &&

            (

              !hasTagFilter ||

              $0.mainTagRaw == tagValue

            )

          )

        )

      }

    case .future:

      return #Predicate<TodoTask> {

        !$0.isCompleted &&
          (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
        !noDeadlineOnly &&

        $0.deadLine != nil &&

        $0.deadLine! >= now &&

        (

          !hasPeriodRange ||

          (

            $0.deadLine! >= periodStart &&

            $0.deadLine! < periodEnd

          )

        ) &&

        (

          !hasPriorityFilter ||

          $0.priorityRaw == priorityValue

        ) &&

        (

          (isNoTagFilter && $0.mainTagRaw == nil) ||

          (

            !isNoTagFilter &&

            (

              !hasTagFilter ||

              $0.mainTagRaw == tagValue

            )

          )

        )

      }

    case .noDeadline:

      return #Predicate<TodoTask> {

        !$0.isCompleted &&
          (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
        $0.deadLine == nil &&

        !hasPeriodRange &&

        (

          !hasPriorityFilter ||

          $0.priorityRaw == priorityValue

        ) &&

        (

          (isNoTagFilter && $0.mainTagRaw == nil) ||

          (

            !isNoTagFilter &&

            (

              !hasTagFilter ||

              $0.mainTagRaw == tagValue

            )

          )

        )

      }

    }

  }

  private func activeTaskPeriodRange(

    now: Date

  ) -> (

    start: Date,

    end: Date,

    hasRange: Bool,

    noDeadlineOnly: Bool,

    invalid: Bool

  ) {

    let calendar = Calendar.current

    guard let period = selectedPeriodFilter else {

      return (

        .distantPast,

        .distantFuture,

        false,

        false,

        false

      )

    }

    switch period {

    case .noDeadline:

      return (

        .distantPast,

        .distantFuture,

        false,

        true,

        false

      )

    case .today:

      let start = calendar.startOfDay(for: now)

      guard let end = calendar.date(

        byAdding: .day,

        value: 1,

        to: start

      ) else {

        return (.distantPast, .distantFuture, false, false, true)

      }

      return (start, end, true, false, false)

    case .tomorrow:

      guard

        let start = calendar.date(

          byAdding: .day,

          value: 1,

          to: calendar.startOfDay(for: now)

        ),

        let end = calendar.date(

          byAdding: .day,

          value: 1,

          to: start

        )

      else {

        return (.distantPast, .distantFuture, false, false, true)

      }

      return (start, end, true, false, false)

    case .dayAfterTomorrow:

      guard

        let start = calendar.date(

          byAdding: .day,

          value: 2,

          to: calendar.startOfDay(for: now)

        ),

        let end = calendar.date(

          byAdding: .day,

          value: 1,

          to: start

        )

      else {

        return (.distantPast, .distantFuture, false, false, true)

      }

      return (start, end, true, false, false)

    case .thisWeekend:

      guard let weekend = calendar.nextWeekend(startingAfter: now) else {

        return (.distantPast, .distantFuture, false, false, true)

      }

      return (

        weekend.start,

        weekend.end,

        true,

        false,

        false

      )

    case .nextWeekend:

      guard

        let firstWeekend = calendar.nextWeekend(startingAfter: now),

        let secondWeekend = calendar.nextWeekend(

          startingAfter: firstWeekend.end

        )

      else {

        return (.distantPast, .distantFuture, false, false, true)

      }

      return (

        secondWeekend.start,

        secondWeekend.end,

        true,

        false,

        false

      )

    case .thisWeek:

      guard let interval = calendar.dateInterval(

        of: .weekOfYear,

        for: now

      ) else {

        return (.distantPast, .distantFuture, false, false, true)

      }

      return (

        interval.start,

        interval.end,

        true,

        false,

        false

      )

    case .nextWeek:

      guard

        let nextWeek = calendar.date(

          byAdding: .weekOfYear,

          value: 1,

          to: now

        ),

        let interval = calendar.dateInterval(

          of: .weekOfYear,

          for: nextWeek

        )

      else {

        return (.distantPast, .distantFuture, false, false, true)

      }

      return (

        interval.start,

        interval.end,

        true,

        false,

        false

      )

    case .thisMonth:

      guard let interval = calendar.dateInterval(

        of: .month,

        for: now

      ) else {

        return (.distantPast, .distantFuture, false, false, true)

      }

      return (

        interval.start,

        interval.end,

        true,

        false,

        false

      )

    }

  }

    
    @MainActor
    private func updateActiveTaskCount() {
        let now = Date()
        let period = activeTaskPeriodRange(now: now)

        guard !period.invalid else {
            activeTaskCount = 0
            return
        }

        let hasSearch = !debouncedSearchText.isEmpty
        let searchValue = debouncedSearchText

        let phases: [ActiveTaskFetchPhase]

        if period.noDeadlineOnly {
            phases = [.noDeadline]
        } else if period.hasRange {
            phases = [.overdue, .future]
        } else {
            phases = [.overdue, .future, .noDeadline]
        }

        do {
            var total = 0

            for phase in phases {
                let predicate = activeTaskPredicate(
                    phase: phase,
                    now: now,
                    periodStart: period.start,
                    periodEnd: period.end,
                    hasPeriodRange: period.hasRange,
                    noDeadlineOnly: period.noDeadlineOnly,
                    hasSearch: hasSearch,
                    searchValue: searchValue
                )

                let descriptor = FetchDescriptor<TodoTask>(
                    predicate: predicate
                )

                total += try modelContext.fetchCount(descriptor)
            }

            activeTaskCount = total

        } catch {
            AppLogger.persistence.error(
                "TaskList active task count failed: \(error.localizedDescription)"
            )
        }
    }
    @MainActor
    private func checkDatabaseIsEmpty() {
        var descriptor = FetchDescriptor<TodoTask>()
        descriptor.fetchLimit = 1

        do {
            databaseIsEmpty = try modelContext.fetch(descriptor).isEmpty
        } catch {
            AppLogger.persistence.error(
                "TaskList database empty check failed: \(error.localizedDescription)"
            )

            // In caso di errore non possiamo dichiarare il database vuoto.
            databaseIsEmpty = nil
        }
    }

    @MainActor
    private func refreshActiveList() {
        activePaginationTask?.cancel()
        activePaginationTask = nil
        isLoadingMoreActive = false

        activeListRefreshInProgress = true
        activeFetchGeneration &+= 1
        let refreshGeneration = activeFetchGeneration

        checkDatabaseIsEmpty()
        fetchActiveTasks()
        updateActiveTaskCount()

        // Let SwiftUI commit the refreshed datasource before an onAppear at the
        // page boundary can request another page.
        DispatchQueue.main.async {
            guard refreshGeneration == activeFetchGeneration else {
                return
            }
            activeListRefreshInProgress = false
        }
    }

  @MainActor

  private func fetchActiveTasks() {
    
    AppLogger.persistence.debug(

      "TaskList fetchActiveTasks START"

    )

    let now = Date()
    activeFetchNow = now

    let period = activeTaskPeriodRange(now: now)

    if period.invalid {

//      todoQuery = []

      filteredTodoTasksCache = []

      return

    }

    let phases: [ActiveTaskFetchPhase]

    if period.noDeadlineOnly {

      phases = [.noDeadline]

    } else if period.hasRange {

      phases = [.overdue, .future]

    } else {

      phases = [.overdue, .future, .noDeadline]

    }

    // During a refresh caused by an edit/delete/complete/reschedule, do not
    // collapse the datasource back to the first 100 rows. Keep the number of
    // already materialized rows so SwiftUI/List can preserve the current
    // scroll position, especially around 100/200/300 item boundaries.
    let refreshLimit = max(100, filteredTodoTasksCache.count)

    var result: [TodoTask] = []

    result.reserveCapacity(refreshLimit)
      activeOverdueOffset = 0
      activeFutureOffset = 0
      activeNoDeadlineOffset = 0
      activeHasMore = false

    do {

      for phase in phases {

        let remaining = refreshLimit - result.count

        guard remaining > 0 else {

          break

        }

          let predicate = activeTaskPredicate(
              phase: phase,
              now: now,
              periodStart: period.start,
              periodEnd: period.end,
              hasPeriodRange: period.hasRange,
              noDeadlineOnly: period.noDeadlineOnly,
              hasSearch: !debouncedSearchText.isEmpty,
              searchValue: debouncedSearchText
          )

        let sortDescriptors: [SortDescriptor<TodoTask>]

        switch phase {

        case .overdue, .future:

          sortDescriptors = [

            SortDescriptor(

              \TodoTask.deadLine,

              order: .forward

            ),

            SortDescriptor(

              \TodoTask.id,

              order: .forward

            )

          ]

        case .noDeadline:

          sortDescriptors = [

            SortDescriptor(

              \TodoTask.id,

              order: .forward

            )

          ]

        }

        var descriptor = FetchDescriptor<TodoTask>(

          predicate: predicate,

          sortBy: sortDescriptors

        )

        descriptor.fetchLimit = remaining

          let page = try modelContext.fetch(descriptor)

          result.append(contentsOf: page)

          switch phase {
          case .overdue:
              activeOverdueOffset += page.count

          case .future:
              activeFutureOffset += page.count

          case .noDeadline:
              activeNoDeadlineOffset += page.count
          }

      }

//      todoQuery = result

      AppLogger.persistence.debug(

        "TaskList fetchActiveTasks RESULT: \(result.count) active tasks"
      )
        filteredTodoTasksCache = result
        activeHasMore = result.count == refreshLimit

      AppLogger.persistence.debug(

        "TaskList optimized fetch: \(result.count) tasks"

      )

    } catch {

      AppLogger.persistence.error(

        "TaskList optimized fetch failed: \(error.localizedDescription)"

      )

      filteredTodoTasksCache = []

    }

  }
    private struct ActivePaginationResult: Sendable {
        let ids: [UUID]
        let overdueCount: Int
        let futureCount: Int
        let noDeadlineCount: Int
        let hasMore: Bool
    }

    @MainActor
    private func loadMoreActiveTasks() {
        guard !activeListRefreshInProgress, !isLoadingMoreActive, activeHasMore else {
            return
        }

        isLoadingMoreActive = true

        let generation = activeFetchGeneration
        let now = activeFetchNow
        let period = activeTaskPeriodRange(now: now)
        let container = modelContext.container

        guard !period.invalid else {
            isLoadingMoreActive = false
            activeHasMore = false
            return
        }

        let phases: [ActiveTaskFetchPhase]
        if period.noDeadlineOnly {
            phases = [.noDeadline]
        } else if period.hasRange {
            phases = [.overdue, .future]
        } else {
            phases = [.overdue, .future, .noDeadline]
        }

        let overdueOffset = activeOverdueOffset
        let futureOffset = activeFutureOffset
        let noDeadlineOffset = activeNoDeadlineOffset
        let searchValue = debouncedSearchText
        let hasSearch = !searchValue.isEmpty
        let hasPriorityFilter = selectedPriorityFilter != nil
        let priorityValue = selectedPriorityFilter?.rawValue ?? 0

        let isNoTagFilter: Bool
        let hasTagFilter: Bool
        let tagValue: String
        switch selectedTagFilter {
        case .all:
            isNoTagFilter = false
            hasTagFilter = false
            tagValue = ""
        case .none:
            isNoTagFilter = true
            hasTagFilter = false
            tagValue = ""
        case .tag(let tag):
            isNoTagFilter = false
            hasTagFilter = true
            tagValue = tag.rawValue
        }

        let periodStart = period.start
        let periodEnd = period.end
        let hasPeriodRange = period.hasRange
        let noDeadlineOnly = period.noDeadlineOnly

        activePaginationTask = Task { @MainActor in
            defer {
                isLoadingMoreActive = false
                activePaginationTask = nil
            }

            let result = await Task.detached(priority: .userInitiated) {
                let backgroundContext = ModelContext(container)
                var ids: [UUID] = []
                ids.reserveCapacity(100)

                var nextOverdueOffset = overdueOffset
                var nextFutureOffset = futureOffset
                var nextNoDeadlineOffset = noDeadlineOffset

                do {
                    for phase in phases {
                        let remaining = 100 - ids.count
                        guard remaining > 0 else { break }

                        let offset: Int
                        switch phase {
                        case .overdue:
                            offset = nextOverdueOffset
                        case .future:
                            offset = nextFutureOffset
                        case .noDeadline:
                            offset = nextNoDeadlineOffset
                        }

                        let predicate: Predicate<TodoTask>
                        switch phase {
                        case .overdue:
                            predicate = #Predicate<TodoTask> {
                                !$0.isCompleted &&
                                (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
                                !noDeadlineOnly &&
                                $0.deadLine != nil &&
                                $0.deadLine! < now &&
                                (!hasPeriodRange || ($0.deadLine! >= periodStart && $0.deadLine! < periodEnd)) &&
                                (!hasPriorityFilter || $0.priorityRaw == priorityValue) &&
                                ((isNoTagFilter && $0.mainTagRaw == nil) ||
                                 (!isNoTagFilter && (!hasTagFilter || $0.mainTagRaw == tagValue)))
                            }
                        case .future:
                            predicate = #Predicate<TodoTask> {
                                !$0.isCompleted &&
                                (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
                                !noDeadlineOnly &&
                                $0.deadLine != nil &&
                                $0.deadLine! >= now &&
                                (!hasPeriodRange || ($0.deadLine! >= periodStart && $0.deadLine! < periodEnd)) &&
                                (!hasPriorityFilter || $0.priorityRaw == priorityValue) &&
                                ((isNoTagFilter && $0.mainTagRaw == nil) ||
                                 (!isNoTagFilter && (!hasTagFilter || $0.mainTagRaw == tagValue)))
                            }
                        case .noDeadline:
                            predicate = #Predicate<TodoTask> {
                                !$0.isCompleted &&
                                (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
                                $0.deadLine == nil &&
                                !hasPeriodRange &&
                                (!hasPriorityFilter || $0.priorityRaw == priorityValue) &&
                                ((isNoTagFilter && $0.mainTagRaw == nil) ||
                                 (!isNoTagFilter && (!hasTagFilter || $0.mainTagRaw == tagValue)))
                            }
                        }

                        let sortDescriptors: [SortDescriptor<TodoTask>]
                        switch phase {
                        case .overdue, .future:
                            sortDescriptors = [
                                SortDescriptor(\TodoTask.deadLine, order: .forward),
                                SortDescriptor(\TodoTask.id, order: .forward)
                            ]
                        case .noDeadline:
                            sortDescriptors = [
                                SortDescriptor(\TodoTask.id, order: .forward)
                            ]
                        }

                        var descriptor = FetchDescriptor<TodoTask>(
                            predicate: predicate,
                            sortBy: sortDescriptors
                        )
                        descriptor.fetchOffset = offset
                        descriptor.fetchLimit = remaining

                        let page = try backgroundContext.fetch(descriptor)
                        guard !page.isEmpty else { continue }

                        ids.append(contentsOf: page.map(\.id))

                        switch phase {
                        case .overdue:
                            nextOverdueOffset += page.count
                        case .future:
                            nextFutureOffset += page.count
                        case .noDeadline:
                            nextNoDeadlineOffset += page.count
                        }
                    }

                    return ActivePaginationResult(
                        ids: ids,
                        overdueCount: nextOverdueOffset,
                        futureCount: nextFutureOffset,
                        noDeadlineCount: nextNoDeadlineOffset,
                        hasMore: ids.count == 100
                    )
                } catch {
                    await AppLogger.persistence.error(
                        "TaskList background pagination failed: \(error.localizedDescription)"
                    )
                    return ActivePaginationResult(
                        ids: [],
                        overdueCount: overdueOffset,
                        futureCount: futureOffset,
                        noDeadlineCount: noDeadlineOffset,
                        hasMore: false
                    )
                }
            }.value

            guard !Task.isCancelled,
                  generation == activeFetchGeneration,
                  !activeListRefreshInProgress else {
                return
            }

            guard !result.ids.isEmpty else {
                activeHasMore = false
                return
            }

            do {
                let ids = result.ids
                let descriptor = FetchDescriptor<TodoTask>(
                    predicate: #Predicate<TodoTask> { ids.contains($0.id) }
                )
                let fetchedTasks = try modelContext.fetch(descriptor)
                let tasksByID = Dictionary(uniqueKeysWithValues: fetchedTasks.map { ($0.id, $0) })
                let orderedTasks = result.ids.compactMap { tasksByID[$0] }

                let existingTaskIDs = Set(filteredTodoTasksCache.map(\.id))
                let uniqueNewTasks = orderedTasks.filter { !existingTaskIDs.contains($0.id) }

                activeOverdueOffset = result.overdueCount
                activeFutureOffset = result.futureCount
                activeNoDeadlineOffset = result.noDeadlineCount
                filteredTodoTasksCache.append(contentsOf: uniqueNewTasks)
                activeHasMore = result.hasMore
            } catch {
                AppLogger.persistence.error(
                    "TaskList main pagination materialization failed: \(error.localizedDescription)"
                )
            }

        }
    }

    private func completedTaskPredicate(
        hasSearch: Bool,
        searchValue: String,
        hasPriorityFilter: Bool,
        priorityValue: Int,
        isNoTagFilter: Bool,
        hasTagFilter: Bool,
        tagValue: String,
        hasPeriodRange: Bool,
        noDeadlineOnly: Bool,
        periodStart: Date,
        periodEnd: Date
    ) -> Predicate<TodoTask> {

        #Predicate<TodoTask> {
            $0.isCompleted &&
            (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
            (!hasPriorityFilter || $0.priorityRaw == priorityValue) &&
            (
                (!isNoTagFilter && !hasTagFilter) ||
                (isNoTagFilter && $0.mainTagRaw == nil) ||
                (hasTagFilter && $0.mainTagRaw == tagValue)
            ) &&
            (
                !hasPeriodRange ||
                (
                    $0.deadLine != nil &&
                    $0.deadLine! >= periodStart &&
                    $0.deadLine! < periodEnd
                )
            )
        }
    }
    
    
    private func completedNoDeadlinePredicate(
        hasSearch: Bool,
        searchValue: String,
        hasPriorityFilter: Bool,
        priorityValue: Int,
        isNoTagFilter: Bool,
        hasTagFilter: Bool,
        tagValue: String
    ) -> Predicate<TodoTask> {

        #Predicate<TodoTask> {
            $0.isCompleted &&
            (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
            (!hasPriorityFilter || $0.priorityRaw == priorityValue) &&
            (
                (!isNoTagFilter && !hasTagFilter) ||
                (isNoTagFilter && $0.mainTagRaw == nil) ||
                (hasTagFilter && $0.mainTagRaw == tagValue)
            ) &&
            $0.deadLine == nil
        }
    }
    
    private func completedPeriodPredicate(
        hasSearch: Bool,
        searchValue: String,
        hasPriorityFilter: Bool,
        priorityValue: Int,
        isNoTagFilter: Bool,
        hasTagFilter: Bool,
        tagValue: String,
        periodStart: Date,
        periodEnd: Date
    ) -> Predicate<TodoTask> {

        #Predicate<TodoTask> {
            $0.isCompleted &&
            (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
            (!hasPriorityFilter || $0.priorityRaw == priorityValue) &&
            (
                (!isNoTagFilter && !hasTagFilter) ||
                (isNoTagFilter && $0.mainTagRaw == nil) ||
                (hasTagFilter && $0.mainTagRaw == tagValue)
            ) &&
            $0.deadLine != nil &&
            $0.deadLine! >= periodStart &&
            $0.deadLine! < periodEnd
        }
    }
    
    private func completedAllPredicate(
        hasSearch: Bool,
        searchValue: String,
        hasPriorityFilter: Bool,
        priorityValue: Int,
        isNoTagFilter: Bool,
        hasTagFilter: Bool,
        tagValue: String
    ) -> Predicate<TodoTask> {

        #Predicate<TodoTask> {
            $0.isCompleted &&
            (!hasSearch || $0.title.localizedStandardContains(searchValue)) &&
            (!hasPriorityFilter || $0.priorityRaw == priorityValue) &&
            (
                (!isNoTagFilter && !hasTagFilter) ||
                (isNoTagFilter && $0.mainTagRaw == nil) ||
                (hasTagFilter && $0.mainTagRaw == tagValue)
            )
        }
    }

    @MainActor
    private func makeCompletedTaskPredicate(
        period: (
            start: Date,
            end: Date,
            hasRange: Bool,
            noDeadlineOnly: Bool,
            invalid: Bool
        ),
        hasSearch: Bool,
        searchValue: String,
        hasPriorityFilter: Bool,
        priorityValue: Int,
        isNoTagFilter: Bool,
        hasTagFilter: Bool,
        tagValue: String
    ) -> Predicate<TodoTask> {

        if period.noDeadlineOnly {
            return completedNoDeadlinePredicate(
                hasSearch: hasSearch,
                searchValue: searchValue,
                hasPriorityFilter: hasPriorityFilter,
                priorityValue: priorityValue,
                isNoTagFilter: isNoTagFilter,
                hasTagFilter: hasTagFilter,
                tagValue: tagValue
            )
        }

        if period.hasRange {
            return completedPeriodPredicate(
                hasSearch: hasSearch,
                searchValue: searchValue,
                hasPriorityFilter: hasPriorityFilter,
                priorityValue: priorityValue,
                isNoTagFilter: isNoTagFilter,
                hasTagFilter: hasTagFilter,
                tagValue: tagValue,
                periodStart: period.start,
                periodEnd: period.end
            )
        }

        return completedAllPredicate(
            hasSearch: hasSearch,
            searchValue: searchValue,
            hasPriorityFilter: hasPriorityFilter,
            priorityValue: priorityValue,
            isNoTagFilter: isNoTagFilter,
            hasTagFilter: hasTagFilter,
            tagValue: tagValue
        )
    }

    
    @MainActor
    private func fetchCompletedTasks() {
        completedOffset = 0
        completedHasMore = true
        isLoadingMoreCompleted = false

        AppLogger.persistence.debug(
            "TaskList fetchCompletedTasks START"
        )

        let now = Date()
    
        let period = activeTaskPeriodRange(now: now)

        guard !period.invalid else {
            completedQuery = []
            return
        }

        let hasSearch = !debouncedSearchText.isEmpty
        let searchValue = debouncedSearchText

        let hasPriorityFilter = selectedPriorityFilter != nil
        let priorityValue = selectedPriorityFilter?.rawValue ?? 0

        let isNoTagFilter: Bool
        let hasTagFilter: Bool
        let tagValue: String

        switch selectedTagFilter {
        case .all:
            isNoTagFilter = false
            hasTagFilter = false
            tagValue = ""

        case .none:
            isNoTagFilter = true
            hasTagFilter = false
            tagValue = ""

        case .tag(let tag):
            isNoTagFilter = false
            hasTagFilter = true
            tagValue = tag.rawValue
        }

        let predicate = makeCompletedTaskPredicate(
            period: period,
            hasSearch: hasSearch,
            searchValue: searchValue,
            hasPriorityFilter: hasPriorityFilter,
            priorityValue: priorityValue,
            isNoTagFilter: isNoTagFilter,
            hasTagFilter: hasTagFilter,
            tagValue: tagValue
        )

        var descriptor = FetchDescriptor<TodoTask>(
            predicate: predicate,
            sortBy: [
                SortDescriptor(
                    \TodoTask.completedAt,
                    order: .reverse
                ),
                SortDescriptor(
                    \TodoTask.id,
                    order: .forward
                )
            ]
        )
        descriptor.fetchOffset = completedOffset
        descriptor.fetchLimit = 100

        do {
            completedQuery = try modelContext.fetch(descriptor)
            completedOffset = completedQuery.count
            completedHasMore = completedQuery.count == 100

            AppLogger.persistence.debug(
                "TaskList fetchCompletedTasks RESULT: \(completedQuery.count) completed tasks"
            )
        } catch {
            AppLogger.persistence.error(
                "TaskList completed fetch failed: \(error.localizedDescription)"
            )

            completedQuery = []
        }
    }

    
    @MainActor
    private func loadMoreCompletedTasks() {
        guard completedHasMore, !isLoadingMoreCompleted else {
            return
        }

        isLoadingMoreCompleted = true

        let now = Date()
        let period = activeTaskPeriodRange(now: now)

        guard !period.invalid else {
            completedHasMore = false
            isLoadingMoreCompleted = false
            return
        }

        let hasSearch = !debouncedSearchText.isEmpty
        let searchValue = debouncedSearchText
        let hasPriorityFilter = selectedPriorityFilter != nil
        let priorityValue = selectedPriorityFilter?.rawValue ?? 0

        let isNoTagFilter: Bool
        let hasTagFilter: Bool
        let tagValue: String

        switch selectedTagFilter {
        case .all:
            isNoTagFilter = false
            hasTagFilter = false
            tagValue = ""

        case .none:
            isNoTagFilter = true
            hasTagFilter = false
            tagValue = ""

        case .tag(let tag):
            isNoTagFilter = false
            hasTagFilter = true
            tagValue = tag.rawValue
        }

        let predicate = makeCompletedTaskPredicate(
            period: period,
            hasSearch: hasSearch,
            searchValue: searchValue,
            hasPriorityFilter: hasPriorityFilter,
            priorityValue: priorityValue,
            isNoTagFilter: isNoTagFilter,
            hasTagFilter: hasTagFilter,
            tagValue: tagValue
        )

        var descriptor = FetchDescriptor<TodoTask>(
            predicate: predicate,
            sortBy: [
                SortDescriptor(\TodoTask.completedAt, order: .reverse),
                SortDescriptor(\TodoTask.id, order: .forward)
            ]
        )

        descriptor.fetchOffset = completedOffset
        descriptor.fetchLimit = 100

        do {
            let nextPage = try modelContext.fetch(descriptor)

            completedQuery.append(contentsOf: nextPage)
            completedOffset += nextPage.count

            if nextPage.count < 100 {
                completedHasMore = false
            }
        } catch {
            AppLogger.persistence.error(
                "TaskList load more completed tasks failed: \(error.localizedDescription)"
            )
        }

        isLoadingMoreCompleted = false
    }
    
    @MainActor
    private func migrateLegacyRecurrence(
        _ task: TodoTask,
        futureCount: Int?,
        endDate: Date?,
        keepCurrentOccurrenceActive: Bool
    ) {
        do {
            _ = try RecurrenceEngine.migrateLegacyRecurrence(
                for: task,
                futureCount: futureCount,
                endDate: endDate,keepCurrentOccurrenceActive: keepCurrentOccurrenceActive,
                in: modelContext
            )

            try modelContext.save()
            modelContext.processPendingChanges()

            NotificationCenter.default.post(
                name: .taskDidChange,
                object: nil
            )

            NotificationManager.shared.refresh(force: false)

            legacyRecurrenceTask = nil

        } catch {
            AppLogger.persistence.error(
                "Legacy recurrence migration failed: \(error.localizedDescription)"
            )
        }
    }

    @MainActor
    private func deleteLegacyRecurrence(_ task: TodoTask) {
        task.isCompleted = true
        task.completedAt = .now
        task.snoozeUntil = nil
        task.recurrenceRule = nil
        task.recurrenceInterval = 1
        task.recurrenceID = nil
        task.occurrenceIndex = nil
        task.recurrenceStartDate = nil
        task.recurrenceEndDate = nil
        task.recurrenceCount = nil

        do {
            try modelContext.save()
            modelContext.processPendingChanges()

            Task { @MainActor in
                _ = await ForMemoAlarmManager.shared.synchronize(task: task)
            }

            NotificationCenter.default.post(
                name: .taskDidChange,
                object: nil
            )
            
            NotificationManager.shared.refresh(force: false)
            
            legacyRecurrenceTask = nil

        } catch {
            AppLogger.persistence.error(
                "Legacy recurrence deletion failed: \(error.localizedDescription)"
            )
        }
    }
    
    @MainActor
    private func updateCompletedTaskCount() {
        let now = Date()
        let period = activeTaskPeriodRange(now: now)

        guard !period.invalid else {
            completedTaskCount = 0
            return
        }

        let hasSearch = !debouncedSearchText.isEmpty
        let searchValue = debouncedSearchText

        let hasPriorityFilter = selectedPriorityFilter != nil
        let priorityValue = selectedPriorityFilter?.rawValue ?? 0

        let isNoTagFilter: Bool
        let hasTagFilter: Bool
        let tagValue: String

        switch selectedTagFilter {
        case .all:
            isNoTagFilter = false
            hasTagFilter = false
            tagValue = ""

        case .none:
            isNoTagFilter = true
            hasTagFilter = false
            tagValue = ""

        case .tag(let tag):
            isNoTagFilter = false
            hasTagFilter = true
            tagValue = tag.rawValue
        }

        let predicate = makeCompletedTaskPredicate(
            period: period,
            hasSearch: hasSearch,
            searchValue: searchValue,
            hasPriorityFilter: hasPriorityFilter,
            priorityValue: priorityValue,
            isNoTagFilter: isNoTagFilter,
            hasTagFilter: hasTagFilter,
            tagValue: tagValue
        )

        let descriptor = FetchDescriptor<TodoTask>(
            predicate: predicate
        )

        do {
            completedTaskCount = try modelContext.fetchCount(descriptor)

            AppLogger.persistence.debug(
                "TaskList completed task count: \(completedTaskCount)"
            )
        } catch {
            AppLogger.persistence.error(
                "TaskList completed task count failed: \(error.localizedDescription)"
            )
            completedTaskCount = 0
        }
    }
    
    
    
    
    @ViewBuilder
    private var completedTasksSection: some View {
        
        CompletedTasksContainerView(
            taskPendingDeletion: $taskPendingDeletion,
            modelContext: modelContext,
            tasks: completedQuery,
            loadMoreTasks: loadMoreCompletedTasks,
            completedTaskCount: completedTaskCount,
            refreshCompletedTasks: {
                fetchCompletedTasks()
                updateCompletedTaskCount()
            }
        )
    }
    
    @ViewBuilder
    private var taskListContent: some View {
        List {
            if showCompleted {
                completedTasksSection
            } else if databaseIsEmpty == true && !showNewTask {
                EmptySectionView(showQuickGuide: $showQuickGuide)
            } else {
                TodoSectionView(
                    taskPendingDeletion: $taskPendingDeletion,
                    openWeatherForecast: { date in
                        selectedWeatherDay = SelectedWeatherDay(date: date)
                    },
                    tasks: filteredTodoTasksCache,
                    activeTaskCount: activeTaskCount,
                    modelContext: modelContext,
                    loadMoreTasks: loadMoreActiveTasks,
                    paginationLocked: activeListRefreshInProgress,
                    deleteTaskAndRefresh: deleteTaskAndRefresh,
                    duplicateTaskAndUpdateList: duplicateTaskAndUpdateList,
                    onLegacyRecurrenceCompletion: { task in
                        legacyRecurrenceTask = task
                    }
                )
            }
            
        }
        .id(showCompleted)
        .id(debouncedSearchText)
    }
    
  var body: some View {
     
    ZStack {
      AppGlassBackground()
        listWithStyle {
            taskListContent
          .safeAreaInset(edge: .bottom) {
            Color.clear.frame(height: 80)
          }
          .scrollContentBackground(.hidden)
          .background(Color.clear)
          .scrollEdgeEffectHidden(true, for: .top)
          .alert(
              String(localized: "Delete task?"),
              isPresented: Binding(
                  get: { taskPendingDeletion != nil },
                  set: { if !$0 { taskPendingDeletion = nil } }
              )
          ) {

              if let task = taskPendingDeletion,
                 !task.isCompleted,
                 task.recurrenceID != nil,
                 hasFutureOccurrenceForDeletion(task) {

                  Button(
                      String(localized: "Delete This Occurrence"),
                      role: .destructive
                  ) {
                      deleteTaskAndRefresh(task)
                      taskPendingDeletion = nil
                  }

                  Button(
                      String(localized: "Delete This & Future Occurrences"),
                      role: .destructive
                  ) {
                      taskPendingDeletion = nil
                      isDeletingRecurrence = true

                      Task { @MainActor in
                          await Task.yield()

                          await deleteRecurringTaskAndFutureOccurrences(
                              task,
                              in: modelContext
                          )

                          modelContext.processPendingChanges()

                          NotificationCenter.default.post(
                              name: .taskDidChange,
                              object: nil
                          )

                          isDeletingRecurrence = false
                      }
                  }

              } else {

                  Button(
                      String(localized: "Delete"),
                      role: .destructive
                  ) {
                      guard let task = taskPendingDeletion else {
                          taskPendingDeletion = nil
                          return
                      }

                      deleteTaskAndRefresh(task)
                      taskPendingDeletion = nil
                  }
              }

              Button(
                  String(localized: "Cancel"),
                  role: .cancel
              ) {
                  taskPendingDeletion = nil
              }

          } message: {
              Text(String(localized: "This action cannot be undone."))
          }
          .contentMargins(
            .horizontal,
            listStyleChoice == .plain
            ? 0
            : TaskRowMetrics.groupedLeadingPadding,
            for: .scrollContent
          )

          .fullScreenCover(isPresented: $showQuickGuide) {
            AppQuickGuideView()
          }
          .listRowSpacing(0)
        }
        .navigationDestination(for: TodoTask.self) { task in
          TaskDetailView(task: task)
        }
        .scrollDismissesKeyboard(.immediately)
        
        if isDeletingRecurrence {
            ZStack {
                Color.black.opacity(0.25)
                    .ignoresSafeArea()

                VStack(spacing: 12) {
                    ProgressView()

                    Text(String(localized: "Deleting occurrences…"))
                        .font(.headline)

                    Text(String(localized: "Do not close ForMemo until the deletion is complete."))
                        .font(.subheadline)
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.secondary)
                }
                .padding(24)
                .frame(maxWidth: 320)
                .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 20))
            }
            .zIndex(100)
        }
        
        
        
        
        }
    .onChange(of: scenePhase) { _, newPhase in
        if newPhase == .inactive {
            if showCompleted {
                showCompleted = false
            }
            return
        }

        if newPhase == .active {
            if showCompleted {
                fetchCompletedTasks()
                updateCompletedTaskCount()
            } else {
                refreshActiveList()
            }
        }
    }

    .searchableIf(
        databaseIsEmpty == false,
        text: $searchText,
        placement: .navigationBarDrawer(displayMode: .automatic),
        prompt: "Search task"
    )

    .onReceive(
        NotificationCenter.default.publisher(
            for: .taskDidChange
        )
    ) { _ in
        
        checkDatabaseIsEmpty()
        
        if showCompleted {
            fetchCompletedTasks()
            updateCompletedTaskCount()
        } else {
            refreshActiveList()
        }
    }
      
    .sheet(item: $legacyRecurrenceTask) { task in
        RecurrenceMigrationView(
            task: task,
            onMigrate: { task, futureCount, endDate, keepCurrentOccurrenceActive in
                migrateLegacyRecurrence(
                    task,
                    futureCount: futureCount,
                    endDate: endDate,
                    keepCurrentOccurrenceActive: keepCurrentOccurrenceActive
                )
            },
            onDeleteRecurrence: { task in
                deleteLegacyRecurrence(task)
            }
        )
    }
        .onChange(of: searchText) { _, newValue in
            if newValue.isEmpty {
                debouncedSearchText = ""
            } else {
                let value = newValue

                Task {
                    try? await Task.sleep(for: .milliseconds(300))

                    if value == searchText {
                        debouncedSearchText = value
                    }
                }
            }
        }
        .onAppear {
            debouncedSearchText = searchText
            if databaseIsEmpty == nil {
                checkDatabaseIsEmpty()
            }
            refreshActiveList()
        }

        .onChange(of: debouncedSearchText) { _, _ in
            if showCompleted {
                fetchCompletedTasks()
                updateCompletedTaskCount()
            } else {
                refreshActiveList()
            }
        }

        .onChange(of: selectedTagFilter) { _, _ in
            if showCompleted {
                fetchCompletedTasks()
                updateCompletedTaskCount()
            } else {
                refreshActiveList()
            }
        }

        .onChange(of: selectedPriorityFilter) { _, _ in
            if showCompleted {
                fetchCompletedTasks()
                updateCompletedTaskCount()
            } else {
                refreshActiveList()
            }
        }

        .onChange(of: selectedPeriodFilter) { _, _ in
            if showCompleted {
                fetchCompletedTasks()
                updateCompletedTaskCount()
            } else {
                refreshActiveList()
            }
        }

            .toolbarBackground(.hidden, for: .navigationBar)

            .toolbarBackgroundVisibility(.hidden, for: .navigationBar)

            .navigationTitle(
                databaseIsEmpty == true && !showCompleted && !showNewTask
                    ? ""
                    : String(localized: "My Tasks")
            )

        .navigationBarTitleDisplayMode(.inline)

        .sheet(item: $selectedWeatherDay) { selectedDay in

          NavigationStack {

            WeatherDayView(

              date: selectedDay.date,

              showsCloseButton: true,

              closeAction: {

                selectedWeatherDay = nil

              }

            )

          }

        }

        .sheet(
            item: $draftTask,
            onDismiss: {
                refreshActiveList()
            }
        ) { task in

            NewTaskSheetView(draftTask: task)
        }

        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    withAnimation(.snappy) {
                        showCompleted.toggle()
                    }

                    if showCompleted {
                        fetchCompletedTasks()
                        updateCompletedTaskCount()
                    } else {
                        refreshActiveList()
                    }
                } label: {
                    Image(systemName: showCompleted ? "eye.slash" : "eye")
                }
            }

          ToolbarItem(placement: .topBarTrailing) {

            Button {

              withAnimation(.snappy) {

                draftTask = TodoTask()

              }

            } label: {

              Image(systemName: draftTask == nil ? "plus.circle.fill" : "minus.circle.fill")

                .foregroundStyle(draftTask == nil ? .green : .gray)

                .font(.title2)

            }

          }

          if databaseIsEmpty == false {
            ToolbarItem(placement: .topBarLeading) {

              Menu {

                // Sezione per rimuovere tutti i filtri

                if selectedTagFilter != .all || selectedPriorityFilter != nil || selectedPeriodFilter != nil {

                  Button(role: .destructive) {

                    selectedTagFilter = .all

                    selectedPriorityFilter = nil

                    selectedPeriodFilter = nil

                  } label: {

                    Label(

                      String(localized: "Remove Filters"),

                      systemImage: "line.3.horizontal.decrease.circle"

                    )

                  }

                  Divider()

                }

                // MENU FILTRO TAG

                // Usiamo un Picker per gestire la selezione "esclusiva" in modo nativo

                Menu {

                  Picker("Tags", selection: $selectedTagFilter) {

                    Text("All")

                      .tag(TaskTagFilter.all)

                    Label("None", systemImage: "tag.slash")

                      .tag(TaskTagFilter.none)

                    ForEach(TaskMainTag.localizedSortedCases) { tag in

                      Label(tag.localizedTitle, systemImage: tag.mainIcon)

                        .tag(TaskTagFilter.tag(tag))

                    }

                  }

                } label: {

                  Label(

                    String(localized: "Tags"),

                    systemImage: "tag"

                  )

                }

                // MENU FILTRO PRIORITÀ

                Menu {

                  Picker("Priority", selection: $selectedPriorityFilter) {

                    Text("All").tag(nil as TaskPriority?)

                    ForEach(TaskPriority.allCases) { priority in

                      // Utilizziamo l'icona della priorità o una stringa vuota se nil

                      Label(priority.localizedTitle, systemImage: priority.systemImage ?? "ellipsis")

                        .tag(priority as TaskPriority?)

                    }

                  }

                } label: {

                  Label(

                    String(localized: "Priority"),

                    systemImage: "exclamationmark.circle"

                  )

                }

                // MENU FILTRO PERIODO

                Section {

                  Button {

                    selectedPeriodFilter = nil

                  } label: {

                    Label(

                      "All",

                      systemImage: selectedPeriodFilter == nil

                      ? "checkmark"

                      : "circle"

                    )

                  }

                  ForEach(TaskPeriodFilter.allCases) { period in

                    Button {

                      selectedPeriodFilter = period

                    } label: {

                      Label(

                        period.localizedTitle,

                        systemImage: selectedPeriodFilter == period

                        ? "checkmark"

                        : period.systemImage

                      )

                    }

                  }

                } header: {

                  Label(

                    String(localized: "Period"),

                    systemImage: "calendar"

                  )

                }

              } label: {

                // Icona principale del Filtro nella Toolbar

                // Diventa blu se almeno un filtro è attivo

                Image(systemName: "line.3.horizontal.decrease.circle")

                  .foregroundStyle(

                    selectedTagFilter != .all ||

                    selectedPriorityFilter != nil ||

                    selectedPeriodFilter != nil

                    ? .red

                    : .primary.opacity(0.7)

                  )

              }

            }

          }

          ToolbarItem(placement: .topBarLeading) {

            Menu {

              Section("Appearance") {

                Picker("Style", selection: listStyleBinding) {

                  Label("Plain", systemImage: "list.bullet")

                    .tag(TaskListStyle.plain)

                  Label("Grouped", systemImage: "square.on.square")

                    .tag(TaskListStyle.grouped)

                }

              }

              Section() {

                Toggle(isOn: showDateEveryRowBinding) {

                  Label(

                    "Show Date On Every Row",

                    systemImage: "calendar.day.timeline.left.circle"

                  )

                }

              }

            } label: {

              Image(systemName: "ellipsis")

                .foregroundStyle(.primary.opacity(0.7))

            }

          }

        }

    }

    @MainActor
    private func duplicateTaskAndUpdateList(_ duplicatedTask: TodoTask) {
        guard !duplicatedTask.isCompleted else { return }
        guard !filteredTodoTasksCache.contains(where: { $0.id == duplicatedTask.id }) else { return }

        let now = activeFetchNow
        let phase: ActiveTaskFetchPhase

        if duplicatedTask.deadLine == nil {
            phase = .noDeadline
        } else if duplicatedTask.deadLine! < now {
            phase = .overdue
        } else {
            phase = .future
        }

        func comesBefore(_ lhs: TodoTask, _ rhs: TodoTask) -> Bool {
            switch phase {
            case .overdue, .future:
                let lhsDate = lhs.deadLine ?? .distantFuture
                let rhsDate = rhs.deadLine ?? .distantFuture
                if lhsDate != rhsDate {
                    return lhsDate < rhsDate
                }
                return lhs.id.uuidString < rhs.id.uuidString
            case .noDeadline:
                return lhs.id.uuidString < rhs.id.uuidString
            }
        }

        let insertionIndex: Int
        switch phase {
        case .overdue:
            let range = filteredTodoTasksCache.indices.filter { index in
                let task = filteredTodoTasksCache[index]
                return task.deadLine != nil && task.deadLine! < now
            }
            insertionIndex = range.first(where: { comesBefore(duplicatedTask, filteredTodoTasksCache[$0]) }) ?? (range.last.map { $0 + 1 } ?? 0)

        case .future:
            let start = filteredTodoTasksCache.firstIndex(where: {
                guard let deadline = $0.deadLine else { return false }
                return deadline >= now
            }) ?? filteredTodoTasksCache.count
            let end = filteredTodoTasksCache.firstIndex(where: { $0.deadLine == nil }) ?? filteredTodoTasksCache.count
            let upperBound = max(start, end)
            let range = start..<upperBound
            insertionIndex = range.first(where: { comesBefore(duplicatedTask, filteredTodoTasksCache[$0]) }) ?? upperBound

        case .noDeadline:
            insertionIndex = filteredTodoTasksCache.firstIndex(where: { $0.deadLine == nil && comesBefore(duplicatedTask, $0) }) ?? filteredTodoTasksCache.count
        }

        filteredTodoTasksCache.insert(duplicatedTask, at: insertionIndex)

        switch phase {
        case .overdue:
            activeOverdueOffset += 1
        case .future:
            activeFutureOffset += 1
        case .noDeadline:
            activeNoDeadlineOffset += 1
        }

        activeTaskCount += 1
    }

    @MainActor
    private func deleteTaskAndRefresh(_ task: TodoTask) {
        deleteTask(task, in: modelContext)

        modelContext.processPendingChanges()

        NotificationCenter.default.post(
            name: .taskDidChange,
            object: nil
        )
    }
    
    @MainActor
    private func hasFutureOccurrenceForDeletion(_ task: TodoTask) -> Bool {
        guard !task.isCompleted else { return false }
        do {
            return try RecurrenceEngine.hasFutureOccurrence(
                for: task,
                in: modelContext
            )
        } catch {
            AppLogger.persistence.error(
                "TaskList future occurrence check failed: \(error.localizedDescription)"
            )
            return false
        }
    }
    

    @MainActor
    private func requestTaskDeletion(_ task: TodoTask) {
        
        AppLogger.persistence.error(
            "DELETE DEBUG — title=\(task.title), recurrenceID=\(task.recurrenceID?.uuidString ?? "nil"), occurrenceIndex=\(task.occurrenceIndex.map(String.init) ?? "nil"), recurrenceRule=\(task.recurrenceRule ?? "nil")"
        )
        guard task.recurrenceID != nil else {
            if confirmTaskDeletion {
                taskPendingDeletion = task
            } else {
                withAnimation(.snappy(duration: 0.26, extraBounce: 0.01)) {
                    deleteTaskAndRefresh(task)
                }
            }
            return
        }

        let hasFutureOccurrence = hasFutureOccurrenceForDeletion(task)

        if hasFutureOccurrence || confirmTaskDeletion {
            taskPendingDeletion = task
        } else {
            withAnimation(.snappy(duration: 0.26, extraBounce: 0.01)) {
                deleteTaskAndRefresh(task)
            }
        }
    }
    
    

  @ViewBuilder

  private func listWithStyle<Content: View>(

    @ViewBuilder content: () -> Content

  ) -> some View {

    switch listStyleChoice {

    case .plain:

      content().listStyle(.plain)

    case .grouped:

      content().listStyle(.plain)

    }

  }

}



// MARK: - EmptySectionView

struct EmptySectionView: View {

  @Binding var showQuickGuide: Bool

  var body: some View {

    Section("") {

      ContentUnavailableView {

        VStack(spacing: 12) {

          Text(String(localized:("Welcome!")))

            .font(.largeTitle.bold())

            .foregroundStyle(.primary)

            .padding(.top, 20)

          Image(systemName: "checkmark.circle.dotted")

            .resizable()

            .scaledToFit()

            .frame(width: 80, height: 80)

            .symbolRenderingMode(.palette)

            .foregroundStyle(.cyan, .blue)

          // animazione continua

            .symbolEffect(.pulse, options: .repeating.speed(0.2))

            .shadow(color: .blue.opacity(0.3), radius: 20, x: 0, y: 10)

          Text(String(localized:"No Tasks"))

            .font(.title2.bold())

        }

      } description: {

        VStack(alignment: .center, spacing: 12) {

          Text("Get started with a few simple taps:")

            .font(.subheadline.bold())

            .padding(.top, 20)

            .padding(.bottom, 4)

            .foregroundStyle(.blue)

            .lineLimit(2)

        }

        Group {

          VStack(alignment: .leading, spacing: 12) {

            HStack(alignment: .top, spacing: 12) {

              Image(systemName: "ellipsis")

                .frame(width: 30)

                .padding(.top, 4)

                .padding(.trailing, -6)

                .foregroundStyle(.primary)

              VStack(alignment: .leading){

                Text("switch your task view.")

              }}

            HStack(alignment: .top, spacing: 12) {

              Image(systemName: "plus.circle.fill")

                .foregroundStyle(.green)

              Text("add a new task to your list.")

            }





            HStack(alignment: .top, spacing: 12) {

              Image(systemName: "eye")

                .foregroundStyle(.blue)

              Text("show or hide completed tasks.")

            }

            Spacer()

            HStack{

              Spacer()

              Button {

                Task { @MainActor in

                  showQuickGuide = true

                }

              } label: {

                Label("Quick Guide", systemImage: "questionmark.circle")

              }

              .buttonStyle(.bordered)

              .foregroundStyle(.blue)

              Spacer()

            }

          }

          .font(.footnote)

          .foregroundStyle(.secondary)

          .multilineTextAlignment(.leading)

          .frame(maxWidth: 320, alignment: .leading)

          .frame(maxWidth: .infinity, alignment: .center)

          .padding(.horizontal, 24)

        }

      }

      .padding(.top, -20)

      .listRowSeparator(.hidden)

      .listRowBackground(Color.clear)

    }

  }

}



// MARK: - TaskRow

struct TaskRowAppearance {

  let iconStyle: TaskIconStyle

  let showBadge: Bool

  let showAttachments: Bool

  let showLocation: Bool

  let showPriority: Bool

  let showBadgeOnlyWithPriority: Bool

  let highlightEnabled: Bool

  let showTodayExpiredLabel: Bool

  let selectedRowStyle: Int

  let dueIconEffect: DueIconEffect

}

@MainActor

struct TaskRow: View {

  // Riceviamo il task direttamente. SwiftData gestisce la relazione in modo efficiente.

  let task: TodoTask

  let showDateColumn: Bool

  let appearance: TaskRowAppearance

  @Environment(AppSettings.self) private var settings

  private let now = Date()

  private var isToday: Bool {

    guard let d = task.deadLine else { return false }

    return Calendar.current.isDateInToday(d)

  }

  private var isOverdue: Bool {

    guard let d = task.deadLine else { return false }

    return d < now

  }

  private var isOverdueToday: Bool {

    guard let d = task.deadLine else { return false }

    return d < now && Calendar.current.isDateInToday(d)

  }

  private var dynamicRowHeight: CGFloat {

    max(

      1,

      TaskRowMetrics.rowHeight + CGFloat(settings.taskRowVerticalPadding)

    )

  }

  var rowStyleToUse: Int {

    appearance.selectedRowStyle

  }

    private var model: TaskRowDisplayModel {

        let shouldDisplayBadge =
            appearance.showBadge &&
            (!appearance.showBadgeOnlyWithPriority || task.priority != .none)

        let hasValidAttachments = task.hasVisibleTaskAttachments

        return TaskRowDisplayModel(
            id: task.persistentModelID,
            title: task.title,
            subtitle: task.taskDescription,
            mainIcon: task.mainTag?.mainIcon ?? task.status.icon,
            statusColor: task.status.color,
            hasValidAttachments: hasValidAttachments,
            hasLocation: task.locationName?.isEmpty == false,
            badgeText: task.daysRemainingBadgeText,
            prioritySystemImage: task.priority.systemImage,
            deadLine: task.deadLine,
            reminderOffsetMinutes: task.reminderOffsetMinutes,
            shouldShowBadge: shouldDisplayBadge,
            isCompleted: task.isCompleted,
            recurrenceRule: task.recurrenceRule,
            isLegacyRecurrence: task.recurrenceRule != nil && task.occurrenceIndex == nil,
            mainTag: task.mainTag
        )
    }

  var body: some View {

    rowContent

      .contentShape(Rectangle())

      .alignmentGuide(.listRowSeparatorLeading) { d in d[.leading] }

      .frame(minHeight: dynamicRowHeight)

      .buttonStyle(.plain)

  }

  private var rowContent: some View {

    content

      .background {

        navigationLink

      }

  }

  private var navigationLink: some View {

    NavigationLink(value: task) {

      EmptyView()

    }

    .opacity(0)

  }

  private var content: some View {

    TaskRowContent(

      model: model,

      iconStyle: appearance.iconStyle,

      showBadge: model.shouldShowBadge,

      showAttachments: appearance.showAttachments,

      showLocation: appearance.showLocation,

      showPriority: appearance.showPriority,

      showBadgeOnlyWithPriority: appearance.showBadgeOnlyWithPriority,

      rowStyle: TaskRowStyle(rawValue: rowStyleToUse) ?? .style0,

      showDateColumn: showDateColumn,

      highlightCriticalOverdue: appearance.highlightEnabled,

      showTodayExpiredLabel: appearance.showTodayExpiredLabel,

      dueIconEffect: appearance.dueIconEffect

    )

    .equatable()

    .frame(maxWidth: .infinity, alignment: .leading)

    .padding(

      .trailing,

      rowStyleToUse == 0

      ? TaskRowMetrics.style0TrailingContentPadding

      : TaskRowMetrics.rowTrailingContentPadding

    )

  }

}

// MARK: - Period Filter

enum TaskPeriodFilter: String, CaseIterable, Identifiable {

  case noDeadline

  case today

  case tomorrow

  case dayAfterTomorrow

  case thisWeekend

  case nextWeekend

  case thisWeek

  case nextWeek

  case thisMonth

  var id: String { rawValue }

  var localizedTitle: LocalizedStringKey {

    switch self {

    case .noDeadline:

      return "No Deadline"

    case .today:

      return "Today"

    case .tomorrow:

      return "Tomorrow"

    case .dayAfterTomorrow:

      return "Day After Tomorrow"

    case .thisWeekend:

      return "This Weekend"

    case .nextWeekend:

      return "Next Weekend"

    case .thisWeek:

      return "This Week"

    case .nextWeek:

      return "Next Week"

    case .thisMonth:

      return "This Month"

    }

  }

  var systemImage: String {

    switch self {

    case .noDeadline:

      return "clock.badge.questionmark"

    case .today:

      return "sun.max"

    case .tomorrow:

      return "sunrise"

    case .dayAfterTomorrow:

      return "calendar.badge.clock"

    case .thisWeekend:

      return "beach.umbrella"

    case .nextWeekend:

      return "calendar.badge.plus"

    case .thisWeek:

      return "calendar.badge"

    case .nextWeek:

      return "calendar.circle"

    case .thisMonth:

      return "calendar"

    }

  }

  func matches(_ date: Date?) -> Bool {

    if self == .noDeadline {

      return date == nil

    }

    guard let date else { return false }

    let calendar = Calendar.current

    let now = Date()

    switch self {

    case .today:

      return calendar.isDateInToday(date)

    case .tomorrow:

      return calendar.isDateInTomorrow(date)

    case .dayAfterTomorrow:

      guard let target = calendar.date(byAdding: .day, value: 2, to: now) else {

        return false

      }

      return calendar.isDate(date, inSameDayAs: target)

    case .thisWeekend:

      guard let weekend = calendar.nextWeekend(startingAfter: now) else {

        return false

      }

      return date >= weekend.start && date < weekend.end

    case .nextWeekend:

      guard let firstWeekend = calendar.nextWeekend(startingAfter: now),

         let secondWeekend = calendar.nextWeekend(startingAfter: firstWeekend.end)

      else {

        return false

      }

      return date >= secondWeekend.start && date < secondWeekend.end

    case .thisWeek:

      guard let interval = calendar.dateInterval(of: .weekOfYear, for: now) else {

        return false

      }

      return interval.contains(date)

    case .nextWeek:

      guard let nextWeek = calendar.date(byAdding: .weekOfYear, value: 1, to: now),

         let interval = calendar.dateInterval(of: .weekOfYear, for: nextWeek)

      else {

        return false

      }

      return interval.contains(date)

    case .thisMonth:

      return calendar.isDate(date, equalTo: now, toGranularity: .month)

    case .noDeadline:

      return false // already handled above, but required for completeness

    }

  }

}

// MARK: - List Style Enum

enum TaskListStyle: String, CaseIterable {

  case plain

  case grouped

  var localizedName: LocalizedStringKey {

    switch self {

    case .plain:

      return "Plain"

    case .grouped:

      return "Grouped"

    }

  }

  var iconName: String {

    switch self {

    case .plain:

      return "list.bullet"

    case .grouped:

      return "square.on.square"

    }

  }

}

extension View {

  @ViewBuilder

  func searchableIf(

    _ condition: Bool,

    text: Binding<String>,

    placement: SearchFieldPlacement = .navigationBarDrawer(displayMode: .automatic),

    prompt: LocalizedStringKey = "Search task"

  ) -> some View {

    if condition {

      self.searchable(

        text: text,

        placement: placement,

        prompt: prompt

      )

    } else {

      self

    }

  }

}

@MainActor
struct TodoSectionView: View {

  @Environment(AppSettings.self) private var settings

  @Environment(\.colorScheme) private var colorScheme

  @State private var weatherManager = WeatherManager.shared

  @State private var locationAuthorizationStatus: CLAuthorizationStatus = CLLocationManager().authorizationStatus

    
  @ViewBuilder

  private func weatherCapsuleView(

    weather: DailyWeatherInfo,

    isTodayGroup: Bool

  ) -> some View {

    HStack(spacing: 7) {

      Image(systemName: isTodayGroup

         ? weatherManager.representativeSymbol(for: weather.date)

         : weather.symbolName)

        .symbolRenderingMode(.multicolor)

        .saturation(colorScheme == .light ? 1.25 : 1.0)

        .brightness(colorScheme == .light ? -0.2 : 0.0)

        .font(.subheadline.weight(.medium))

      Text("\(weather.minTemperature)°")

        .font(.caption.weight(.medium))

        .foregroundStyle(

          weather.minTemperature >= 35 ? .red :

          weather.minTemperature >= 30 ? .orange :

          weather.minTemperature <= 0 ? Color(red: 0.65, green: 0.88, blue: 1.00) :

          .primary.opacity(0.55)

        )

        .monospacedDigit()

      Text("/")

        .font(.caption2.weight(.medium))

        .foregroundStyle(.secondary.opacity(0.6))

      Text("\(weather.maxTemperature)°")

        .font(.caption.weight(.semibold))

        .foregroundStyle(

          weather.maxTemperature >= 35 ? .red :

          weather.maxTemperature >= 30 ? .orange :

          weather.maxTemperature <= 0 ? Color(red: 0.65, green: 0.88, blue: 1.00) :

          .primary.opacity(0.90)

        )

        .monospacedDigit()

    }

  }

  @ViewBuilder

  private func groupedHeaderView(

    for group: GroupedSection

  ) -> some View {

    if let title = group.relativeTitle {

      let _ = weatherManager.refreshID

      let isTodayGroup = Calendar.current.isDateInToday(group.date)

      HStack(spacing: 10) {

        Text(title)

          .font(.subheadline.weight(.semibold))

          .foregroundStyle(Color.primary.opacity(0.82))

        Text("\(group.tasks.count)")

          .font(.footnote.weight(.heavy))

          .foregroundStyle(.primary)

          .padding(.horizontal, 8)

          .padding(.vertical, 4)

          .background {

            Capsule(style: .continuous)

              .fill(.clear)

              .glassEffect(.clear)

          }

        Spacer(minLength: 0)

        if (locationAuthorizationStatus == .authorizedAlways

          || locationAuthorizationStatus == .authorizedWhenInUse),

         let weather = weatherManager.weather(for: group.date) {

          Button {

            openWeatherForecast(group.date)

          } label: {

            // Patch: use representative symbol for today, else weather.symbolName

            weatherCapsuleView(

              weather: weather,

              isTodayGroup: isTodayGroup

            )

          }

          .buttonStyle(.plain)

        }

      }

      .padding(.horizontal, 14)

      .padding(.vertical, isTodayGroup ? 12 : 9)

      .fixedSize(horizontal: true, vertical: false)

      .background {

        Capsule(style: .continuous)

          .fill(.clear)

          .glassEffect(.clear)

          .overlay {

            Capsule(style: .continuous)

              .fill(

                isTodayGroup

                ? Color.accentColor.opacity(0.06)

                : Color.white.opacity(0.015)

              )

          }

          .clipShape(

            Capsule(style: .continuous)

          )

      }

      .overlay {

        Capsule(style: .continuous)

          .strokeBorder(

            .white.opacity(0.12),

            lineWidth: 0.8

          )

      }

      .padding(.horizontal, TaskRowMetrics.groupedLeadingPadding+4)

      .padding(.top, group.date == groupedTasksByDay.first?.date ? 4 : 8)

      .padding(.bottom, TaskRowMetrics.weeklyVerticalPadding - 4) //questo alza o abbssa l'intestazione capsula (oggi, domani, ....) rispetto alla row sottostante

      .listRowInsets(EdgeInsets())

      .listRowBackground(Color.clear)

      .listRowSeparator(.hidden)

    }

  }

  private func relativeHeaderTitle(for date: Date) -> LocalizedStringKey? {

    let calendar = Calendar.current

    let today = calendar.startOfDay(for: Date())

    let target = calendar.startOfDay(for: date)

    guard let days = calendar.dateComponents([.day], from: today, to: target).day else {

      return nil

    }

    switch days {

    case -2:

      return "Day Before Yesterday"

    case -1:

      return "Yesterday"

    case 0:

      return "Today"

    case 1:

      return "Tomorrow"

    case 2:

      return "Day After Tomorrow"

    default:

      return nil

    }

  }

  private var listStyleChoice: TaskListStyle {

    settings.taskListStyle

  }

  private var confirmTaskDeletion: Bool {

    settings.confirmTaskDeletion

  }

  @Binding var taskPendingDeletion: TodoTask?

    let openWeatherForecast: (Date) -> Void
    let tasks: [TodoTask]
    let activeTaskCount: Int
    let modelContext: ModelContext
    let loadMoreTasks: () -> Void
    let paginationLocked: Bool
    let deleteTaskAndRefresh: (TodoTask) -> Void
    let duplicateTaskAndUpdateList: (TodoTask) -> Void
    let onLegacyRecurrenceCompletion: (TodoTask) -> Void
    
  private struct GroupedSection: Identifiable, Equatable {

    let date: Date

    let tasks: [TodoTask]

    let relativeTitle: LocalizedStringKey?

    let isUpcomingBoundary: Bool

    let upcomingTasksCount: Int

    var id: Date { date }

  }
    
  private struct GroupingSignature: Equatable {
    let id: UUID
    let deadline: Date?
  }

  @State private var groupedTasksCache: [GroupedSection] = []
  @State private var groupedTasksSignature: [GroupingSignature] = []

  private func currentGroupingSignature() -> [GroupingSignature] {
    tasks.map {
      GroupingSignature(id: $0.id, deadline: $0.deadLine)
    }
  }

  private func rebuildGroupedTasksCache() {
    let calendar = Calendar.current

    let grouped = Dictionary(grouping: tasks) { task in
      calendar.startOfDay(for: task.deadLine ?? .distantFuture)
    }

    let sortedGroups = grouped
      .map { key, value in
        (
          date: key,
          tasks: value.sorted {
            let lhs = $0.deadLine ?? .distantFuture
            let rhs = $1.deadLine ?? .distantFuture
            if lhs != rhs {
              return lhs < rhs
            }
            return $0.id.uuidString < $1.id.uuidString
          }
        )
      }
      .sorted { $0.date < $1.date }

    var result: [GroupedSection] = []
    var remainingTasksCount = tasks.count

    for index in sortedGroups.indices {
      let group = sortedGroups[index]
      let relativeTitle = relativeHeaderTitle(for: group.date)
      let previousRelativeTitle: LocalizedStringKey? =
        index > 0
        ? relativeHeaderTitle(for: sortedGroups[index - 1].date)
        : nil

      let isUpcomingBoundary =
        previousRelativeTitle != nil && relativeTitle == nil

      let upcomingTasksCount = isUpcomingBoundary
        ? remainingTasksCount
        : 0

      remainingTasksCount -= group.tasks.count

      result.append(
        GroupedSection(
          date: group.date,
          tasks: group.tasks,
          relativeTitle: relativeTitle,
          isUpcomingBoundary: isUpcomingBoundary,
          upcomingTasksCount: upcomingTasksCount
        )
      )
    }

    groupedTasksCache = result
    groupedTasksSignature = currentGroupingSignature()
  }

  private var groupedTasksByDay: [GroupedSection] {
    groupedTasksCache
  }

  private var showDateEveryRow: Bool {

    settings.showDateEveryRow

  }



  var body: some View {

    Group {

      if listStyleChoice == .grouped {

      HStack {

          Text(String(localized: "To do (\(activeTaskCount))"))

          .font(.headline.weight(.semibold))

          .foregroundStyle(.primary.opacity(0.9))

        Spacer()

      }

      .padding(.horizontal, TaskRowMetrics.groupedLeadingPadding + 4)

      .padding(.top, 6)

      .padding(.bottom, 8)

      .listRowInsets(EdgeInsets())

      .listRowBackground(Color.clear)

      .listRowSeparator(.hidden)

          ForEach(groupedTasksByDay) { group in
              let isLastGroup = group.id == groupedTasksByDay.last?.id
              
          if group.isUpcomingBoundary {

            let upcomingTasksCount = group.upcomingTasksCount

          HStack(spacing: 10) {

            Text(String(localized: "Upcoming"))

              .font(.subheadline.weight(.semibold))

              .foregroundStyle(Color.primary.opacity(0.82))

            Text("\(upcomingTasksCount)")

              .font(.caption2.weight(.bold))

              .foregroundStyle(.primary.opacity(0.82))

              .padding(.horizontal, 8)

              .padding(.vertical, 4)

              .background {

                Capsule(style: .continuous)

                  .fill(.clear)

                  .glassEffect(.clear)

              }

          }

          .padding(.horizontal, 14)

          .padding(.vertical, 9)

          .fixedSize(horizontal: true, vertical: false)

          .background {

            Capsule(style: .continuous)

              .fill(.clear)

              .glassEffect(.clear)

              .overlay {

                Capsule(style: .continuous)

                  .fill(Color.white.opacity(0.015))

              }

              .clipShape(

                Capsule(style: .continuous)

              )

          }

          .overlay {

            Capsule(style: .continuous)

              .strokeBorder(

                .white.opacity(0.12),

                lineWidth: 0.8

              )

          }

          .padding(.leading, TaskRowMetrics.groupedLeadingPadding - 7)

          .padding(.top, group.date == groupedTasksByDay.first?.date ? 4 : 8)

          .padding(.bottom, TaskRowMetrics.weeklyVerticalPadding - 10)

          .listRowInsets(EdgeInsets())

          .listRowBackground(Color.clear)

          .listRowSeparator(.hidden)

        }

        Section {

          ForEach(Array(group.tasks.enumerated()), id: \.element.id) { index, t in


            taskRow(

              for: t,

              position: TaskRowPosition.position(

                index: index,

                total: group.tasks.count

              )

            )

            .onAppear {
                guard !paginationLocked,
                      isLastGroup,
                      index == group.tasks.count - 1 else {
                    return
                }
                loadMoreTasks()
            }

          }

        } header: {

          groupedHeaderView(for: group)

        }

        .listSectionSeparator(.hidden)

        .listSectionSpacing(TaskRowMetrics.weeklyVerticalPadding / 2) //anche questo per lo spazio tra le row

      }

      .environment(\.defaultMinListRowHeight, 1)



    } else {

      Section(String(localized:"To do (\(tasks.count))")) {

          ForEach(Array(tasks.enumerated()), id: \.element.id) { index, t in

              let previousTaskDate = index > 0
                  ? Calendar.current.startOfDay(
                      for: tasks[index - 1].deadLine ?? .distantFuture
                    )
                  : nil

              let currentTaskDate = Calendar.current.startOfDay(
                  for: t.deadLine ?? .distantFuture
              )

              let startsNewDayGroup = previousTaskDate != currentTaskDate

              taskRow(
                  for: t,
                  position: startsNewDayGroup ? .first : .middle
              )
              .onAppear {
                  guard !paginationLocked,
                        index == tasks.count - 1 else {
                      return
                  }

                  loadMoreTasks()
              }
          }
      }

    }

    }

    .task {
      rebuildGroupedTasksCache()

      DispatchQueue.main.asyncAfter(

        deadline: .now() + 15

      ) {

        Task {

          await weatherManager.refreshIfNeeded()

        }

      }

    }

    .onChange(of: tasks) { _, _ in
      let signature = currentGroupingSignature()
      guard signature != groupedTasksSignature else { return }
      rebuildGroupedTasksCache()
    }

    .onReceive(
      NotificationCenter.default.publisher(for: .taskDidChange)
    ) { _ in
      let signature = currentGroupingSignature()
      guard signature != groupedTasksSignature else { return }
      rebuildGroupedTasksCache()
    }

    .onReceive(

      NotificationCenter.default.publisher(

        for: .locationPermissionChanged

      )

    ) { _ in

      locationAuthorizationStatus = CLLocationManager().authorizationStatus

    }


  }

  @MainActor
  private func requestTaskDeletion(_ task: TodoTask) {
    guard task.recurrenceID != nil else {
      if confirmTaskDeletion {
        taskPendingDeletion = task
      } else {
        withAnimation(.snappy(duration: 0.26, extraBounce: 0.01)) {
          deleteTaskAndRefresh(task)
        }
      }
      return
    }

    do {
      let recurrenceID = task.recurrenceID
      let currentIndex = task.occurrenceIndex ?? 1

      let occurrences = try modelContext.fetch(
        FetchDescriptor<TodoTask>(
          predicate: #Predicate<TodoTask> {
            $0.recurrenceID == recurrenceID
          }
        )
      )

      let hasFutureOccurrence = occurrences.contains { occurrence in
        guard occurrence.id != task.id,
              let occurrenceIndex = occurrence.occurrenceIndex else {
          return false
        }
        return occurrenceIndex > currentIndex
      }

      if hasFutureOccurrence || confirmTaskDeletion {
        taskPendingDeletion = task
      } else {
        withAnimation(.snappy(duration: 0.26, extraBounce: 0.01)) {
          deleteTaskAndRefresh(task)
        }
      }
    } catch {
      taskPendingDeletion = task
      AppLogger.persistence.error(
        "TaskList recurrence deletion check failed: \(error.localizedDescription)"
      )
    }
  }

  @ViewBuilder

  private func taskRow(for t: TodoTask, position: TaskRowPosition) -> some View {

    TaskRow(

      task: t,

      showDateColumn:

        showDateEveryRow

        ? true

        : (position == .first || position == .single),

      appearance: .current(from: settings)

    )

    .modifier(

      RowCardStyle(

        task: t,

        style: listStyleChoice,

        position: position,

        opacity: 1

      )

    )

    .swipeActions(edge: .leading, allowsFullSwipe: true) {

      Button {

        withAnimation(.snappy(duration: 0.30, extraBounce: 0.02)) {

          toggleCompleted(t)

        }

      } label: {

        Label("Complete", systemImage: "checkmark.circle")

      }

      .tint(.green)

    }

    .swipeActions(edge: .trailing, allowsFullSwipe: false) {

      Button(role: .destructive) {

          requestTaskDeletion(t)

      } label: {

        Label("Delete", systemImage: "trash")

      }

    }

    .contextMenu {

      Button(role: .destructive) {

          requestTaskDeletion(t)

      } label: {

        Label("Delete", systemImage: "trash")

      }

      Button {

        toggleCompleted(t)

      } label: {

        Label("Complete", systemImage: "checkmark.circle")

      }



      if t.deadLine != nil {

        Button {

          TaskSingleCalendarExport.shared.present(for: t)

        } label: {

          Label(

            "Add to Calendar",

            systemImage: "calendar.badge.plus"

          )

        }

      }

      TaskRescheduleMenu(task: t)

      if let deadline = t.deadLine,

        deadline < Date() {

        Menu {

          Button {

            NotificationActionProcessor.shared.applyManualSnooze(

              to: t,

              interval: 5 * 60,

              using: modelContext

            )

          } label: {

            Label("5 minutes", systemImage: "5.arrow.trianglehead.clockwise")

          }

          Button {

            NotificationActionProcessor.shared.applyManualSnooze(

              to: t,

              interval: 15 * 60,

              using: modelContext

            )

          } label: {

            Label("15 minutes", systemImage: "15.arrow.trianglehead.clockwise")

          }

          Button {

            NotificationActionProcessor.shared.applyManualSnooze(

              to: t,

              interval: 30 * 60,

              using: modelContext

            )

          } label: {

            Label("30 minutes", systemImage: "30.arrow.trianglehead.clockwise")

          }

          Button {

            NotificationActionProcessor.shared.applyManualSnooze(

              to: t,

              interval: 60 * 60,

              using: modelContext

            )

          } label: {

            Label("1 hour", systemImage: "60.arrow.trianglehead.clockwise")

          }

          Button {

            NotificationActionProcessor.shared.applyManualSnooze(

              to: t,

              interval: 3 * 60 * 60,

              using: modelContext

            )

          } label: {

            Label("3 hours", systemImage: "plus.arrow.trianglehead.clockwise")

          }

        } label: {

          Label("Snooze", systemImage: "timer")

        }

      }

      Menu {

        Button {

          do {

            let duplicatedTask = try TaskDuplicationService.duplicate(

              t,

              using: modelContext,

              includingAttachments: false

            )

            duplicateTaskAndUpdateList(duplicatedTask)

          } catch {

            AppLogger.persistence.error(

              "Task duplication failed: \(error.localizedDescription)"

            )

          }

        } label: {

          Label("Task", systemImage: "text.badge.checkmark")

        }

        if t.hasVisibleTaskAttachments {

          Button {

            do {

              let duplicatedTask = try TaskDuplicationService.duplicate(

                t,

                using: modelContext,

                includingAttachments: true

              )

              duplicateTaskAndUpdateList(duplicatedTask)

            } catch {

              AppLogger.persistence.error(

                "Task duplication failed: \(error.localizedDescription)"

              )

            }

          } label: {

            Label(

              "Task & Attachments",

              systemImage: "rectangle.and.paperclip"

            )

          }

        }

      } label: {

        Label("Duplicate", systemImage: "plus.square.on.square")

      }

    }

  }

    

    
  @MainActor

  @discardableResult
  private func persistChanges() -> Bool {

    do {

      try modelContext.save()

      modelContext.processPendingChanges()

      NotificationCenter.default.post(name: .taskDidChange, object: nil)
      return true

    } catch {

      AppLogger.persistence.fault("Failed to save context: \(error)")
      return false

    }

  }

  @MainActor

  private func toggleCompleted(_ task: TodoTask) {

    let wasCompleted = task.isCompleted

    // 🔥 RICORRENZA: intercetta PRIMA di cambiare stato

    if task.recurrenceRule != nil {

        if task.occurrenceIndex == nil {
            onLegacyRecurrenceCompletion(task)
            return
        }

      task.completeRecurringTask()

      modelContext.processPendingChanges()

    } else {

      let newValue = !task.isCompleted

      task.isCompleted = newValue

      if newValue {

        task.completedAt = .now

        task.snoozeUntil = nil

      } else {

        task.completedAt = nil

        task.snoozeUntil = nil

      }

    }

    let didSave = persistChanges()

    if didSave {
      RecurrenceCompletionNotice.postIfNeeded(
        for: task,
        wasCompleted: wasCompleted
      )
    }

    Task { @MainActor in
      _ = await ForMemoAlarmManager.shared.synchronize(task: task)
    }

    NotificationManager.shared.refresh(force: false)

  }

}



/// Shared production logic for reactivating a completed task.
/// Kept independent of UI and system services so it can be exercised against
/// an isolated SwiftData ModelContext by diagnostic integration tests.
@MainActor
enum CompletedTaskReactivation {
    @discardableResult
    static func reactivate(_ task: TodoTask, in context: ModelContext) throws -> Bool {
        guard task.isCompleted else { return false }

        task.isCompleted = false
        task.completedAt = nil
        task.snoozeUntil = nil

        try context.save()
        context.processPendingChanges()
        return true
    }
}


struct CompletedTasksContainerView: View {
    
    @Environment(AppSettings.self)
    private var settings

  private var confirmTaskDeletion: Bool {

      settings.confirmTaskDeletion

  }

  @Binding var taskPendingDeletion: TodoTask?

    let modelContext: ModelContext
    let tasks: [TodoTask]
    let loadMoreTasks: () -> Void
    let completedTaskCount: Int
    let refreshCompletedTasks: () -> Void
    
  var body: some View {

      CompletedSectionView(
          taskPendingDeletion: $taskPendingDeletion,
          tasks: tasks,
          modelContext: modelContext,
          completedTaskCount: completedTaskCount,
          loadMoreTasks: loadMoreTasks,
          refreshCompletedTasks: refreshCompletedTasks
      )
  }
}

struct CompletedSectionView: View {

  @Environment(AppSettings.self) private var settings

  private var listStyleChoice: TaskListStyle {

    settings.taskListStyle

  }
    
    @State private var legacyRecurrenceTask: TodoTask?

  private var confirmTaskDeletion: Bool {

    settings.confirmTaskDeletion

  }



  @Binding var taskPendingDeletion: TodoTask?

  let tasks: [TodoTask]
  let modelContext: ModelContext
  let completedTaskCount: Int
    let loadMoreTasks: () -> Void
    let refreshCompletedTasks: () -> Void
    
  @MainActor
  private func requestTaskDeletion(_ task: TodoTask) {
    // Completed occurrences are deleted individually, like standalone tasks.
    guard task.recurrenceID != nil, !task.isCompleted else {
      if confirmTaskDeletion {
        taskPendingDeletion = task
      } else {
        withAnimation(.snappy(duration: 0.26, extraBounce: 0.01)) {
          deleteTaskAndRefresh(task)
        }
      }
      return
    }

    do {
      let recurrenceID = task.recurrenceID
      let currentIndex = task.occurrenceIndex ?? 1

      let occurrences = try modelContext.fetch(
        FetchDescriptor<TodoTask>(
          predicate: #Predicate<TodoTask> {
            $0.recurrenceID == recurrenceID
          }
        )
      )

      let hasFutureOccurrence = occurrences.contains { occurrence in
        guard occurrence.id != task.id,
              let occurrenceIndex = occurrence.occurrenceIndex else {
          return false
        }
        return occurrenceIndex > currentIndex
      }

      if hasFutureOccurrence || confirmTaskDeletion {
        taskPendingDeletion = task
      } else {
        withAnimation(.snappy(duration: 0.26, extraBounce: 0.01)) {
          deleteTaskAndRefresh(task)
        }
      }
    } catch {
      taskPendingDeletion = task
      AppLogger.persistence.error(
        "TaskList completed recurrence deletion check failed: \(error.localizedDescription)"
      )
    }
  }

  @MainActor
  private func deleteTaskAndRefresh(_ task: TodoTask) {
    deleteTask(task, in: modelContext)
    modelContext.processPendingChanges()
    NotificationCenter.default.post(name: .taskDidChange, object: nil)
  }
    

  var body: some View {

      Section(String(localized:"Completed (\(completedTaskCount))")) {

          ForEach(Array(tasks.enumerated()), id: \.element.id) { index, t in

        TaskRow(

          task: t,

          showDateColumn: true,

          appearance: .current(from: settings)

        )

        .frame(minHeight: TaskRowMetrics.rowHeight)

        .modifier(

          RowCardStyle(

            task: t,

            style: listStyleChoice,

            position: TaskRowPosition.position(

              index: index,

              total: tasks.count

            ),

            opacity: listStyleChoice == .grouped ? 0.72 : 0.52

          )

        )

          .swipeActions(edge: .leading, allowsFullSwipe: true) {

            Button {

              withAnimation(.snappy(duration: 0.30, extraBounce: 0.02)) {

                toggleCompleted(t)

              }

            } label: {

              Label("To do", systemImage: "arrow.uturn.left")

            }

            .tint(.orange)

          }

          .swipeActions(edge: .trailing, allowsFullSwipe: false) {

            Button(role: .destructive) {

                requestTaskDeletion(t)

            } label: {

              Label("Delete", systemImage: "trash")

            }

          }

          .contextMenu {

            Button(role: .destructive) {

                requestTaskDeletion(t)

            } label: {

              Label("Delete", systemImage: "trash")

            }

            Button {

              toggleCompleted(t)

            } label: {

              Label("To do" , systemImage: "arrow.uturn.left"

              )

            }

          }


          .onAppear {
              guard index == tasks.count - 1 else {
                  return
              }

              loadMoreTasks()
          }

      }

    }

  }



  @MainActor

  private func persistChanges() {

    do {

      try modelContext.save()

      modelContext.processPendingChanges()

      NotificationCenter.default.post(name: .taskDidChange, object: nil)

    } catch {

      AppLogger.persistence.fault("Failed to save context: \(error)")

    }

  }

    @MainActor
    private func toggleCompleted(_ task: TodoTask) {
        do {
            guard try CompletedTaskReactivation.reactivate(task, in: modelContext) else {
                return
            }
        } catch {
            AppLogger.persistence.error(
                "Failed to reactivate task: \(error.localizedDescription)"
            )
            return
        }

        // Re-fetch after SwiftData has processed the completion-state change so
        // this occurrence is removed from the completed datasource immediately.
        refreshCompletedTasks()

        Task { @MainActor in
            _ = await ForMemoAlarmManager.shared.synchronize(task: task)
        }


        NotificationCenter.default.post(
            name: .taskDidChange,
            object: nil
        )

        NotificationManager.shared.refresh(force: false)
    }

}
