import SwiftUI

import SwiftData

import os

struct TaskCalendarView: View {

    @Environment(AppSettings.self)

    private var settings

    @Environment(\.modelContext) private var modelContext

    @State private var calendarTasks: [TodoTask] = []

    @Environment(\.verticalSizeClass) private var verticalSizeClass

    @State private var draftTask: TodoTask?

    private var isLandscape: Bool {

        verticalSizeClass == .compact

    }

    private var showExpandedCalendar: Bool {

        isExpanded || isLandscape

    }

    @State private var showCompletedTasks: Bool = false

    @State private var displayedMonth: Date = .now
    
    @State private var showMonthYearPicker = false
    @State private var pickerMonth = Calendar.current.component(.month, from: .now)
    @State private var pickerYear = Calendar.current.component(.year, from: .now)
    
    
    @State private var selectedDate: Date = Calendar.current.startOfDay(for: .now)

    @State private var newTaskSelection: NewTaskSelection?

    @State private var monthDirection: Int = 0

    @State private var timer: Timer? = nil

    @State private var isLongPressing = false

    // Expanded calendar state (scroll driven)

    @State private var isExpanded: Bool = false
    
    
    @State private var showDatePicker = false
    @State private var datePickerSelection: Date = .now

    private let expandThreshold: CGFloat = 40
    @State private var isCalendarHidden: Bool = false

    private let calendar: Calendar = {

        var cal = Calendar.current

        cal.firstWeekday = 2

        return cal

    }()

    @State private var holidayDates: Set<Date> = []

    @State private var tasksCache: [Date: [TodoTask]] = [:]
    
    @State private var calendarContainerSize: CGSize = .zero

    private var availableYears: [Int] {
        let currentYear = Calendar.current.component(.year, from: .now)
        return Array((currentYear - 100)...(currentYear + 100))
    }
    
    private var calendarMaxZoomScale: CGFloat {
        guard calendarContainerSize.width > 0 else {
            return 6
        }

        let longSide = max(
            calendarContainerSize.width,
            calendarContainerSize.height
        )

        let orientationRatio = longSide / calendarContainerSize.width

        return 6 * orientationRatio
    }
    
    var body: some View {

        ZStack {

            AppGlassBackground()

            VStack(spacing: 0) {

                if !isCalendarHidden || isLandscape {

                    header
                        .padding(.horizontal)
                        .padding(.top, (isLandscape || isExpanded) ? 0 : 10)

                    VStack(spacing: 5) {

                        if isLandscape || isExpanded {

                            ZoomableScrollView(
                                minScale: 1,
                                maxScale: calendarMaxZoomScale
                            ) {
                                VStack(spacing: 5) {

                                    weekHeader

                                    calendarGrid
                                        .frame(maxWidth: .infinity)
                                        .padding(.top, 2)
                                }
                            }
                            .id(
                                isLandscape
                                    ? "landscape_zoom_view"
                                    : "portrait_zoom_view"
                            )

                        } else {

                            VStack(spacing: 5) {
                                weekHeader
                                calendarGrid
                            }
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 4)
                    .frame(
                        height: isLandscape
                            ? nil
                            : (isExpanded ? 520 : 310),
                        alignment: .top
                    )
                    .highPriorityGesture(
                        isLandscape || isExpanded
                            ? nil
                            : monthSwipeGesture
                    )
                    .simultaneousGesture(
                        isLandscape
                            ? nil
                            : DragGesture(minimumDistance: 30)
                                .onChanged { value in
                                    if abs(value.translation.height)
                                        > abs(value.translation.width) {

                                        updateExpandedState(
                                            with: value.translation.height
                                        )
                                    }
                                }
                    )
                }
                
                Divider()

                if !showExpandedCalendar {

                    ZStack(alignment: .top) {

                        // Contenuto della row: centrato verticalmente
                        HStack {
                            Button {
                                datePickerSelection = selectedDate
                                showDatePicker = true
                            } label: {
                                Text(selectedDate.formatted(date: .abbreviated, time: .omitted))
                                    .foregroundStyle(.primary)
                            }
                            .buttonStyle(.plain)

                            Spacer()

                            Button {
                                showCompletedTasks.toggle()
                            } label: {
                                Image(systemName: showCompletedTasks ? "eye.slash" : "eye")
                            }
                            .labelStyle(.iconOnly)
                            .padding(.trailing, 4)

                            Button {
                                prepareNewTask(on: selectedDate)
                            } label: {
                                Image(systemName: "plus.circle.fill")
                                    .font(.title)
                                    .foregroundStyle(.green)
                            }
                            .labelStyle(.iconOnly)
                        }
                        .padding(.horizontal)
                        .frame(maxHeight: .infinity, alignment: .center)

                        // Maniglia: tap per mostrare/nascondere il calendario
                        Button {
                            withAnimation(.snappy(duration: 0.25)) {
                                isCalendarHidden.toggle()
                            }
                        } label: {
                            Image(systemName: isCalendarHidden ? "chevron.down" : "chevron.up")
                                .font(.system(size: 15, weight: .semibold))
                                .foregroundStyle(.secondary)
                                .frame(width: 44, height: 30)
                                .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .padding(.top, 8)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 52, alignment: .top)
                    .background(
                        Color(uiColor: .secondarySystemBackground)
                            .opacity(0.4)
                    )
                    .contentShape(Rectangle())
                    .simultaneousGesture(
                        isLandscape ? nil :
                            DragGesture(minimumDistance: 20)
                                .onEnded { value in

                                    guard abs(value.translation.height)
                                            > abs(value.translation.width),
                                          abs(value.translation.height) > 40
                                    else {
                                        return
                                    }

                                    withAnimation(.snappy(duration: 0.25)) {
                                        if value.translation.height < 0 {
                                            isCalendarHidden = true
                                        } else {
                                            isCalendarHidden = false
                                        }
                                    }
                                }
                    )
                    
                    DayTasksInlineView(

                        tasks: tasksForDay(selectedDate)

                    )

                }

            }

        }
        
        .onGeometryChange(for: CGSize.self) { proxy in
            proxy.size
        } action: { newSize in
            calendarContainerSize = newSize
        }
        
        
        .id(verticalSizeClass)

        .padding(.top, isLandscape || isExpanded ? 0 : -8)

        .navigationTitle("Calendar")

        .navigationBarTitleDisplayMode(.inline)

        .padding(.top, -8)

        .onAppear {
            Task { @MainActor in await loadHolidays(for: displayedMonth) }
            fetchCalendarTasks()
        }
        .onChange(of: displayedMonth) { _, newValue in
            Task { @MainActor in await loadHolidays(for: newValue) }
            fetchCalendarTasks()
        }
        .onReceive(
            NotificationCenter.default.publisher(for: .taskDidChange)
        ) { _ in
            fetchCalendarTasks()
        }

        .sheet(item: $draftTask) { task in

            NewTaskSheetView(draftTask: task)

        }

        .navigationDestination(for: TodoTask.self) { task in

            TaskDetailView(task: task)

        }
        
        .sheet(isPresented: $showDatePicker) {
            NavigationStack {
                DatePicker(
                    "Select Date",
                    selection: Binding(
                        get: { datePickerSelection },
                        set: { newDate in
                            datePickerSelection = newDate

                            withAnimation(.snappy) {
                                selectedDate = newDate

                                displayedMonth = calendar.date(
                                    from: calendar.dateComponents(
                                        [.year, .month],
                                        from: newDate
                                    )
                                ) ?? newDate
                            }
                        }
                    ),
                    displayedComponents: .date
                )
                .datePickerStyle(.graphical)
                .padding()
                .navigationTitle("Select Date")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) {
                        Button("Done") {
                            showDatePicker = false
                        }
                    }
                }
            }
            .presentationDetents([.medium])
        }
        .sheet(isPresented: $showMonthYearPicker) {
            NavigationStack {
                VStack(spacing: 0) {
                    HStack(spacing: 0) {

                        Picker("Month", selection: $pickerMonth) {
                            ForEach(1...12, id: \.self) { month in
                                Text(calendar.monthSymbols[month - 1])
                                    .tag(month)
                            }
                        }
                        .pickerStyle(.wheel)
                        .frame(maxWidth: .infinity)

                        Picker("Year", selection: $pickerYear) {
                            ForEach(availableYears, id: \.self) { year in
                                Text(String(year))
                                    .tag(year)
                            }
                        }
                        .pickerStyle(.wheel)
                        .frame(maxWidth: .infinity)
                    }
                    .frame(height: 220)
                }
                .navigationTitle("Select Month")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") {
                            showMonthYearPicker = false
                        }
                    }

                    ToolbarItem(placement: .confirmationAction) {
                        Button("Done") {
                            let selectedDay = calendar.component(.day, from: selectedDate)

                            var components = DateComponents()
                            components.year = pickerYear
                            components.month = pickerMonth
                            components.day = 1

                            guard let monthStart = calendar.date(from: components),
                                  let range = calendar.range(of: .day, in: .month, for: monthStart)
                            else {
                                showMonthYearPicker = false
                                return
                            }

                            let day = min(selectedDay, range.count)
                            components.day = day

                            if let newDate = calendar.date(from: components) {
                                withAnimation(.snappy) {
                                    displayedMonth = monthStart
                                    selectedDate = newDate
                                }
                            }

                            showMonthYearPicker = false
                        }
                    }
                }
            }
            .presentationDetents([.medium])
        }

    }

    private func prepareNewTask(on date: Date) {

        let calendar = Calendar.current

        let finalDate: Date

        if calendar.isDateInToday(date) {

            // Current time for today

            finalDate = Date()

        } else {

            // Default morning time for future days

            var components = calendar.dateComponents([.year, .month, .day], from: date)

            components.hour = 8

            components.minute = 0

            finalDate = calendar.date(from: components) ?? date

        }

        let task = TodoTask()

        task.deadLine = finalDate

        draftTask = task

    }

    private func monthNavigationButton(systemName: String, direction: Int) -> some View {

        Image(systemName: systemName)

            .font(.title2)

            .fontWeight(.semibold)

            .foregroundStyle(.blue)

            .frame(width: 44, height: 44) // Area di tocco standard Apple

            .contentShape(Rectangle())

            .onTapGesture {

                // Single month navigation

                changeMonth(by: direction)

            }

            .gesture(

                LongPressGesture(minimumDuration: 0.4)

                    .onEnded { _ in

                        isLongPressing = true

                        // Start rapid scrolling timer

                        timer = Timer.scheduledTimer(withTimeInterval: 0.15, repeats: true) { _ in

                            changeMonth(by: direction)

                            UIImpactFeedbackGenerator(style: .light).impactOccurred()

                        }

                    }

            )

            // Stop rapid scrolling when gesture ends

            .simultaneousGesture(

                DragGesture(minimumDistance: 0)

                    .onEnded { _ in

                        timer?.invalidate()

                        timer = nil

                        isLongPressing = false

                    }

            )

            .onDisappear {

                timer?.invalidate()

                timer = nil

                isLongPressing = false

            }

    }

    // Month navigation helper

    private func changeMonth(by value: Int) {

        monthDirection = value > 0 ? 1 : -1

        withAnimation(.snappy(duration: 0.2)) {

            if let newDate = Calendar.current.date(byAdding: .month, value: value, to: displayedMonth) {

                displayedMonth = newDate

            }

        }

    }

}



// MARK: - Scroll handling

private extension TaskCalendarView {

    func updateExpandedState(with offset: CGFloat) {

        if offset > expandThreshold {

            isExpanded = true

        }

        if offset < -expandThreshold {

            isExpanded = false

        }

    }

}

// MARK: - Gestures

private extension TaskCalendarView {

    var monthSwipeGesture: some Gesture {

        DragGesture(minimumDistance: 20)

            .onEnded { value in

                let threshold: CGFloat = 60

                if value.translation.width < -threshold {

                    monthDirection = 1

                    withAnimation(.snappy) {

                        if let nextMonth = calendar.date(byAdding: .month, value: 1, to: displayedMonth) {

                            displayedMonth = nextMonth

                        }

                    }

                } else if value.translation.width > threshold {

                    monthDirection = -1

                    withAnimation(.snappy) {

                        if let previousMonth = calendar.date(byAdding: .month, value: -1, to: displayedMonth) {

                            displayedMonth = previousMonth

                        }

                    }

                }

            }

    }

}

// MARK: - Header

private extension TaskCalendarView {

    var header: some View {

        HStack {

            Button {
                pickerMonth = calendar.component(.month, from: displayedMonth)
                pickerYear = calendar.component(.year, from: displayedMonth)
                showMonthYearPicker = true
            } label: {
                Text(displayedMonth, format: .dateTime.month(.wide).year())
                    .font(.headline.bold())
                    .foregroundStyle(.primary)
            }
            .buttonStyle(.plain)

                .font(.headline.bold())

            Spacer()

            HStack(spacing: 5) {

                monthNavigationButton(systemName: "chevron.left", direction: -1)

                Button("Today") {

                    let startOfToday = calendar.startOfDay(for: .now)

                    // Animated reset to current month

                    withAnimation(.snappy) {

                        displayedMonth = startOfToday

                        selectedDate = startOfToday

                    }

                }

                .font(.caption.bold())

                .buttonStyle(.bordered)

                .frame(width: 80)

                monthNavigationButton(systemName: "chevron.right", direction: 1)

            }

        }

        .padding(.bottom, 5)

        .contentShape(Rectangle()) // Assicura che i tocchi vengano intercettati

        .zIndex(10) // Mantiene l'header sopra la griglia zoomabile

    }



    var weekHeader: some View {

        let originalSymbols = calendar.shortStandaloneWeekdaySymbols

        let mondayIndex = 1

        let symbols =

        Array(originalSymbols[mondayIndex..<originalSymbols.count]) +

        Array(originalSymbols[0..<mondayIndex])

        return HStack {

            ForEach(symbols, id: \.self) { symbol in

                Text(symbol)

                    .font(.caption.bold())

                    .foregroundStyle(.secondary)

                    .frame(maxWidth: .infinity)

            }

        }

    }

}





// MARK: - Helpers

private extension TaskCalendarView {

    func tasksForDay(_ day: Date) -> [TodoTask] {

        let dayKey = calendar.startOfDay(for: day)

        let dayTasks = tasksCache[dayKey] ?? []

        if showCompletedTasks {

            return dayTasks

        } else {

            return dayTasks.filter { !$0.isCompleted }

        }

    }

    @MainActor
    func fetchCalendarTasks() {
        guard
            let currentMonthStart = calendar.date(
                from: calendar.dateComponents(
                    [.year, .month],
                    from: displayedMonth
                )
            ),
            let startDate = calendar.date(
                byAdding: .month,
                value: -1,
                to: currentMonthStart
            ),
            let endDate = calendar.date(
                byAdding: .month,
                value: 2,
                to: currentMonthStart
            )
        else {
            calendarTasks = []
            tasksCache = [:]
            return
        }

        let predicate = #Predicate<TodoTask> { task in
            task.deadLine != nil &&
            task.deadLine! >= startDate &&
            task.deadLine! < endDate
        }

        let descriptor = FetchDescriptor<TodoTask>(
            predicate: predicate,
            sortBy: [
                SortDescriptor(\.deadLine, order: .forward)
            ]
        )

        do {
            let fetchedTasks = try modelContext.fetch(descriptor)
            calendarTasks = fetchedTasks

            var newCache: [Date: [TodoTask]] = [:]
            newCache.reserveCapacity(93)

            for task in fetchedTasks {
                guard let deadline = task.deadLine else { continue }
                let day = calendar.startOfDay(for: deadline)
                newCache[day, default: []].append(task)
            }

            tasksCache = newCache
        } catch {
            AppLogger.persistence.error(
                "Calendar task fetch failed: \(error.localizedDescription)"
            )
        }
    }



    func makeDaysForMonth(_ date: Date) -> [Date] {

        guard

            let startOfMonth = calendar.date(

                from: calendar.dateComponents([.year, .month], from: date)

            ),

            let range = calendar.range(of: .day, in: .month, for: startOfMonth)

        else {

            return []

        }

        let firstWeekday = calendar.component(.weekday, from: startOfMonth)

        var days: [Date] = []

        let offset = (firstWeekday - calendar.firstWeekday + 7) % 7

        for i in stride(from: offset, to: 0, by: -1) {

            if let d = calendar.date(byAdding: .day, value: -i, to: startOfMonth) {

                days.append(d)

            }

        }

        for day in range {

            if let d = calendar.date(byAdding: .day, value: day - 1, to: startOfMonth) {

                days.append(d)

            }

        }

        while days.count % 7 != 0 {

            guard let last = days.last,

                  let next = calendar.date(byAdding: .day, value: 1, to: last)

            else { break }

            days.append(next)

        }

        return days

    }



    @MainActor

    func loadHolidays(for month: Date) async {

        holidayDates = HolidayProvider.holidays(

            in: month,

            calendar: calendar

        )

    }

}



// MARK: - Holidays

struct HolidayKey: Hashable {

    let day: Int

    let month: Int

}

enum HolidayProvider {

    static func holidays(

        in month: Date,

        calendar: Calendar

    ) -> Set<Date> {

        let region = Locale.current.region?.identifier ?? "EU"

        guard let start = calendar.date(

            from: calendar.dateComponents([.year, .month], from: month)

        ),

        let range = calendar.range(of: .day, in: .month, for: start)

        else {

            AppLogger.persistence.error("Unable to calculate holiday calendar range")

            return []

        }

        var result: Set<Date> = []

        for day in range {

            guard let date = calendar.date(byAdding: .day, value: day-1, to: start)

            else { continue }

            if isHoliday(date, region: region, calendar: calendar) {

                result.insert(calendar.startOfDay(for: date))

            }

        }

        return result

    }

}

private extension HolidayProvider {

    static func isHoliday(

        _ date: Date,

        region: String,

        calendar: Calendar

    ) -> Bool {

        let comp = calendar.dateComponents([.day,.month,.year], from: date)

        guard let day = comp.day,

              let month = comp.month,

              let year = comp.year

        else { return false }

        // festività europee comuni

        if europeanFixed.contains(HolidayKey(day: day, month: month)) {

            return true

        }

        // festività specifiche paese

        if let local = countryFixed[region],

           local.contains(HolidayKey(day: day, month: month)) {

            return true

        }

        // festività mobili

        let easter = easterDate(year: year, calendar: calendar)

        if calendar.isDate(date, inSameDayAs: easter) { return true }

        if let easterMonday = calendar.date(byAdding: .day, value: 1, to: easter),

           calendar.isDate(date, inSameDayAs: easterMonday) { return true }

        // Good Friday solo in alcuni paesi

        if ["ES","DE","GB","UK"].contains(region) {

            if let goodFriday = calendar.date(byAdding: .day, value: -2, to: easter),

               calendar.isDate(date, inSameDayAs: goodFriday) {

                return true

            }

        }

        return false

    }

}

// MARK: - Scroll preference

private struct CalendarScrollOffsetKey: PreferenceKey {

    static var defaultValue: CGFloat = 0

    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {

        value = nextValue()

    }

}





private extension HolidayProvider {

    static let europeanFixed: Set<HolidayKey> = [

        HolidayKey(day: 1, month: 1),   // Capodanno

        HolidayKey(day: 1, month: 5),   // Festa del Lavoro

        HolidayKey(day: 25, month: 12), // Natale

        HolidayKey(day: 26, month: 12)  // Santo Stefano (comune a quasi tutti, tranne FR nazionale)

    ]

    static let countryFixed: [String: Set<HolidayKey>] = [

        "IT": [ // Italia

            HolidayKey(day: 6, month: 1), HolidayKey(day: 25, month: 4),

            HolidayKey(day: 2, month: 6), HolidayKey(day: 15, month: 8),

            HolidayKey(day: 4, month: 10), // San Francesco (Festivo dal 2026)

            HolidayKey(day: 1, month: 11), HolidayKey(day: 8, month: 12)

              ],

        "AT": [ // Austria

            HolidayKey(day: 6, month: 1), HolidayKey(day: 15, month: 8),

            HolidayKey(day: 26, month: 10), // Festa Nazionale

            HolidayKey(day: 1, month: 11), HolidayKey(day: 8, month: 12)

              ],

        "BE": [ // Belgio

            HolidayKey(day: 21, month: 7), // Festa Nazionale

            HolidayKey(day: 15, month: 8), HolidayKey(day: 1, month: 11),

            HolidayKey(day: 11, month: 11) // Armistizio

              ],

        "DE": [ // Germania (Date fisse nazionali Federali)

            HolidayKey(day: 3, month: 10)  // Giorno dell'Unità Tedesca

            // Nota: 1/11 e 6/1 sono regionali (Länder), non federali.

              ],

        "ES": [ // Spagna

            HolidayKey(day: 6, month: 1), HolidayKey(day: 15, month: 8),

            HolidayKey(day: 12, month: 10), // Festa Nazionale (Hispanidad)

            HolidayKey(day: 1, month: 11), HolidayKey(day: 6, month: 12),

            HolidayKey(day: 8, month: 12)

              ],

        "FR": [ // Francia

            HolidayKey(day: 8, month: 5),  // Vittoria 1945

            HolidayKey(day: 14, month: 7), // Presa della Bastiglia

            HolidayKey(day: 15, month: 8), HolidayKey(day: 1, month: 11),

            HolidayKey(day: 11, month: 11) // Armistizio 1918

              ],

        "PT": [ // Portogallo

            HolidayKey(day: 25, month: 4), // Rivoluzione dei Garofani

            HolidayKey(day: 10, month: 6), // Giorno del Portogallo

            HolidayKey(day: 15, month: 8), HolidayKey(day: 5, month: 10),

            HolidayKey(day: 1, month: 11), HolidayKey(day: 1, month: 12),

            HolidayKey(day: 8, month: 12)

              ],

        "PL": [ // Polonia

            HolidayKey(day: 6, month: 1), HolidayKey(day: 3, month: 5), // Costituzione

            HolidayKey(day: 15, month: 8), HolidayKey(day: 1, month: 11),

            HolidayKey(day: 11, month: 11) // Indipendenza

              ],

        "GR": [ // Grecia

            HolidayKey(day: 6, month: 1), HolidayKey(day: 25, month: 3), // Indipendenza

            HolidayKey(day: 15, month: 8), HolidayKey(day: 28, month: 10) // Giorno del No

              ],

        "IE": [ // Irlanda

            HolidayKey(day: 1, month: 2), // S. Brigida

            HolidayKey(day: 17, month: 3) // S. Patrizio

              ],

        "NL": [ // Paesi Bassi

            HolidayKey(day: 27, month: 4), // Giorno del Re (Koningsdag)

            HolidayKey(day: 5, month: 5)   // Liberazione (Bevrijdingsdag - ogni 5 anni festivo)

              ],

        "SE": [ // Svezia

            HolidayKey(day: 6, month: 1),  // Epifania

            HolidayKey(day: 6, month: 6)   // Festa Nazionale

              ],

        "FI": [ // Finlandia

            HolidayKey(day: 6, month: 1),  // Epifania

            HolidayKey(day: 6, month: 12)  // Indipendenza

              ]

    ]

}



private extension HolidayProvider {

    static func easterDate(

        year: Int,

        calendar: Calendar

    ) -> Date {

        let a = year % 19

        let b = year / 100

        let c = year % 100

        let d = b / 4

        let e = b % 4

        let f = (b + 8) / 25

        let g = (b - f + 1) / 3

        let h = (19 * a + b - d - g + 15) % 30

        let i = c / 4

        let k = c % 4

        let l = (32 + 2*e + 2*i - h - k) % 7

        let m = (a + 11*h + 22*l) / 451

        let month = (h + l - 7*m + 114) / 31

        let day = ((h + l - 7*m + 114) % 31) + 1

        var comp = DateComponents()

        comp.year = year

        comp.month = month

        comp.day = day

        return calendar.date(from: comp) ?? .now

    }

}

// MARK: - Actions

private extension TaskCalendarView {

    @MainActor

    func toggleCompleted(_ task: TodoTask) {

        if task.recurrenceRule != nil {

            // Complete(se scelto da utenet) and reschedule recurring task

            task.completeRecurringTask(

                in: modelContext,

                options: settings.recurringTaskOptions

            )

        } else {

            task.isCompleted.toggle()

            task.completedAt = task.isCompleted ? .now : nil

            task.snoozeUntil = nil

        }

        do {

            try modelContext.save()

        } catch {

            AppLogger.persistence.fault("Failed to save context: \(error)")

        }

        NotificationManager.shared.refresh(force: true)

    }

}

// MARK: - Calendar Grid

private extension TaskCalendarView {

    var calendarGrid: some View {

        let days = makeDaysForMonth(displayedMonth)

        return LazyVGrid(

            columns: Array(repeating: GridItem(.flexible()), count: 7),

            spacing: 6

        ) {

            ForEach(days, id: \.self) { day in

                DayCell(

                    date: day,

                    now: .now,

                    isSelected: calendar.isDate(day, inSameDayAs: selectedDate),

                    isInDisplayedMonth: calendar.isDate(day, equalTo: displayedMonth, toGranularity: .month),

                    isToday: calendar.isDateInToday(day),

                    isHoliday: holidayDates.contains(calendar.startOfDay(for: day)),

                    tasks: tasksForDay(day),
                    
                    isExpanded: showExpandedCalendar,
                    
                    isLandscape: isLandscape,

                    onSelect: { selectedDate = day },

                    onToggleCompleted: toggleCompleted,

                    onDelete: { taskToDelete in deleteTask(taskToDelete, in: modelContext)},

                    onAdd: prepareNewTask

                )

            }

        }

        .id(displayedMonth)

        .transition(

            .asymmetric(

                insertion: .move(edge: monthDirection > 0 ? .trailing : .leading),

                removal: .move(edge: monthDirection > 0 ? .leading : .trailing)

            )

        )

    }

}

// MARK: - Day Cell

private struct DayCell: View {

    let date: Date

    let now: Date

    let isSelected: Bool

    let isInDisplayedMonth: Bool

    let isToday: Bool

    let isHoliday: Bool

    let tasks: [TodoTask]

    let isExpanded: Bool
    
    let isLandscape: Bool
    
    let onSelect: () -> Void

    let onToggleCompleted: (TodoTask) -> Void

    let onDelete: (TodoTask) -> Void

    let onAdd: (Date) -> Void

    private let calendar: Calendar = {

        var cal = Calendar.current

        cal.firstWeekday = 2

        return cal

    }()

    @Environment(AppSettings.self) private var settings

    private func iconColor(for task: TodoTask) -> Color {

        if settings.iconStyle == .monochrome {

            return .primary

        } else {

            return task.mainTag?.color ?? task.status.color

        }

    }



    var body: some View {

        VStack(spacing: 2) {

            ZStack {

                if isToday {

                    Circle()

                        .stroke(.blue, lineWidth: 2)

                        .frame(width: 32, height: 32)

                }

                if isSelected {

                    Circle()

                        .stroke(.primary, lineWidth: 2)

                        .frame(width: 26, height: 26)

                }

                let isSunday = calendar.component(.weekday, from: date) == 1

                Text("\(calendar.component(.day, from: date))")

                    .font(.callout.bold())

                    .foregroundStyle(

                        !isInDisplayedMonth

                        ? .secondary

                        : (isHoliday || isSunday ? Color.red : .primary)

                    )

                    .opacity(isInDisplayedMonth ? 1.0 : 0.4)

            }

            .frame(width: 34, height: 34)

            if isExpanded {

                expandedTitles

            } else {

                Circle()

                    .fill(indicatorColor.opacity(indicatorColor == .clear ? 0 : 1))

                    .frame(width: 6, height: 6)

            }

        }

        .frame(maxHeight: .infinity, alignment: .top)

        .contentShape(Rectangle())

        .onTapGesture(coordinateSpace: .local) { location in

            let dayHeaderHeight: CGFloat = 38

            if location.y <= dayHeaderHeight {

                onSelect()

            }

        }

    }

    private var hasOverdueTasks: Bool {

        tasks.contains {

            !$0.isCompleted &&

            (($0.deadLine ?? .distantFuture) < now)

        }

    }

    private var allCompleted: Bool {

        !tasks.isEmpty && tasks.allSatisfy { $0.isCompleted }

    }

    private var hasActiveTasks: Bool {

        tasks.contains { !$0.isCompleted }

    }

    private var indicatorColor: Color {

        if hasOverdueTasks {

            return .red

        }

        if allCompleted {

            return .green

        }

        if hasActiveTasks {

            return .blue

        }

        return .clear

    }

    @ViewBuilder

    private var expandedTitles: some View {

        VStack(
            alignment: .leading,
            spacing: isExpanded ? 3 : 1
        ) {

            let sortedTasks = tasks.sorted {
                ($0.deadLine ?? .distantFuture) < ($1.deadLine ?? .distantFuture)
            }

            let visibleTasks = isExpanded
                ? sortedTasks
                : Array(sortedTasks.prefix(3))

            ForEach(visibleTasks) { task in

                NavigationLink(value: task) {

                    HStack(spacing: 3) {
                        if isLandscape {
                        Image(systemName: task.mainTag?.mainIcon ?? task.status.icon)
                        
                            .font(.system(
                                size: isExpanded ? 7 : 5,
                                weight: .medium
                            ))
                        
                            .symbolRenderingMode(settings.iconStyle == .monochrome ? .monochrome : .palette)
                        
                            .foregroundStyle(iconColor(for: task), .primary)
                    }
                        HStack(spacing: 3) {

                            Text(task.title)

                                .font(.system(
                                    size: isExpanded ? 7 : 4,
                                    weight: .regular
                                ))
                                .lineLimit(isExpanded ? 2 : 1)
                                .fixedSize(horizontal: false, vertical: true)
                                .foregroundStyle(task.isCompleted ? .secondary : .primary)

                                .overlay(alignment: .bottomLeading) {

                                    if settings.showTodayExpiredLabel && isOverdue(task) {

                                        Rectangle()

                                            .fill(Color.red.opacity(0.75))

                                            .frame(height: 0.8)

                                            .offset(y: 1.5)

                                    }

                                }

                                .strikethrough(task.isCompleted, color: .secondary)

                            if isLandscape &&  task.recurrenceRule != nil {

                                Image(systemName: "arrow.triangle.2.circlepath")

                                    .font(.system(size: 5))

                                    .foregroundStyle(.blue)

                            }

                        }

                        Spacer(minLength: 0)

                    }

                    .frame(maxWidth: .infinity, alignment: .leading)

                    .padding(.vertical, isExpanded ? 2 : 1)

                    .contentShape(Rectangle())

                }

                .buttonStyle(.plain)

                .frame(maxWidth: .infinity, alignment: .leading)

                .contentShape(Rectangle())

            }

            if !isExpanded && tasks.count > 3 {
                Text("…")
                    .font(.system(size: 9, weight: .medium))
                    .foregroundStyle(.secondary)
            }

        }

        .frame(maxWidth: .infinity, alignment: .leading)

    }

}

// MARK: - DayTasksInlineView

private struct DayTasksInlineView: View {

    @Environment(\.modelContext) private var modelContext

    @State private var hasAnyTasks: Bool? = nil

    @Environment(AppSettings.self) private var settings

    @State private var taskPendingDeletion: TodoTask?

    let tasks: [TodoTask]

    private var uniqueTasks: [TodoTask] {

        let deduplicated = Array(

            Dictionary(grouping: tasks, by: \.id)

                .compactMap { $0.value.first }

        )

        return deduplicated.sorted {

            let firstDate = $0.deadLine ?? .distantFuture

            let secondDate = $1.deadLine ?? .distantFuture

            if firstDate != secondDate {

                return firstDate < secondDate

            }

            return $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending

        }

    }

    private func iconColor(for task: TodoTask) -> Color {

        if settings.iconStyle == .monochrome {

            return .primary

        } else {

            return task.mainTag?.color ?? task.status.color

        }

    }

    // Helper methods for highlight

    private func shouldShowHighlight(for task: TodoTask) -> Bool {

        guard settings.highlightEnabled else { return false }

        let isCritical = task.priority.systemImage == "flame"

        return isCritical && (

            isOverdue(task) ||

            Calendar.current.isDateInToday(task.deadLine ?? .distantPast)

        )

    }

    private func highlightColor(for task: TodoTask) -> Color {

        Color(hex: settings.highlightColorHex) ?? .red

    }

    @MainActor
    private func refreshTaskExistence() {
        var descriptor = FetchDescriptor<TodoTask>()
        descriptor.fetchLimit = 1

        do {
            hasAnyTasks = !(try modelContext.fetch(descriptor).isEmpty)
        } catch {
            AppLogger.persistence.error("Failed to check task existence: \(error.localizedDescription)")
        }
    }



    var body: some View {

        Group {

        if tasks.isEmpty && hasAnyTasks == false {

            ContentUnavailableView {

                Label {

                    Text("No tasks")

                        .font(.subheadline)

                } icon: {

                    Image(systemName: "tray")

                        .resizable()

                        .frame(width: 30, height: 30)

                        .foregroundStyle(.secondary)

                }

            } description: {

                Text("Tap the green button to add a task.")

                    .font(.subheadline)

            }

        } else {

            List {

                ForEach(uniqueTasks) { task in

                NavigationLink(value: task) {

                        HStack(spacing: 0) {

                            Rectangle()

                                .fill(

                                    shouldShowHighlight(for: task)

                                    ? highlightColor(for: task)

                                    : Color.clear

                                )

                                .frame(width: 1.3)

                                .frame(maxHeight: .infinity)

                                .clipShape(RoundedRectangle(cornerRadius: 2))

                                .padding(.vertical, 1)

                                .padding(.trailing, 10)

                            HStack(alignment: .center, spacing: 10) {

                                Text(task.deadLine?.formatted(.dateTime.hour().minute()) ?? "")

                                    .font(.subheadline.monospacedDigit())

                                    .foregroundStyle(

                                        isOverdue(task) ? .red : .secondary

                                    )

                                    .frame(width: 52, alignment: .leading)

                                    .lineLimit(1)

                                    .minimumScaleFactor(0.75)

                                    .allowsTightening(true)

                                    .dynamicTypeSize(...DynamicTypeSize.xxxLarge)

                                HStack(spacing: 6) {

                                    Text(task.title)

                                        .font(.callout)

                                        .foregroundStyle(task.isCompleted ? .secondary : .primary)

                                .overlay(alignment: .bottomLeading) {

                                    if settings.showTodayExpiredLabel && isOverdue(task) {

                                        Rectangle()

                                            .fill(Color.red.opacity(0.75))

                                            .frame(height: 1)

                                            .offset(y: 2)

                                    }

                                }

                                        .strikethrough(task.isCompleted)

                                    if task.recurrenceRule != nil {

                                        Image(systemName: "arrow.triangle.2.circlepath")

                                            .font(.caption)

                                            .foregroundStyle(.blue)

                                    }

                                }

                                Spacer()

                                HStack(spacing: 6) {

                                    if task.isCompleted {

                                        Image(systemName: "checkmark")

                                            .font(.headline)

                                            .foregroundStyle(.green)

                                    }

                                    Image(systemName: task.mainTag?.mainIcon ?? task.status.icon)

                                        .symbolRenderingMode(settings.iconStyle == .monochrome ? .monochrome : .palette)

                                        .foregroundStyle(iconColor(for: task), .primary)

                                        .shadow(color: Color.black.opacity(0.6), radius: 0.5, x: 0.5, y: 0.5)

                                        .shadow(color: Color.black.opacity(0.6), radius: 0.5, x: -0.5, y: -0.5)

                                }

                            }

                            .frame(maxWidth: .infinity, alignment: .leading)

                        }

                        .frame(maxWidth: .infinity, alignment: .leading)

                        .contentShape(Rectangle())

                        .padding(.vertical, 1)

                    }

                    .buttonStyle(.plain)

                    .contentShape(Rectangle())

                    .listRowBackground(Color.clear)

                    .swipeActions(edge: .leading) {

                        Button {

                            if task.recurrenceRule != nil {

                                // Complete and reschedule recurring task

                                task.completeRecurringTask(

                                    in: modelContext,

                                    options: settings.recurringTaskOptions

                                )

                            } else {

                                task.isCompleted.toggle()

                                if task.isCompleted {

                                    task.completedAt = .now

                                    task.snoozeUntil = nil

                                } else {

                                    task.completedAt = nil

                                    task.snoozeUntil = nil

                                }

                            }

                            do {

                                try modelContext.save()

                            } catch {

                                AppLogger.persistence.fault("Failed to save task completion: \(error)")

                            }

                            NotificationManager.shared.refresh(force: true)
                            
                            NotificationCenter.default.post(
                                name: .taskDidChange,
                                object: nil
                            )

                        } label: {
                            

                            Label(

                                task.isCompleted ? "To do" : "Complete",

                                systemImage: task.isCompleted

                                ? "arrow.uturn.backward"

                                : "checkmark"

                            )

                        }

                        .tint(.green)

                    }

                    .swipeActions(edge: .trailing, allowsFullSwipe: false) {

                        Button(role: .destructive) {

                            if settings.confirmTaskDeletion {

                                taskPendingDeletion = task // <--- Questo attiva l'alert

                            } else {

                                withAnimation {
                                    deleteTask(task, in: modelContext)
                                }

                                NotificationCenter.default.post(
                                    name: .taskDidChange,
                                    object: nil
                                )

                            }

                        } label: {

                            Label("Delete", systemImage: "trash")

                        }

                    }

                    .contextMenu {

                        Button(role: .destructive) {
                            if settings.confirmTaskDeletion {
                                DispatchQueue.main.async {
                                    taskPendingDeletion = task
                                }
                            } else {
                                withAnimation {
                                    deleteTask(task, in: modelContext)
                                    NotificationCenter.default.post(
                                        name: .taskDidChange,
                                        object: nil
                                    )
                                }
                            }
                        } label: {
                            Label("Delete", systemImage: "trash")
                        }

                        Button {
                            if task.recurrenceRule != nil {
                                task.completeRecurringTask(
                                    in: modelContext,
                                    options: settings.recurringTaskOptions
                                )
                            } else {
                                task.isCompleted.toggle()
                                if task.isCompleted {
                                    task.completedAt = .now
                                    task.snoozeUntil = nil
                                } else {
                                    task.completedAt = nil
                                    task.snoozeUntil = nil
                                }
                            }

                            do {
                                try modelContext.save()
                            } catch {
                                AppLogger.persistence.fault(
                                    "Failed to save task completion from context menu: \(error)"
                                )
                            }

                            NotificationManager.shared.refresh(force: true)
                            
                            NotificationCenter.default.post(
                                name: .taskDidChange,
                                object: nil
                            )
                        } label: {
                            Label(
                                  task.isCompleted ? "To do" : "Complete",
                                  systemImage: task.isCompleted
                                      ? "arrow.uturn.backward"
                                      : "checkmark.circle"
                              )
                        }

                        if task.deadLine != nil {
                            Button {
                                TaskSingleCalendarExport.shared.present(for: task)
                            } label: {
                                Label(
                                    "Add to Calendar",
                                    systemImage: "calendar.badge.plus"
                                )
                            }
                        }

                        TaskRescheduleMenu(task: task)

                        if let deadline = task.deadLine,
                           deadline < Date() {
                            Menu {
                                Button {
                                    NotificationActionProcessor.shared.applyManualSnooze(
                                        to: task,
                                        interval: 5 * 60,
                                        using: modelContext
                                    )
                                } label: {
                                    Label(
                                        "5 minutes",
                                        systemImage: "5.arrow.trianglehead.clockwise"
                                    )
                                }

                                Button {
                                    NotificationActionProcessor.shared.applyManualSnooze(
                                        to: task,
                                        interval: 15 * 60,
                                        using: modelContext
                                    )
                                } label: {
                                    Label(
                                        "15 minutes",
                                        systemImage: "15.arrow.trianglehead.clockwise"
                                    )
                                }

                                Button {
                                    NotificationActionProcessor.shared.applyManualSnooze(
                                        to: task,
                                        interval: 30 * 60,
                                        using: modelContext
                                    )
                                } label: {
                                    Label(
                                        "30 minutes",
                                        systemImage: "30.arrow.trianglehead.clockwise"
                                    )
                                }

                                Button {
                                    NotificationActionProcessor.shared.applyManualSnooze(
                                        to: task,
                                        interval: 60 * 60,
                                        using: modelContext
                                    )
                                } label: {
                                    Label(
                                        "1 hour",
                                        systemImage: "60.arrow.trianglehead.clockwise"
                                    )
                                }

                                Button {
                                    NotificationActionProcessor.shared.applyManualSnooze(
                                        to: task,
                                        interval: 3 * 60 * 60,
                                        using: modelContext
                                    )
                                } label: {
                                    Label(
                                        "3 hours",
                                        systemImage: "plus.arrow.trianglehead.clockwise"
                                    )
                                }
                            } label: {
                                Label("Snooze", systemImage: "timer")
                            }
                        }

                        Menu {
                            Button {
                                do {
                                    _ = try TaskDuplicationService.duplicate(
                                        task,
                                        using: modelContext,
                                        includingAttachments: false
                                    )
                                    NotificationCenter.default.post(
                                        name: .taskDidChange,
                                        object: nil
                                    )
                                } catch {
                                    AppLogger.persistence.error(
                                        "Task duplication failed: \(error.localizedDescription)"
                                    )
                                }
                            } label: {
                                Label("Task", systemImage: "text.badge.checkmark")
                            }

                            if !(task.attachments?.isEmpty ?? true) {
                                Button {
                                    do {
                                        _ = try TaskDuplicationService.duplicate(
                                            task,
                                            using: modelContext,
                                            includingAttachments: true
                                        )
                                        NotificationCenter.default.post(
                                            name: .taskDidChange,
                                            object: nil
                                        )
                                    } catch {
                                        AppLogger.persistence.error(
                                            "Task duplication failed: \(error.localizedDescription)"
                                        )
                                    }
                                } label: {
                                    Label(
                                        "Task & Attachments",
                                        systemImage: "rectangle.and.paperclip"
                                    )
                                }
                            }
                        } label: {
                            Label("Duplicate", systemImage: "plus.square.on.square")
                        }

                    }

                }

            }

            .contentMargins(.bottom,70, for:.scrollContent)

            .listStyle(.plain)

            .scrollContentBackground(.hidden)

            .background(Color.clear)

            .alert("Delete task?",

                   isPresented: Binding(

                    get: { taskPendingDeletion != nil },

                    set: { if !$0 { taskPendingDeletion = nil } }

                   )

            ) {

                Button("Delete", role: .destructive) {

                    if let task = taskPendingDeletion {

                        withAnimation {
                            deleteTask(task, in: modelContext)
                        }

                        NotificationCenter.default.post(
                            name: .taskDidChange,
                            object: nil
                        )

                        taskPendingDeletion = nil

                    }

                }

                Button("Cancel", role: .cancel) {

                    taskPendingDeletion = nil

                }

            } message: {

                Text("This action cannot be undone.")

            }

        }

        }
        .onAppear {
            refreshTaskExistence()
        }
        .onReceive(
            NotificationCenter.default.publisher(for: .taskDidChange)
        ) { _ in
            refreshTaskExistence()
        }

    }

}



// MARK: - NewTaskSelection

struct NewTaskSelection: Identifiable {

    let id = UUID()

    let date: Date

}

private func isOverdue(_ task: TodoTask) -> Bool {

    guard let deadline = task.deadLine else { return false }

    return !task.isCompleted && deadline < .now

}



struct ZoomableScrollView<Content: View>: UIViewRepresentable {

    let content: Content

    let minScale: CGFloat

    let maxScale: CGFloat

    init(minScale: CGFloat = 1,

         maxScale: CGFloat = 2,

         @ViewBuilder content: () -> Content) {

        self.content = content()

        self.minScale = minScale

        self.maxScale = maxScale

    }

    func makeCoordinator() -> Coordinator {

        Coordinator()

    }



    func makeUIView(context: Context) -> UIScrollView {

        let scrollView = UIScrollView()

        scrollView.minimumZoomScale = minScale

        scrollView.maximumZoomScale = maxScale

        scrollView.bouncesZoom = true

        scrollView.alwaysBounceVertical = true

        scrollView.alwaysBounceHorizontal = true

        // Improve pinch zoom responsiveness

        scrollView.delaysContentTouches = false

        scrollView.canCancelContentTouches = true

        scrollView.panGestureRecognizer.cancelsTouchesInView = false

        scrollView.pinchGestureRecognizer?.delaysTouchesBegan = false

        scrollView.pinchGestureRecognizer?.cancelsTouchesInView = false

        scrollView.decelerationRate = .fast

        scrollView.showsVerticalScrollIndicator = false

        scrollView.showsHorizontalScrollIndicator = false

        scrollView.delegate = context.coordinator

        scrollView.panGestureRecognizer.minimumNumberOfTouches = 2

        scrollView.contentInset = .zero

        scrollView.contentInsetAdjustmentBehavior = .never

        let host = UIHostingController(rootView: content)

        host.sizingOptions = .intrinsicContentSize

        host.view.translatesAutoresizingMaskIntoConstraints = false

        host.view.backgroundColor = .clear

        scrollView.addSubview(host.view)

        context.coordinator.hostingController = host

        NSLayoutConstraint.activate([

            host.view.leadingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.leadingAnchor),

            host.view.trailingAnchor.constraint(equalTo: scrollView.contentLayoutGuide.trailingAnchor),

            host.view.topAnchor.constraint(equalTo: scrollView.contentLayoutGuide.topAnchor),

            host.view.bottomAnchor.constraint(equalTo: scrollView.contentLayoutGuide.bottomAnchor),

            host.view.widthAnchor.constraint(equalTo: scrollView.frameLayoutGuide.widthAnchor)

        ])



        return scrollView

    }

    func updateUIView(_ uiView: UIScrollView, context: Context) {

        context.coordinator.hostingController?.rootView = content

    }

    class Coordinator: NSObject, UIScrollViewDelegate {

        var hostingController: UIHostingController<Content>?

        func viewForZooming(in scrollView: UIScrollView) -> UIView? {

            hostingController?.view

        }

        func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {

            scrollView.isScrollEnabled = true

        }

    }

}
