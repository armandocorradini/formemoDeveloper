
import SwiftData
import Foundation
import os

@Model
final class TaskAttachment {
    
    var id: UUID = UUID()
    
    var originalName: String = ""
    //    var fileName: String = ""
    var contentType: String = ""
    var createdAt: Date = Date()
    var relativePath: String = ""
    
    
    var task: TodoTask?
    
    init(
        originalName: String,
        relativePath: String,
        //        fileName: String ,
        contentType: String,
        task: TodoTask?
    ) {
        self.originalName = originalName
        //        self.fileName = fileName
        self.relativePath = relativePath
        self.contentType = contentType
        self.task = task
    }
}
extension TaskAttachment {
    
    /// Local persistent asset directory.
    ///
    /// This is deliberately independent of iCloud availability. The resolver
    /// uses this directory as its first local source; iCloud remains a
    /// separate fallback/source until the storage write path is migrated.
    static var attachmentsDirectory: URL? {
        AssetDirectoryCoordinator.localDirectory(for: .taskAttachments)
            ?? legacyAttachmentsDirectory()
    }
    
    static func ensureAttachmentsDirectoryForWrite() throws -> URL {
        try AssetDirectoryCoordinator.ensureCanonicalDirectory(
            for: .taskAttachments
        )
    }
    
    static var trashDirectory: URL? {
        FileManager.default
            .urls(
                for: .documentDirectory,
                in: .userDomainMask
            )
            .first?
            .appendingPathComponent(
                "TaskAttachments_Trash",
                isDirectory: true
            )
    }

    private static func legacyCloudTrashDirectory() -> URL? {
        guard let containerURL = FileManager.default.url(
            forUbiquityContainerIdentifier:
                "iCloud.corradini.armando.NewTask"
        ) else {
            return nil
        }

        return containerURL
            .appendingPathComponent(
                "Documents",
                isDirectory: true
            )
            .appendingPathComponent(
                "TaskAttachments_Trash",
                isDirectory: true
            )
    }


    
    static func trashFileURL(
        trashFileName: String
    ) -> URL? {

        let fm = FileManager.default

        // 1. Canonical local Trash
        if let local = trashDirectory?
            .appendingPathComponent(trashFileName),
           fm.fileExists(atPath: local.path) {
            return local
        }

        // 2. Canonical iCloud Trash
        if let legacy = legacyCloudTrashDirectory()?
            .appendingPathComponent(trashFileName),
           fm.fileExists(atPath: legacy.path) {
            return legacy
        }

        // 3. CloudDocs conflict Trash directories
        for directory in duplicateCloudTrashDirectories() {
            let candidate = directory.appendingPathComponent(trashFileName)

            if fm.fileExists(atPath: candidate.path) {
                return candidate
            }
        }

        return nil
    }
    

    private static func legacyAttachmentsDirectory() -> URL? {
        guard let directory = FileManager.default.urls(
            for: .documentDirectory,
            in: .userDomainMask
        ).first?.appendingPathComponent(
            "TaskAttachments",
            isDirectory: true
        ) else {
            return nil
        }

        guard FileManager.default.fileExists(atPath: directory.path) else {
            return nil
        }

        return directory
    }

    private static func cloudAttachmentsDirectory() -> URL? {

        guard let containerURL = FileManager.default.url(
            forUbiquityContainerIdentifier: "iCloud.corradini.armando.NewTask"
        ) else {
            return nil
        }

        return containerURL
            .appendingPathComponent("Documents", isDirectory: true)
            .appendingPathComponent("TaskAttachments", isDirectory: true)
    }

    private static func duplicateCloudAttachmentDirectories() -> [URL] {
        guard let containerURL = FileManager.default.url(
            forUbiquityContainerIdentifier: "iCloud.corradini.armando.NewTask"
        ) else {
            return []
        }

        let fm = FileManager.default
        let documents = containerURL.appendingPathComponent("Documents", isDirectory: true)
        guard let items = try? fm.contentsOfDirectory(
            at: documents,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else {
            return []
        }

        // CloudDocs may suffix a concurrently-created directory with a number.
        // These are read-only fallback locations; imports always use the canonical
        // TaskAttachments directory.
        return items.filter { url in
            guard (try? url.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory == true else {
                return false
            }
            let name = url.lastPathComponent
            return name.hasPrefix("TaskAttachments ")
        }.sorted { $0.lastPathComponent < $1.lastPathComponent }
    }

    private static func duplicateCloudTrashDirectories() -> [URL] {
        guard let containerURL = FileManager.default.url(
            forUbiquityContainerIdentifier: "iCloud.corradini.armando.NewTask"
        ) else {
            return []
        }

        let fm = FileManager.default
        let documents = containerURL.appendingPathComponent(
            "Documents",
            isDirectory: true
        )

        guard let items = try? fm.contentsOfDirectory(
            at: documents,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        ) else {
            return []
        }

        return items.filter { url in
            guard
                (try? url.resourceValues(
                    forKeys: [.isDirectoryKey]
                ))?.isDirectory == true
            else {
                return false
            }

            return url.lastPathComponent.hasPrefix("TaskAttachments_Trash ")
        }
        .sorted {
            $0.lastPathComponent < $1.lastPathComponent
        }
    }
    
    
    
    
    
    private static func resolvedExistingURL(
        relativePath: String
    ) -> URL? {

        DebugLog.write(
            """
            📎 Resolver start
            relativePath = \(relativePath)
            iCloudDir = \(cloudAttachmentsDirectory() != nil)
            legacyDir = \(legacyAttachmentsDirectory() != nil)
            """
        )

        let fm = FileManager.default
        
        DebugLog.write("════════════════════════════════════")
        DebugLog.write("RESOLVER START")
        DebugLog.write("relativePath = \(relativePath)")
        DebugLog.write(
            "attachmentsDirectory = \(attachmentsDirectory == nil ? "Missing" : "Available")"
        )
        DebugLog.write(
            "cloudDirectory = \(cloudAttachmentsDirectory() == nil ? "Unavailable" : "Available")"
        )
        DebugLog.write(
            "legacyDirectory = \(legacyAttachmentsDirectory() == nil ? "Unavailable" : "Available")"
        )
        DebugLog.write("════════════════════════════════════")
        

        // ===== Directory diagnostics =====

        if let directory = attachmentsDirectory {

            let exists = fm.fileExists(atPath: directory.path)

            DebugLog.write(
                """
                📁 Attachments directory exists: \(exists)
                📁 Directory: \(directory.path)
                """
            )

            if let files = try? fm.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: nil
            ) {

                DebugLog.write(
                    "📁 Files in directory: \(files.count)"
                )

                for file in files.prefix(30) {
                    DebugLog.write(
                        "   • \(file.lastPathComponent)"
                    )
                }
            }

        } else {

            DebugLog.write(
                "📁 Attachments directory is NIL"
            )
        }

        // ===== Candidate diagnostics =====

        if let cloudDir = cloudAttachmentsDirectory() {

            let candidate = cloudDir.appendingPathComponent(relativePath)

            DebugLog.write(
                """
                ☁️ Cloud candidate
                exists = \(fm.fileExists(atPath: candidate.path))
                """
            )

        } else {

            DebugLog.write(
                """
                ☁️ Cloud candidate
                directory = unavailable
                """
            )

        }

        if let legacyDir = legacyAttachmentsDirectory() {

            let candidate = legacyDir.appendingPathComponent(relativePath)

            DebugLog.write(
                """
                📂 Legacy candidate
                exists = \(fm.fileExists(atPath: candidate.path))
                """
            )

        } else {

            DebugLog.write(
                """
                📂 Legacy candidate
                directory = unavailable
                """
            )

        }

        // 1️⃣ Local canonical
        // =====================================================

        if let localDir = attachmentsDirectory {
            let local = localDir.appendingPathComponent(relativePath)

            if fm.fileExists(atPath: local.path) {
                DebugLog.write("📱 Local canonical file FOUND")
                return local
            }
        }




        // 1️⃣ Cloud
        // =====================================================

        if let cloudDir = cloudAttachmentsDirectory() {

            let cloud = cloudDir.appendingPathComponent(relativePath)

            DebugLog.write("Cloud candidate = \(cloud.path)")

            let exists = fm.fileExists(atPath: cloud.path)

            let values = try? cloud.resourceValues(forKeys: [
                .isUbiquitousItemKey,
                .ubiquitousItemIsDownloadingKey,
                .ubiquitousItemDownloadingStatusKey,
                .fileSizeKey
            ])

            let status = values?.ubiquitousItemDownloadingStatus
            let isUbiquitous = values?.isUbiquitousItem ?? false
            let isDownloading = values?.ubiquitousItemIsDownloading ?? false
            let size = values?.fileSize ?? 0

            DebugLog.write(
                """
                ☁️ Cloud candidate
                exists = \(exists)
                ubiquitous = \(isUbiquitous)
                downloading = \(isDownloading)
                status = \(String(describing: status))
                size = \(size)
                """
            )

            // Il record CloudKit può arrivare prima della
            // materializzazione locale del file.
            // Il resolver deve solo risolvere l'URL.
            // La richiesta di download è responsabilità di loadDataAsync().
            if isUbiquitous || exists {

                if !exists ||
                    status == .notDownloaded {
                    return cloud
                }

                if status == .current || status == .downloaded,
                   size > 0 {

                    DebugLog.write(
                        "☁️ Cloud asset materialized"
                    )

                    if let localDir = attachmentsDirectory {

                        let local = localDir.appendingPathComponent(
                            relativePath
                        )

                        if !fm.fileExists(atPath: local.path) {

                            do {
                                try fm.createDirectory(
                                    at: localDir,
                                    withIntermediateDirectories: true
                                )

                                let coordinator = NSFileCoordinator()
                                var coordinationError: NSError?
                                var copyError: Error?

                                coordinator.coordinate(
                                    readingItemAt: cloud,
                                    options: [],
                                    writingItemAt: local,
                                    options: .forReplacing,
                                    error: &coordinationError
                                ) { sourceURL, destinationURL in

                                    do {
                                        try fm.copyItem(
                                            at: sourceURL,
                                            to: destinationURL
                                        )
                                    } catch {
                                        copyError = error
                                    }
                                }

                                if let coordinationError {
                                    throw coordinationError
                                }

                                if let copyError {
                                    throw copyError
                                }

                                let localSize =
                                    (try? fm.attributesOfItem(
                                        atPath: local.path
                                    )[.size] as? NSNumber)?.int64Value ?? 0

                                if localSize > 0 {
                                    DebugLog.write(
                                        "📱 Cloud asset copied to local canonical"
                                    )

                                    return local
                                }

                            } catch {
                                DebugLog.write(
                                    "📱 Local asset copy failed: \(error.localizedDescription)"
                                )
                            }
                        } else {
                            DebugLog.write(
                                "📱 Local canonical already contains asset"
                            )

                            return local
                        }
                    }

                    return cloud
                }

                if exists, size > 0 {

                    DebugLog.write(
                        "☁️ Returning existing cloud URL"
                    )

                    return cloud
                }
            }
        }

        // CloudDocs conflict directories (for example, TaskAttachments 2) can
        // contain files referenced by already-synced SwiftData records. Resolve
        // them without copying, moving, or deleting production data.
        for duplicateDirectory in duplicateCloudAttachmentDirectories() {
            let candidate = duplicateDirectory.appendingPathComponent(relativePath)
            guard fm.fileExists(atPath: candidate.path) else {
                continue
            }

            // Il resolver non avvia il download.
            // La richiesta di materializzazione è responsabilità di loadDataAsync().
            return candidate
        }
        // =====================================================
        // 2️⃣ Legacy
        // =====================================================


        if let legacy = legacyAttachmentsDirectory()?
            .appendingPathComponent(relativePath),
           fm.fileExists(atPath: legacy.path) {

            DebugLog.write(
                "📂 Legacy file FOUND"
            )

            return legacy
        }

        // =====================================================
        // 3️⃣ Trash
        // =====================================================

        var trashDirectories: [URL] = []

        if let trashDirectory {
            trashDirectories.append(trashDirectory)
        }

        if let legacyTrash = legacyCloudTrashDirectory() {
            trashDirectories.append(legacyTrash)
        }

        trashDirectories.append(
            contentsOf: duplicateCloudTrashDirectories()
        )

        for trashDirectory in trashDirectories {

            guard let recovered = try? fm.contentsOfDirectory(
                at: trashDirectory,
                includingPropertiesForKeys: nil
            ).first(where: {
                $0.lastPathComponent.hasSuffix(relativePath)
            }) else {
                continue
            }

            DebugLog.write(
                """
                🗑 Recovered from Trash

                Directory:
                \(trashDirectory.path)

                File:
                \(recovered.lastPathComponent)
                """
            )

            return recovered
        }

        DebugLog.write(
            """
            📎 Resolver FAILED
            relativePath = \(relativePath)
            """
        )

        return nil
    }
    
    var isActuallyAvailable: Bool {

        guard let url = fileURL else {
            return false
        }

        let fm = FileManager.default

        guard fm.fileExists(atPath: url.path) else {
            return false
        }

        let size = (try? fm.attributesOfItem(
            atPath: url.path
        )[.size] as? Int64) ?? 0

        guard size > 0 else {
            return false
        }

        return true
    }
    
    var fileURL: URL? {

        Self.resolvedExistingURL(
            relativePath: relativePath
        )
    }
    
    /// Checks every attachment before any task-deletion mutation begins.
    @MainActor
    static func attachmentsAreSafeToDelete(
        _ attachments: [TaskAttachment]
    ) -> Bool {
        attachments.allSatisfy { isSafeToDelete($0) }
    }

    /// A locally complete copy is sufficient for safe deletion. iCloud upload
    /// state is independent: the local file can be recovered from Trash.
    @MainActor
    private static func isSafeToDelete(_ attachment: TaskAttachment) -> Bool {
        guard !attachment.relativePath.isEmpty,
              let localDirectory = attachmentsDirectory else {
            return false
        }

        let fileManager = FileManager.default
        let localURL = localDirectory.appendingPathComponent(
            attachment.relativePath,
            isDirectory: false
        )

        guard fileManager.fileExists(atPath: localURL.path),
              let localAttributes = try? fileManager.attributesOfItem(
                atPath: localURL.path
              ),
              let localSize = localAttributes[.size] as? NSNumber,
              localSize.int64Value > 0 else {
            return false
        }

        return true
    }

    private static func cloudFileIsFullyUploaded(at url: URL) -> Bool {
        let resourceKeys: Set<URLResourceKey> = [
            .isUbiquitousItemKey,
            .ubiquitousItemIsUploadedKey,
            .ubiquitousItemIsUploadingKey,
            .ubiquitousItemIsDownloadingKey,
            .ubiquitousItemHasUnresolvedConflictsKey
        ]

        let coordinator = NSFileCoordinator()
        var coordinationError: NSError?
        var isReady = false

        coordinator.coordinate(
            readingItemAt: url,
            options: [],
            error: &coordinationError
        ) { coordinatedURL in
            guard let values = try? coordinatedURL.resourceValues(
                forKeys: resourceKeys
            ) else {
                return
            }

            isReady =
                values.isUbiquitousItem == true &&
                values.ubiquitousItemIsUploaded == true &&
                values.ubiquitousItemIsUploading == false &&
                values.ubiquitousItemIsDownloading == false &&
                values.ubiquitousItemHasUnresolvedConflicts == false
        }

        return coordinationError == nil && isReady
    }

    var fileStatus: FileStatus {
        
        guard let url = fileURL else { return .missing }
        
        let fm = FileManager.default
        
        let exists = fm.fileExists(atPath: url.path)
        
        let values = try? url.resourceValues(forKeys: [
            .ubiquitousItemDownloadingStatusKey
        ])
        
        let status = values?.ubiquitousItemDownloadingStatus
        
        switch status {
            
        case .current:
            return exists ? .ready : .downloading
            
        case .downloaded:
            return exists ? .ready : .downloading
            
        case .notDownloaded:
            return .notDownloaded
            
        default:
            return exists ? .ready : .downloading
        }
    }
    
    
    func deleteFileIfNeeded() throws -> String? {
        guard
            let attachmentsDirectory = Self.attachmentsDirectory,
            Self.isSafeRelativeAssetPath(relativePath)
        else {
            throw CocoaError(.fileNoSuchFile)
        }

        let fm = FileManager.default
        let rootURL = attachmentsDirectory.standardizedFileURL
        let sourceURL = rootURL
            .appendingPathComponent(relativePath, isDirectory: false)
            .standardizedFileURL

        // The resolved source must remain inside the canonical attachment directory.
        let rootPrefix = rootURL.path.hasSuffix("/")
            ? rootURL.path
            : rootURL.path + "/"

        guard sourceURL.path.hasPrefix(rootPrefix) else {
            throw CocoaError(.fileWriteNoPermission)
        }

        // Reject symbolic-link ancestors so a valid-looking relative path cannot
        // redirect the move outside the attachment directory.
        var ancestorURL = rootURL
        let pathComponents = relativePath.split(separator: "/")
        for component in pathComponents.dropLast() {
            ancestorURL.appendPathComponent(String(component), isDirectory: true)
            if fm.fileExists(atPath: ancestorURL.path) {
                let values = try ancestorURL.resourceValues(forKeys: [
                    .isDirectoryKey,
                    .isSymbolicLinkKey
                ])
                guard values.isDirectory == true,
                      values.isSymbolicLink != true else {
                    throw CocoaError(.fileWriteNoPermission)
                }
            }
        }

        if fm.fileExists(atPath: sourceURL.path) {
            let values = try sourceURL.resourceValues(forKeys: [.isSymbolicLinkKey])
            guard values.isSymbolicLink != true else {
                throw CocoaError(.fileWriteNoPermission)
            }
        }

        // Se il file non esiste già → nessuna azione
        guard fm.fileExists(atPath: sourceURL.path) else {
            throw CocoaError(.fileWriteNoPermission)
        }

        guard let trashDir = Self.trashDirectory else {
            AppLogger.persistence.fault(
                "Trash directory unavailable. Cleanup aborted."
            )
            throw CocoaError(.fileWriteNoPermission)
        }

        do {
            try fm.createDirectory(
                at: trashDir,
                withIntermediateDirectories: true
            )
        } catch {
            AppLogger.persistence.error(
                "Unable to create TaskAttachments Trash directory: \(error.localizedDescription)"
            )
            throw error
        }
        
        // Nome unico per evitare collisioni
        let uniqueName = UUID().uuidString + "_" + sourceURL.lastPathComponent
        let destinationURL = trashDir.appendingPathComponent(uniqueName)

        let coordinator = NSFileCoordinator()
        var coordError: NSError?
        var result: String? = nil

        coordinator.coordinate(
            writingItemAt: sourceURL,
            options: .forMoving,
            writingItemAt: destinationURL,
            options: .forReplacing,
            error: &coordError
        ) { readURL, writeURL in
            do {
                try fm.moveItem(at: readURL, to: writeURL)

                // 🔥 verifica reale
                let size = (try? fm.attributesOfItem(atPath: writeURL.path)[.size] as? Int64) ?? 0
                if size == 0 {
                    try? fm.removeItem(at: writeURL)
                    throw NSError(domain: "AttachmentImporter", code: 3, userInfo: [
                        NSLocalizedDescriptionKey: "Moved file is empty"
                    ])
                }

                result = writeURL.lastPathComponent
            } catch {
                AppLogger.persistence.fault(
                    "Move to Trash failed: \(error.localizedDescription)"
                )

                result = nil
            }
        }

        if let coordError {
            AppLogger.persistence.fault(
                "Attachment file coordination failed: \(coordError.localizedDescription)"
            )
            throw coordError
        }

        guard let result else { throw CocoaError(.fileWriteUnknown) }

        return result
    }
    
    /// Restores a staged attachment to its canonical local path. The operation
    /// is idempotent when the file is already restored and the Trash copy is gone.
    /// It never overwrites an existing destination or follows symlink ancestors.
    static func restoreFileFromTrash(
        trashFileName: String,
        relativePath: String
    ) throws {
        guard !trashFileName.isEmpty,
              !trashFileName.contains("/"),
              !trashFileName.contains("\\"),
              trashFileName != ".",
              trashFileName != "..",
              isSafeRelativeAssetPath(relativePath),
              let attachmentsDirectory = attachmentsDirectory else {
            throw CocoaError(.fileWriteNoPermission)
        }

        let fm = FileManager.default
        let rootURL = attachmentsDirectory.standardizedFileURL
        let destinationURL = rootURL
            .appendingPathComponent(relativePath, isDirectory: false)
            .standardizedFileURL
        let rootPrefix = rootURL.path.hasSuffix("/")
            ? rootURL.path
            : rootURL.path + "/"

        guard destinationURL.path.hasPrefix(rootPrefix) else {
            throw CocoaError(.fileWriteNoPermission)
        }

        guard let sourceURL = trashFileURL(trashFileName: trashFileName)?.standardizedFileURL else {
            // A prior restore may already have completed before a retry.
            if fm.fileExists(atPath: destinationURL.path) {
                return
            }
            throw CocoaError(.fileNoSuchFile)
        }

        if fm.fileExists(atPath: destinationURL.path) {
            throw CocoaError(.fileWriteFileExists)
        }

        var ancestorURL = rootURL
        let components = relativePath.split(separator: "/")
        for component in components.dropLast() {
            ancestorURL.appendPathComponent(String(component), isDirectory: true)
            if fm.fileExists(atPath: ancestorURL.path) {
                let values = try ancestorURL.resourceValues(forKeys: [
                    .isDirectoryKey,
                    .isSymbolicLinkKey
                ])
                guard values.isDirectory == true,
                      values.isSymbolicLink != true else {
                    throw CocoaError(.fileWriteNoPermission)
                }
            } else {
                try fm.createDirectory(
                    at: ancestorURL,
                    withIntermediateDirectories: true
                )
            }
        }

        let sourceValues = try sourceURL.resourceValues(forKeys: [.isSymbolicLinkKey])
        guard sourceValues.isSymbolicLink != true else {
            throw CocoaError(.fileWriteNoPermission)
        }

        var coordinationError: NSError?
        var moveError: Error?
        NSFileCoordinator().coordinate(
            writingItemAt: sourceURL,
            options: .forMoving,
            writingItemAt: destinationURL,
            options: .forReplacing,
            error: &coordinationError
        ) { coordinatedSource, coordinatedDestination in
            do {
                guard !fm.fileExists(atPath: coordinatedDestination.path) else {
                    throw CocoaError(.fileWriteFileExists)
                }
                try fm.moveItem(
                    at: coordinatedSource,
                    to: coordinatedDestination
                )
            } catch {
                moveError = error
            }
        }

        if let coordinationError {
            throw coordinationError
        }
        if let moveError {
            throw moveError
        }

        guard fm.fileExists(atPath: destinationURL.path),
              !fm.fileExists(atPath: sourceURL.path) else {
            throw CocoaError(.fileWriteUnknown)
        }

        AppLogger.persistence.notice(
            "TaskAttachment restored from Trash: \(relativePath)"
        )
    }

    // MARK: - Delete Cloud Mirror

    enum CloudMirrorDeletionResult: Equatable {
        case deleted
        case alreadyMissing
    }

    enum CloudMirrorDeletionError: LocalizedError {
        case invalidRelativePath(String)
        case cloudDirectoryUnavailable

        var errorDescription: String? {
            switch self {
            case .invalidRelativePath:
                return "The attachment relative path is invalid."
            case .cloudDirectoryUnavailable:
                return "The iCloud attachment directory is unavailable."
            }
        }
    }

    /// Compatibility wrapper for existing callers. New cleanup code should use
    /// deleteCloudMirrorVerified so it can observe and handle failures.
    static func deleteCloudMirror(relativePath: String) {
        guard let cloudDirectory = AssetDirectoryCoordinator.cloudDirectory(
            for: .taskAttachments
        ) else {
            return
        }

        do {
            _ = try deleteCloudMirrorVerified(
                relativePath: relativePath,
                cloudDirectory: cloudDirectory
            )
        } catch {
            AppLogger.persistence.error(
                "Unable to delete TaskAttachment cloud mirror: \(error.localizedDescription)"
            )
        }
    }

    /// Deletes the canonical cloud copy and reports whether it was removed or
    /// was already absent. A missing iCloud container and filesystem failures
    /// are errors, not silent success.
    @discardableResult
    static func deleteCloudMirrorVerified(
        relativePath: String,
        cloudDirectory overrideDirectory: URL? = nil,
        deletionOperation: ((URL) throws -> Void)? = nil
    ) throws -> CloudMirrorDeletionResult {
        guard isSafeRelativeAssetPath(relativePath) else {
            throw CloudMirrorDeletionError.invalidRelativePath(relativePath)
        }

        guard let cloudDirectory = overrideDirectory
                ?? AssetDirectoryCoordinator.cloudDirectory(for: .taskAttachments) else {
            throw CloudMirrorDeletionError.cloudDirectoryUnavailable
        }

        let rootURL = cloudDirectory.standardizedFileURL
        let cloudURL = rootURL
            .appendingPathComponent(relativePath, isDirectory: false)
            .standardizedFileURL
        let rootPrefix = rootURL.path.hasSuffix("/")
            ? rootURL.path
            : rootURL.path + "/"

        guard cloudURL.path.hasPrefix(rootPrefix) else {
            throw CloudMirrorDeletionError.invalidRelativePath(relativePath)
        }

        let fm = FileManager.default
        var ancestorURL = rootURL
        let pathComponents = relativePath.split(separator: "/")
        for component in pathComponents.dropLast() {
            ancestorURL.appendPathComponent(String(component), isDirectory: true)
            if fm.fileExists(atPath: ancestorURL.path) {
                let values = try ancestorURL.resourceValues(forKeys: [
                    .isDirectoryKey,
                    .isSymbolicLinkKey
                ])
                guard values.isDirectory == true,
                      values.isSymbolicLink != true else {
                    throw CloudMirrorDeletionError.invalidRelativePath(relativePath)
                }
            }
        }
        guard fm.fileExists(atPath: cloudURL.path) else {
            return .alreadyMissing
        }

        if let deletionOperation {
            try deletionOperation(cloudURL)
        } else {
            var coordinationError: NSError?
            var deletionError: Error?

            NSFileCoordinator().coordinate(
                writingItemAt: cloudURL,
                options: .forDeleting,
                error: &coordinationError
            ) { coordinatedURL in
                do {
                    if fm.fileExists(atPath: coordinatedURL.path) {
                        try fm.removeItem(at: coordinatedURL)
                    }
                } catch {
                    deletionError = error
                }
            }

            if let coordinationError {
                throw coordinationError
            }
            if let deletionError {
                throw deletionError
            }
        }

        guard !fm.fileExists(atPath: cloudURL.path) else {
            throw CocoaError(.fileWriteUnknown)
        }

        AppLogger.persistence.notice(
            "TaskAttachment cloud mirror deleted: \(relativePath)"
        )
        return .deleted
    }

    static func isSafeRelativeAssetPath(_ relativePath: String) -> Bool {
        guard !relativePath.isEmpty,
              !relativePath.hasPrefix("/"),
              !relativePath.contains("\0") else {
            return false
        }

        let components = relativePath.split(separator: "/", omittingEmptySubsequences: false)
        return !components.isEmpty &&
            components.allSatisfy { !$0.isEmpty && $0 != "." && $0 != ".." } &&
            !relativePath.contains("\\")
    }

    static func removeAllPhysicalFiles(
        in directory: URL?
    ) throws {

        guard let directory else {
            return
        }

        let fm = FileManager.default

        guard fm.fileExists(atPath: directory.path) else {
            return
        }

        func removeContents(of directory: URL) throws {

            let items = try fm.contentsOfDirectory(
                at: directory,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: []
            )

            for itemURL in items {

                let values = try itemURL.resourceValues(
                    forKeys: [.isDirectoryKey]
                )

                if values.isDirectory == true {

                    // Prima eliminiamo ricorsivamente il contenuto.
                    try removeContents(of: itemURL)

                }

                let coordinator = NSFileCoordinator()
                var coordinationError: NSError?
                var deletionError: Error?

                coordinator.coordinate(
                    writingItemAt: itemURL,
                    options: .forDeleting,
                    error: &coordinationError
                ) { coordinatedURL in

                    do {
                        if fm.fileExists(atPath: coordinatedURL.path) {
                            try fm.removeItem(at: coordinatedURL)
                        }
                    } catch {
                        deletionError = error
                    }
                }

                if let coordinationError {
                    throw coordinationError
                }

                if let deletionError {
                    throw deletionError
                }
            }
        }

        try removeContents(of: directory)
    }
    
    
}


extension TaskAttachment {
    
    func loadDataAsync() async -> Data? {
        guard let url = fileURL else {
            return nil
        }

        let fm = FileManager.default

        try? fm.startDownloadingUbiquitousItem(at: url)

        // 🔥 Wait real materialization
        for _ in 0..<40 {

            let exists = fm.fileExists(atPath: url.path)

            let values = try? url.resourceValues(forKeys: [
                .ubiquitousItemDownloadingStatusKey
            ])

            let status = values?.ubiquitousItemDownloadingStatus

            if exists && (status == .current || status == .downloaded || status == nil) {
                break
            }

            try? await Task.sleep(nanoseconds: 200_000_000)
        }

        guard fm.fileExists(atPath: url.path) else {
            return nil
        }

        guard let data = try? Data(contentsOf: url),
              !data.isEmpty else {

            return nil
        }
        return data
    }
}


extension TaskAttachment {
    
    var shortDisplayName: String {
        
        let url = URL(fileURLWithPath: originalName)
        
        let name = url.deletingPathExtension().lastPathComponent
        let ext = url.pathExtension
        
        let maxLength = 8
        
        if name.count <= maxLength {
            return ext.isEmpty ? name : "\(name).\(ext)"
        }
        
        let prefix = name.prefix(7)
        let suffix = name.suffix(4)
        
        let shortened = "\(prefix)…\(suffix)"
        
        return ext.isEmpty ? shortened : "\(shortened).\(ext)"
    }
}
enum FileStatus {
    case missing
    case notDownloaded
    case downloading
    case ready
}


// MARK: - Trash Helpers

extension TaskAttachment {
    
    @MainActor
    static func createDeletedAttachmentRecord(
        from attachment: TaskAttachment,
        in context: ModelContext
    ) {
        let item = DeletedItem(type: "attachment")
        
        item.taskID = attachment.task?.id
        item.fileName = attachment.originalName
        item.relativePath = attachment.relativePath
        item.trashFileName = nil // will be set AFTER move
        
        context.insert(item)
    }
}



extension TaskAttachment {
    
    static var previewMock: TaskAttachment {
        TaskAttachment(
            originalName: "preview.jpg",
            relativePath: "preview.jpg",
            contentType: "image/jpeg",
            task: nil
        )
    }
}
