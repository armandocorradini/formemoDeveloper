import SwiftUI

// MARK: - STYLE ENUM

enum TaskRowStyle: Int {
    case style0 = 0
    case style1 = 1
    case style2 = 2
    case style3 = 3
    case style4 = 4
    case style5 = 5
    case style6 = 6
    case style7 = 7
    case style8 = 8
    case style9 = 9
    case style10 = 10
}

// MARK: - MAIN ROW

struct TaskRowContent: View, Equatable, TaskRowBaseLogic {
    
    let model: TaskRowDisplayModel
    let iconStyle: TaskIconStyle
    
    let showBadge: Bool
    let showAttachments: Bool
    let showLocation: Bool
    let showPriority: Bool
    let showBadgeOnlyWithPriority: Bool
    
    let rowStyle: TaskRowStyle
    let showDateColumn: Bool

    let highlightCriticalOverdue: Bool
    let showTodayExpiredLabel: Bool
    let dueIconEffect: DueIconEffect
    @Environment(AppSettings.self) private var settings
    

    private var isToday: Bool {
        guard let d = model.deadLine else { return false }
        return Calendar.current.isDateInToday(d)
    }

    private var isOverdue: Bool {
        guard let d = model.deadLine else { return false }
        return d < Date()
    }

    private var futureYearText: String? {
        guard let deadline = model.deadLine else { return nil }

        let currentYear = Calendar.current.component(.year, from: Date())
        let deadlineYear = Calendar.current.component(.year, from: deadline)

        guard deadlineYear > currentYear else { return nil }

        return String(deadlineYear)
    }
    
    @ViewBuilder
    private func recurrenceAndYearIndicator() -> some View {
        if let futureYearText {
            HStack(spacing: 3) {
                Image(
                    systemName: model.recurrenceRule != nil
                        ? "arrow.triangle.2.circlepath"
                        : "calendar"
                )
                .font(.caption)
                .foregroundStyle(.blue)

                Text(futureYearText)
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundStyle(.secondary)
            }
        } else if model.recurrenceRule != nil {
            Image(systemName: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(.blue)
        }
    }

    @ViewBuilder
    private func todayExpiredLabel() -> some View {
        EmptyView()
    }

    var body: some View {
        content
            .frame(
                maxWidth: .infinity,
                minHeight: max(
                    1,
                    TaskRowMetrics.rowHeight + CGFloat(settings.taskRowVerticalPadding)
                ),
                alignment: .leading
            )
            .contentShape(Rectangle())
    }
}


extension TaskRowContent {

    static func == (
        lhs: TaskRowContent,
        rhs: TaskRowContent
    ) -> Bool {

        lhs.model == rhs.model &&
        lhs.iconStyle == rhs.iconStyle &&
        lhs.showBadge == rhs.showBadge &&
        lhs.showAttachments == rhs.showAttachments &&
        lhs.showLocation == rhs.showLocation &&
        lhs.showPriority == rhs.showPriority &&
        lhs.showBadgeOnlyWithPriority == rhs.showBadgeOnlyWithPriority &&
        lhs.rowStyle == rhs.rowStyle &&
        lhs.showDateColumn == rhs.showDateColumn &&
        lhs.highlightCriticalOverdue == rhs.highlightCriticalOverdue &&
        lhs.showTodayExpiredLabel == rhs.showTodayExpiredLabel &&
        lhs.dueIconEffect == rhs.dueIconEffect
    }
}

// MARK: - SWITCH

extension TaskRowContent {

    enum BadgeVisualStyle {
        case filled
        case soft
        case outlined
    }

    @ViewBuilder
    private func badgeView(text: String, color: Color, style: BadgeVisualStyle) -> some View {
        let isCircle = text.count <= 1

        switch style {
        case .filled:
            Text(text)
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(.white)
                .frame(width: isCircle ? 18 : nil, height: 18)
                .padding(.horizontal, isCircle ? 0 : 6)
                .background(
                    Group {
                        if isCircle {
                            Circle().fill(color)
                        } else {
                            Capsule().fill(color)
                        }
                    }
                )

        case .soft:
            Text(text)
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(color)
                .frame(width: isCircle ? 18 : nil, height: 18)
                .padding(.horizontal, isCircle ? 0 : 6)
                .background(
                    Group {
                        if isCircle {
                            Circle().fill(color.opacity(0.2))
                        } else {
                            Capsule().fill(color.opacity(0.2))
                        }
                    }
                )

        case .outlined:
            Text(text)
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(color)
                .frame(width: isCircle ? 18 : nil, height: 18)
                .padding(.horizontal, isCircle ? 0 : 6)
                .background(
                    Group {
                        if isCircle {
                            Circle().stroke(color, lineWidth: 1)
                        } else {
                            Capsule().stroke(color, lineWidth: 1)
                        }
                    }
                )
        }
    }
    
    @ViewBuilder
    var content: some View {
        switch rowStyle {
        case .style0: layoutStyle0()
        case .style1: layoutStyle1()
        case .style2: layoutStyle2()
        case .style3: layoutStyle3()
        case .style4: layoutStyle4()
        case .style5: layoutStyle5()
        case .style6: layoutStyle6()
        case .style7: layoutStyle7()
        case .style8: layoutStyle8()
        case .style9: layoutStyle9()
        case .style10: layoutStyle10()
        }
    }
    private func layoutStyle10() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            if let deadline = model.deadLine {
                VStack(spacing: 0) {
                    Text(deadline, format: .dateTime.weekday(.abbreviated))
                        .font(.system(size: 9, weight: .bold))
                        .textCase(.uppercase)
                        .foregroundStyle(.secondary)

                    Text(deadline, format: .dateTime.day())
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(isToday ? Color.orange : .primary)

                    Text(deadline, format: .dateTime.month(.abbreviated))
                        .font(.system(size: 10, weight: .semibold))
                        .textCase(.uppercase)
                        .foregroundStyle(.secondary)
                }
                .frame(width: TaskRowMetrics.dateColumnWidth)
                .opacity(showDateColumn ? 1 : 0)
            }

            Image(systemName: model.mainIcon)
                .font(.system(size: 20, weight: .medium))
                .foregroundStyle(model.mainTag?.color ?? model.statusColor)
                .frame(
                    width: TaskRowLayout.iconColumnWidth,
                    alignment: .center
                )

            VStack(alignment: .leading, spacing: 2) {

                HStack(alignment: .top, spacing: 5) {
                    Text(model.title)
                        .font(.headline)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if !model.isCompleted,
                               (model.deadLine ?? .distantFuture) < Date() {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .padding(.bottom, 4)
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)

                    if model.recurrenceRule != nil {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundStyle(.blue)
                    }
                }

                if let deadline = model.deadLine {
                    Text(deadline, format: .dateTime.hour().minute())
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer(minLength: 0)

            if model.shouldShowBadge,
               let badge = model.badgeText,
               let deadline = model.deadLine {

                TaskBadgeView(
                    deadline: deadline,
                    badgeText: badge,
                    statusColor: model.statusColor
                )
            }
        }
        .padding(.vertical, max(0, 6 + CGFloat(settings.taskRowVerticalPadding)))
    }
}

// MARK: - BASE COMPONENTS

extension TaskRowContent {
    
    var icon: some View {
        TaskIconContent(
            model: model,
            iconStyle: iconStyle,
            showAttachments: false,
            showLocation: false
        )
    }
    
    @ViewBuilder
    var flagsContent: some View {
        if showPriority, let image = model.prioritySystemImage {
            Image(systemName: image)
                .foregroundStyle(image == "flame" ? .red : .primary)
        }
        if showAttachments && model.hasValidAttachments {
            Image(systemName: "paperclip")
        }
        if showLocation && model.hasLocation {
            Image(systemName: "location.fill")

        }
    }
    
    func flags(vertical: Bool) -> some View {
        Group {
            if vertical {
                VStack(spacing: 6) { flagsContent }
            } else {
                HStack(spacing: 6) { flagsContent }
            }
        }
        .font(.system(size: 10))
        .foregroundStyle(.primary).opacity(0.7)
    }
    
    func timeColumn(style: Int) -> some View {
        Group {
            if let d = model.deadLine {
                VStack(spacing: style == 1 ? 1 : 0) {

                    if style == 1 || style == 7 || style == 9 {
                        Text(d, format: .dateTime.weekday(.abbreviated))
                            .font(.system(size: 10, weight: .semibold))
                            .textCase(.uppercase)
                            .opacity(showDateColumn ? 1 : 0)
                    }

                    if style == 6 {
                        Text(d, format: .dateTime.hour().minute())
                            .font(.system(size: 11, weight: .medium))
                    }

                    Text(d, format: .dateTime.day())
                        .font(
                            style == 1
                            ? .headline
                            : .system(size: 22, weight: .bold, design: .rounded)
                        )
                        .foregroundStyle(
                            isToday ? Color.orange : .primary
                        )
                        .opacity(showDateColumn ? 1 : 0)

                    Text(d, format: .dateTime.month(.abbreviated))
                        .font(.system(size: 11, weight: .bold))
                        .textCase(.uppercase)
                        .opacity(showDateColumn ? 1 : 0)

                    if style != 0 && style != 6 && style != 1 && style != 7 {
                        Text(d, format: .dateTime.hour().minute())
                            .font(
                                .system(
                                    size: 12,
                                    weight: .medium,
                                    design: .monospaced
                                )
                            )
                            .opacity(0.8)
                    }
                }
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    height: 44,
                    alignment: .center
                )
            } else {
                Image(systemName: "clock.badge.questionmark")
                    .font(.system(size: 26, weight: .light))
                    .foregroundStyle(.primary)
                    .opacity(showDateColumn ? 1 : 0)
            }
        }
    }
}

// MARK: - STYLES

extension TaskRowContent {
    
    private func layoutStyle9() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            timeColumn(style: 9)
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    alignment: .center
                )

            icon
                .scaleEffect(0.8)
                .frame(
                    width: TaskRowLayout.iconColumnWidth,
                    alignment: .center
                )

            VStack(alignment: .leading, spacing: 6) {
                todayExpiredLabel()
                HStack(spacing: 6) {
                    Text(model.title)
                        .font(.headline)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)
                 

                    if model.recurrenceRule != nil {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .font(.caption)
                            .foregroundStyle(.blue)
                    }
                }

                HStack(spacing: 6) {

//                    if let deadline = model.deadLine {
//                        Image(systemName: "clock")
//                            .foregroundStyle(.primary)
//                        Text(deadline, format: .dateTime.hour().minute())
//                            .foregroundStyle(.primary)
//                    }

                    if model.reminderOffsetMinutes != nil {
                        Image(systemName: "bell")
                        Text(formattedOffset(model: model))
                    }
                }
                .font(.caption2)
                .foregroundStyle(.primary).opacity(0.7)
            }

            Spacer()

            flags(vertical: true)
        }
    }
    
    private func layoutStyle1() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {
            
            timeColumn(style: 1)
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    alignment: .center
                )
            
            VStack(alignment: .leading, spacing: 1) {
                todayExpiredLabel()

                HStack(spacing: 6) {
                    Text(model.title)
                        .font(.headline)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)
                    
                    recurrenceAndYearIndicator()
                }

                HStack(spacing: 8) {
                    if model.reminderOffsetMinutes != nil {
                        Image(systemName: "bell")
                        Text(formattedOffset(model: model))
                    }

                    Spacer()

                    flags(vertical: false)
                }
                .font(.caption2)
                .foregroundStyle(.primary).opacity(0.7)
            }
            icon
                .scaleEffect(0.72)
                .frame(
                    width: TaskRowLayout.iconColumnWidth,
                    alignment: .center
                )
        }
    }
    
    private func layoutStyle2() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            timeColumn(style: 2)
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    alignment: .center
                )

            VStack(alignment: .leading, spacing: 1) {
                todayExpiredLabel()

                HStack(spacing: 6) {
                    Text(model.title)
                        .font(.headline)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)

                    recurrenceAndYearIndicator()
                }

                HStack(spacing: 8) {
                    if model.reminderOffsetMinutes != nil {
                        Image(systemName: "bell")
                        Text(formattedOffset(model: model))
                    }

                    Spacer()

                    flags(vertical: false)
                }
                .font(.caption2)
                .foregroundStyle(.primary).opacity(0.7)
            }
            icon
                .scaleEffect(0.85)
                .frame(
                    width: TaskRowLayout.iconColumnWidth,
                    alignment: .center
                )
        }
    }
    
    private func layoutStyle3() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            VStack(spacing: 4) {
                icon.scaleEffect(0.85)
                flags(vertical: false)
            }
            .frame(width: TaskRowLayout.iconColumnWidth)

            VStack(alignment: .leading, spacing: 6) {
                todayExpiredLabel()
                HStack(spacing: 6) {
                    Text(model.title)
                        .font(.headline)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)
                 

                    recurrenceAndYearIndicator()
                }

                if model.reminderOffsetMinutes != nil {
                    HStack {
                        Image(systemName: "bell")
                        Text(formattedOffset(model: model))
                    }
                    .font(.caption)
                }
            }

            Spacer()

            timeColumn(style: 3)
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    alignment: .center
                )
        }

    }
    
    private func layoutStyle4() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {
            
            icon
                .frame(
                    width: TaskRowLayout.iconColumnWidth,
                    alignment: .center
                )
            
            VStack(alignment: .leading, spacing: 6) {
                todayExpiredLabel()
                HStack(spacing: 6) {
                    Text(model.title)
                        .font(.headline)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .strikethrough(model.isCompleted)
                    
                    recurrenceAndYearIndicator()
                }

                
                if model.reminderOffsetMinutes != nil {
                    HStack {
                        Image(systemName: "bell")
                        Text(formattedOffset(model: model))
                    }
                    .font(.caption)
                }
            }
            Spacer()
            VStack {
                flags(vertical: false)
                timeColumn(style: 4)
                    .frame(
                        width: TaskRowMetrics.dateColumnWidth,
                        alignment: .center
                    )
            }
        }

    }
    
    private func layoutStyle5() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            timeColumn(style: 5)
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    alignment: .center
                )
            
            icon
                .frame(
                    width: TaskRowLayout.iconColumnWidth,
                    alignment: .center
                )
            
            VStack(alignment: .leading) {
                todayExpiredLabel()
                HStack(spacing: 6) {
                    Text(model.title)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .font(.headline)
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)
                    
                    recurrenceAndYearIndicator()
                }
                
                if let deadline = model.deadLine {
                    Text(deadline, format: .dateTime.weekday(.wide))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
            }
            
            Spacer()
            
            flags(vertical: true)
        }

    }
    
    private func layoutStyle6() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            timeColumn(style: 6)
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    alignment: .center
                )

            VStack(alignment: .leading) {

                todayExpiredLabel()

                if let d = model.deadLine {
                    Text(d, format: .dateTime.weekday(.wide))
                        .font(.caption)
                        .foregroundStyle(.primary)
                }

                HStack(spacing: 6) {
                    Text(model.title)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .font(.headline)
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)

                    if model.recurrenceRule != nil {
                        Image(systemName: "arrow.triangle.2.circlepath")
                            .font(.caption)
                            .foregroundStyle(.blue)
                    }
                }
            }

            Spacer()

            flags(vertical: true)
        }
    }
    
    private func layoutStyle7() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            timeColumn(style: 7)
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    alignment: .center
                )

            VStack(alignment: .leading) {

                todayExpiredLabel()

                if let d = model.deadLine {
                    Text(d, format: .dateTime.hour().minute())
                }

                HStack(spacing: 6) {
                    Text(model.title)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)

                    recurrenceAndYearIndicator()
                }
            }

            Spacer()

            flags(vertical: true)
        }
    }
    
    private func layoutStyle8() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            timeColumn(style: 8)
                .frame(
                    width: TaskRowMetrics.dateColumnWidth,
                    alignment: .center
                )

            VStack(alignment: .leading) {

                todayExpiredLabel()

                if let d = model.deadLine {
                    Text(d, format: .dateTime.weekday(.wide))
                }

                HStack(spacing: 6) {
                    Text(model.title)
                        .font(.headline)
                        .foregroundStyle(model.isCompleted ? .secondary : .primary)
                        .overlay(alignment: .bottomLeading) {
                            if showTodayExpiredLabel,
                               !model.isCompleted,
                               (
                                    (model.deadLine ?? .distantFuture) < Date()
                                    || model.title == String(localized: "Preview")
                               ) {

                                Rectangle()
                                    .fill(Color.red.opacity(0.75))
                                    .frame(height: 1)
                                    .offset(y: 2)
                            }
                        }
                        .strikethrough(model.isCompleted)
                        .lineLimit(2)

                    recurrenceAndYearIndicator()
                }
            }

            Spacer()

            flags(vertical: true)
        }
    }
    
    
    private func layoutStyle0() -> some View {
        HStack(spacing: TaskRowLayout.dateToContentSpacing) {

            // 📅 COLONNA DATA (sinistra)
            Group {
                if let d = model.deadLine {
                    VStack(spacing: 0) {
                        Text(d, format: .dateTime.weekday(.abbreviated))
                            .font(.system(size: 10, weight: .semibold))
                            .textCase(.uppercase)
                            .opacity(showDateColumn ? 1 : 0)

                        Text(d, format: .dateTime.day())
                            .font(.system(size: 22, weight: .bold, design: .rounded))
                            .foregroundStyle(
                                isToday ? Color.orange : .primary
                            )
                            .opacity(showDateColumn ? 1 : 0)

                        Text(d, format: .dateTime.month(.abbreviated))
                            .font(.system(size: 11, weight: .medium))
                            .textCase(.uppercase)
                            .opacity(showDateColumn ? 1 : 0)
                    }
                } else {
                    Image(systemName: "clock.badge.questionmark")
                        .font(.system(size: 24, weight: .regular))
                        .foregroundStyle(.primary)
                        .opacity(showDateColumn ? 1 : 0)
                }
            }
            .frame(
                width: TaskRowMetrics.dateColumnWidth,
                height: 44,
                alignment: .center
            )

            // 📌 CONTENUTO
            VStack(alignment: .leading, spacing: 6) {
                todayExpiredLabel()
                // 🏷️ TAG ICON + TITLE + BADGE
                HStack(alignment: .center, spacing: 8) {

                    // 🔷 ICONA TAG (stessa dimensione del titolo)
                    Image(systemName: model.mainIcon)
                        .font(.system(size: 18, weight: .semibold))
                        .symbolRenderingMode(
                            iconStyle == .polychrome && model.mainTag != nil ? .palette : .monochrome
                        )
                        .foregroundStyle(
                            iconStyle == .polychrome
                            ? (model.mainTag?.color ?? model.statusColor)
                            : .primary,
                            .primary
                        )
                        .opacity(0.9)
                        .dueIconEffect(
                            deadline: model.deadLine,
                            effect: dueIconEffect
                        )

                    HStack(spacing: 6) {
                        Text(model.title)
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(model.isCompleted ? .secondary : .primary)
                            .overlay(alignment: .bottomLeading) {
                               if showTodayExpiredLabel,
                                   !model.isCompleted,
                                   (
                                        (model.deadLine ?? .distantFuture) < Date()
                                        || model.title == String(localized: "Preview")
                                   ) {

                                    Rectangle()
                                        .fill(Color.red.opacity(0.75))
                                        .frame(height: 1)
                                        .offset(y: 2)
                                }
                            }
                            .strikethrough(model.isCompleted)
                            .tracking(-0.2)
                            .lineLimit(2)

                        recurrenceAndYearIndicator()
                    }

                    Spacer()

                    // 🔵 BADGE giorni – verticalmente allineato
                    Group {
                        if model.shouldShowBadge,
                           let badge = model.badgeText,
                           let deadline = model.deadLine {

                            TaskBadgeView(
                                deadline: deadline,
                                badgeText: badge,
                                statusColor: model.statusColor
                            )
                            .padding(.trailing, 2)
                            .padding(.top, 1)
                            .padding(.bottom, 3)

                        } else {

                            Color.clear
                                .frame(width: 24, height: 24)
                        }
                    }
                }

                // 🪶 META LINE (orario + remind + flags)
                HStack(spacing: 10) {

                    if let deadline = model.deadLine {
                        HStack(spacing: 4) {
                            Image(systemName: "clock")
                            Text(deadline, format: .dateTime.hour().minute())
                        }
                        .foregroundStyle(.primary)
                    }

                    if model.reminderOffsetMinutes != nil {
                        HStack(spacing: 4) {
                            Image(systemName: "bell")
                                .symbolRenderingMode(.hierarchical)
                            Text(formattedOffset(model: model))
                        }
                        .foregroundStyle(.primary).opacity(0.7)
                    }
                    Spacer()
                    flags(vertical: false)
                }
                .font(.system(size: 12, weight: .medium))
            }

            Spacer(minLength: 0)
        }
        .padding(.vertical, max(0, 6 + CGFloat(settings.taskRowVerticalPadding)))
    }
}
