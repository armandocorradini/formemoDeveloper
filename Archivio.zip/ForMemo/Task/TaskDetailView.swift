
import SwiftUI                // UI
import SwiftData             // @Query, @Bindable
import PhotosUI              // PhotosPicker
import UniformTypeIdentifiers // UTType
import CoreLocation          // CLLocationCoordinate2D
import os


enum RecurrenceUI: String, CaseIterable, Identifiable {
    
    case none
    case hourly
    case daily
    case weekly
    case monthly
    case yearly
    
    var id: String { rawValue }
    
    var title: String {
        switch self {
        case .none: return "None"
        case .hourly: return "Every hour"
        case .daily: return "Every day"
        case .weekly: return "Every week"
        case .monthly: return "Every month"
        case .yearly: return "Every year"
        }
    }
}

struct TaskDetailView: View {
    
    
    
    @Bindable var task: TodoTask
    
    @Environment(\.modelContext) private var modelContext
    @Environment(AppSettings.self) private var settings
    
    @Environment(\.dismiss) private var dismiss
    var isSheet: Bool = false
    
    private var taskAttachments: [TaskAttachment] {
        task.visibleTaskAttachments
    }
    
    @Environment(\.scenePhase) private var scenePhase
    
    @State private var cameraPhoto: PhotosPickerItem?
    
    @State private var showingFileImporter = false
    @State private var showingScanner = false
    @State private var showingShareOptions = false
    @State private var showingAttachmentPicker = false
    @State private var shareOnlySelectedAttachments = false
    @State private var shareItems: [Any] = []
    @State private var selectedAttachmentIDs: Set<UUID> = []
    
    @State private var showingDeleteConfirmation = false
    @State private var showingShareSheet = false
    @State private var showingAudioRecorder = false
    
    private var validationMessage: String? {
        guard let currentDeadline = task.deadLine,
              let offsetMinutes = task.reminderOffsetMinutes else {
            return nil
        }

        let reminderDate = currentDeadline.addingTimeInterval(-Double(offsetMinutes) * 60)

        if reminderDate < .now {
            return String(localized: "⚠️ This reminder is set in the past.")
        }

        guard settings.notificationLeadTimeDays != -1,
              !task.excludeGlobalNotification else {
            return nil
        }

        let globalNotificationOffsetMinutes = settings.notificationLeadTimeDays * 24 * 60
        guard offsetMinutes == globalNotificationOffsetMinutes else {
            return nil
        }

        return String(localized: "⚠️ This matches your global default notification.")
    }
    
    @State private var photoItems: [PhotosPickerItem] = []
    @State private var photoImportMessage: String?
    
    @State private var selectedPhotos: [PhotosPickerItem] = []
    @State private var showCameraPicker = false
    @State private var imageCache: [UUID: UIImage] = [:]
    @State private var recurringAttachmentScopeIDs: [UUID] = []
    @State private var showingRecurringAttachmentScope = false
    @State private var pendingRecurringAttachmentDeletion: TaskAttachment?
    @State private var showingRecurringAttachmentGlobalDelete = false
    
    @State private var saveTaskDebounce: Task<Void, Never>?
    
    // QuickLook
    struct PreviewItem: Identifiable {
        let id = UUID()
        let url: URL
    }
    
    @State private var previewItem: PreviewItem?
    
    @State private var showingDeleteDeadlineAlert = false
    @State private var showPhPicker = false
    
    @State private var showingLocationPicker = false
    @State private var selectedLocationName: String?
    @State private var selectedCoordinate: CLLocationCoordinate2D?
    
    
    
    @State private var cloudKitDebounceTask: Task<Void, Never>?
    
    @State private var refreshID = UUID()
    @State private var selectedRecurrence: RecurrenceUI = .none
    @State private var recurrenceLimitMode: RecurrenceLimitMode = .until
    @State private var recurrenceEndDate: Date = .now
    @State private var recurrenceCount: Int = 10
    
    // MARK: - Recurrence edit scope
    // True after the user has chosen how edits in this detail session
    // should be applied. The current occurrence is always already saved;
    // the choice determines whether future occurrences receive the same values.
    @State private var recurrenceEditScopeResolved = false
    @State private var showingRecurrenceEditScope = false
    @State private var hasFutureRecurrenceOccurrences = false
    @State private var isExitingDetail = false
    @State private var recurrenceGenerationConfirmation = false
    @State private var recurrenceGenerationRequestedCount = 0
    @State private var recurrenceGenerationCreateCount = 0
    @State private var recurrenceGenerationWasCapped = false
    @State private var pendingRecurrenceRegeneration = false
    
    @State private var isSynchronizing = false
    
    // MARK: - Legacy recurrence migration
    @State private var legacyRecurrenceTask: TodoTask?
    @State private var isMigratingLegacyRecurrence = false
    @State private var showingLegacyRecurrenceMigration = false
    
    private struct TaskEditSnapshot: Equatable {
        let title: String
        let taskDescription: String
        let deadLine: Date?
        let isCompleted: Bool
        let reminderOffsetMinutes: Int?
        let excludeGlobalNotification: Bool
        let alarmEnabled: Bool
        let locationName: String?
        let locationLatitude: Double?
        let locationLongitude: Double?
        let locationReminderEnabled: Bool
        let priorityRaw: Int
        let mainTagRaw: String?
        let recurrenceID: UUID?
        let occurrenceIndex: Int?
        let recurrenceRule: String?
        let recurrenceInterval: Int
        let recurrenceStartDate: Date?
        let recurrenceEndDate: Date?
        let recurrenceCount: Int?
        let attachmentIDs: [UUID]
        
        init(task: TodoTask) {
            self.title = task.title
            self.taskDescription = task.taskDescription
            self.deadLine = task.deadLine
            self.isCompleted = task.isCompleted
            self.reminderOffsetMinutes = task.reminderOffsetMinutes
            self.excludeGlobalNotification = task.excludeGlobalNotification
            self.alarmEnabled = task.alarmEnabled
            self.locationName = task.locationName
            self.locationLatitude = task.locationLatitude
            self.locationLongitude = task.locationLongitude
            self.locationReminderEnabled = task.locationReminderEnabled
            self.priorityRaw = task.priorityRaw
            self.mainTagRaw = task.mainTagRaw
            self.recurrenceID = task.recurrenceID
            self.occurrenceIndex = task.occurrenceIndex
            self.recurrenceRule = task.recurrenceRule
            self.recurrenceInterval = task.recurrenceInterval
            self.recurrenceStartDate = task.recurrenceStartDate
            self.recurrenceEndDate = task.recurrenceEndDate
            self.recurrenceCount = task.recurrenceCount
            self.attachmentIDs = (task.attachments ?? []).map(\.id).sorted { $0.uuidString < $1.uuidString }
        }

        func differsOnlyByCompletion(from other: TaskEditSnapshot) -> Bool {
            isCompleted != other.isCompleted &&
            title == other.title &&
            taskDescription == other.taskDescription &&
            deadLine == other.deadLine &&
            reminderOffsetMinutes == other.reminderOffsetMinutes &&
            excludeGlobalNotification == other.excludeGlobalNotification &&
            alarmEnabled == other.alarmEnabled &&
            locationName == other.locationName &&
            locationLatitude == other.locationLatitude &&
            locationLongitude == other.locationLongitude &&
            locationReminderEnabled == other.locationReminderEnabled &&
            priorityRaw == other.priorityRaw &&
            mainTagRaw == other.mainTagRaw &&
            recurrenceID == other.recurrenceID &&
            occurrenceIndex == other.occurrenceIndex &&
            recurrenceRule == other.recurrenceRule &&
            recurrenceInterval == other.recurrenceInterval &&
            recurrenceStartDate == other.recurrenceStartDate &&
            recurrenceEndDate == other.recurrenceEndDate &&
            recurrenceCount == other.recurrenceCount &&
            attachmentIDs == other.attachmentIDs
        }
    }
    
    @State private var initialEditSnapshot: TaskEditSnapshot?
    
    init(task: TodoTask, isSheet: Bool = false) {
        self._task = Bindable(wrappedValue: task)
        self.isSheet = isSheet
        
        let recurrence = RecurrenceUI(rawValue: task.recurrenceRule ?? "") ?? .none
        self._selectedRecurrence = State(initialValue: recurrence)
        
        if let count = task.recurrenceCount {
            self._recurrenceLimitMode = State(initialValue: .count)
            self._recurrenceCount = State(initialValue: min(max(count, 1), RecurrenceGenerationConfiguration.maximumOccurrencesPerOperation))
            self._recurrenceEndDate = State(initialValue: task.recurrenceEndDate ?? .now)
        } else {
            self._recurrenceLimitMode = State(initialValue: .until)
            self._recurrenceEndDate = State(initialValue: task.recurrenceEndDate ?? .now)
            self._recurrenceCount = State(initialValue: 10)
        }
    }
    
    private func recurrenceUnitTitle(
        for recurrence: RecurrenceUI,
        forcePlural: Bool = false
    ) -> String {
        let plural = forcePlural || task.recurrenceInterval > 1
        
        switch recurrence {
        case .hourly:
            return NSLocalizedString(plural ? "recurrence.hour.other" : "recurrence.hour.one", comment: "")
        case .daily:
            return NSLocalizedString(plural ? "recurrence.day.other" : "recurrence.day.one", comment: "")
        case .weekly:
            return NSLocalizedString(plural ? "recurrence.week.other" : "recurrence.week.one", comment: "")
        case .monthly:
            return NSLocalizedString(plural ? "recurrence.month.other" : "recurrence.month.one", comment: "")
        case .yearly:
            return NSLocalizedString(plural ? "recurrence.year.other" : "recurrence.year.one", comment: "")
        case .none:
            return NSLocalizedString("recurrence.none", comment: "")
        }
    }
    
    
    private var recurrenceCountPicker: some View {
        HStack {
            Text(String(localized: "Total Occurrences"))
            Spacer()
            AcceleratingStepper(
                selection: $recurrenceCount,
                range: 1...RecurrenceEngine.maximumGeneratedOccurrencesPerOperation
            )
        }
    }

    private var recurrenceSection: some View {
        Section {
            VStack(alignment: .leading, spacing: 14) {
                HStack(spacing: 10) {
                    Image(systemName: "arrow.triangle.2.circlepath")
                        .foregroundStyle(
                            task.occurrenceIndex == nil ? .red : .blue
                        )
                    
                    Text(String(localized: "Repeat"))
                    
                    Spacer()
                    
                    if selectedRecurrence == .none {
                        Menu {
                            ForEach(RecurrenceUI.allCases) { option in
                                Button {
                                    selectedRecurrence = option
                                } label: {
                                    Text(recurrenceUnitTitle(for: option, forcePlural: true))
                                }
                            }
                        } label: {
                            HStack(spacing: 4) {
                                Text(recurrenceUnitTitle(for: selectedRecurrence))
                                Image(systemName: "chevron.up.chevron.down")
                                    .font(.caption)
                            }
                            .foregroundStyle(.primary)
                            .contentShape(Rectangle())
                        }
                        .fixedSize(horizontal: true, vertical: false)
                    }
                }
                
                if selectedRecurrence != .none {
                    HStack(spacing: 12) {
                        Text(String(localized: "Every"))
                            .foregroundStyle(.primary)
                        
                        Menu {
                            ForEach(1...365, id: \.self) { value in
                                Button("\(value)") {
                                    task.recurrenceInterval = value
                                }
                            }
                        } label: {
                            HStack(spacing: 4) {
                                Text("\(task.recurrenceInterval)")
                                    .monospacedDigit()
                                Image(systemName: "chevron.up.chevron.down")
                                    .font(.caption)
                            }
                            .foregroundStyle(.primary)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                            .contentShape(Rectangle())
                        }
                        .tint(.primary)
                        
                        Menu {
                            Button {
                                selectedRecurrence = .none
                            } label: {
                                Text(recurrenceUnitTitle(for: .none))
                            }
                            
                            Divider()
                            
                            ForEach(RecurrenceUI.allCases.filter { $0 != .none }) { option in
                                Button {
                                    selectedRecurrence = option
                                } label: {
                                    Text(recurrenceUnitTitle(for: option, forcePlural: true))
                                }
                            }
                        } label: {
                            HStack(spacing: 4) {
                                Text(recurrenceUnitTitle(for: selectedRecurrence))
                                Image(systemName: "chevron.up.chevron.down")
                                    .font(.caption)
                            }
                            .foregroundStyle(.primary)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                            .contentShape(Rectangle())
                        }
                        .tint(.primary)
                        
                        Spacer()
                    }
                    
                    Divider()
                        .padding(.vertical, 4)
                    
                    VStack(alignment: .leading, spacing: 12) {
                        Text(String(localized: "Ends"))
                            .foregroundStyle(.primary)
                        
                        Picker("", selection: $recurrenceLimitMode) {
                            Text(String(localized: "Date"))
                                .tag(RecurrenceLimitMode.until)
                            Text(String(localized: "Occurrences"))
                                .tag(RecurrenceLimitMode.count)
                        }
                        .pickerStyle(.segmented)
                        .labelsHidden()
                        .frame(maxWidth: .infinity)
                        
                        if recurrenceLimitMode == .until {
                            DatePicker(
                                String(localized: "Until"),
                                selection: $recurrenceEndDate,
                                displayedComponents: [.date]
                            )
                            .frame(maxWidth: .infinity)
                        } else {
                            recurrenceCountPicker
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .onChange(of: selectedRecurrence) { _, newValue in
                if newValue == .none {
                    task.recurrenceRule = nil
                    task.recurrenceInterval = 1
                    task.recurrenceEndDate = nil
                    task.recurrenceCount = nil
                } else {
                    task.recurrenceRule = newValue.rawValue
                    if task.recurrenceInterval < 1 {
                        task.recurrenceInterval = 1
                    }
                }
            }
            .onChange(of: recurrenceLimitMode) { _, newValue in
                switch newValue {
                case .until:
                    task.recurrenceCount = nil
                    task.recurrenceEndDate = recurrenceEndDate
                case .count:
                    task.recurrenceEndDate = nil
                    task.recurrenceCount = min(max(recurrenceCount, 1), RecurrenceGenerationConfiguration.maximumOccurrencesPerOperation)
                }
            }
            .onChange(of: recurrenceEndDate) { _, newValue in
                guard selectedRecurrence != .none,
                      recurrenceLimitMode == .until else { return }
                task.recurrenceEndDate = newValue
                task.recurrenceCount = nil
            }
            .onChange(of: recurrenceCount) { _, newValue in
                guard selectedRecurrence != .none,
                      recurrenceLimitMode == .count else { return }
                let clamped = min(max(newValue, 1), RecurrenceGenerationConfiguration.maximumOccurrencesPerOperation)
                if clamped != newValue {
                    recurrenceCount = clamped
                }
                task.recurrenceCount = clamped
                task.recurrenceEndDate = nil
            }
        }
        .listRowBackground(
            Color(.systemBackground).opacity(0.3)
        )
    }
    
    private var rowModel: TaskRowDisplayModel {
        let icon = task.mainTag?.mainIcon ?? task.status.icon
        let color: Color = settings.iconStyle == .monochrome
        ? (task.mainTag?.color ?? task.status.color)
        : task.status.color
        
        return TaskRowDisplayModel(
            id: task.id,
            title: task.title,
            subtitle: task.taskDescription,
            mainIcon: icon,
            statusColor: color,
            hasValidAttachments: !taskAttachments.isEmpty,
            hasLocation: task.locationName != nil && task.locationName != "",
            badgeText: task.daysRemainingBadgeText,
            prioritySystemImage: task.priority.systemImage,
            deadLine: task.deadLine,
            reminderOffsetMinutes: task.reminderOffsetMinutes,
            shouldShowBadge: task.shouldShowDaysBadge(
                showBadge: settings.showBadge,
                showBadgeOnlyWithPriority: settings.showBadgeOnlyWithPriority
            ),
            isCompleted: task.isCompleted,
            recurrenceRule: task.recurrenceRule,
            isLegacyRecurrence: task.recurrenceRule != nil && task.occurrenceIndex == nil,
            mainTag: task.mainTag
        )
    }
    
    
    
    private var mainLayout: some View {
        ZStack {
            AppGlassBackground()
            
            List {
                MainInfoSection(
                    task: task,
                    rowModel: rowModel,
                    iconStyle: settings.iconStyle,
                    saveTask: { saveTask(userInitiated: true) },
                    saveRecurringCompletion: { saveCompletedRecurringOccurrence() },
                    dismiss: dismiss,
                    modelContext: modelContext
                )
                
                ScheduleSection(
                    task: task,
                    notificationLeadTimeDays: settings.notificationLeadTimeDays,
                    validationMessage: validationMessage,
                    showingDeleteDeadlineAlert: $showingDeleteDeadlineAlert,
                    saveTask: { saveTask(userInitiated: true) },
                    saveAndWaitForScheduling: {
                        await saveAndWaitForAlarmScheduling()
                    },
                    isSynchronizing: $isSynchronizing
                )
                
                if task.deadLine != nil {
                    recurrenceSection
                }
                
                ContextSection(
                    task: task,
                    navigationApp: settings.navigationApp,
                    showingDeleteConfirmation: $showingDeleteConfirmation,
                    showingLocationPicker: $showingLocationPicker,
                    saveTask: { saveTask(userInitiated: true) },
                    openNavigation: openNavigation
                )
                
                ResourcesSection(
                    task: task,
                    imageCache: $imageCache,
                    taskAttachments: taskAttachments,
                    onDelete: deleteAttachment,
                    onPreview: { previewItem = PreviewItem(url: $0) },
                    showCamera: { showCameraPicker = true },
                    showAudioRecorder: { showingAudioRecorder = true },
                    showFileImporter: { showingFileImporter = true },
                    showScanner: { showingScanner = true },
                    photoItems: $photoItems
                )
                
                metadataSection
            }
            
            .overlay {
                if isSynchronizing {
                    ZStack {
                        Color.black
                            .opacity(0.25)
                            .ignoresSafeArea()
                        
                        VStack(spacing: 16) {
                            ProgressView()
                                .controlSize(.large)
                            
                            Text("Do not close the app")
                                .font(.headline)
                            
                            Text("ForMemo is scheduling notifications and alarms.")
                                .font(.subheadline)
                                .multilineTextAlignment(.center)
                                .foregroundStyle(.secondary)
                        }
                        .padding(24)
                        .background(
                            .regularMaterial,
                            in: RoundedRectangle(cornerRadius: 18)
                        )
                        .padding()
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .contentShape(Rectangle())
                }
            }
            .contentMargins(.bottom, 70, for: .scrollContent)
            .scrollContentBackground(.hidden)
            .scrollEdgeEffectHidden(true, for: .top)
            .scrollDismissesKeyboard(.interactively)
        }
    }

    // MARK: - Body
    
    var body: some View {
        
        
        
        
        mainLayout
        .confirmationDialog(
            "Share Options:",
            isPresented: $showingShareOptions, titleVisibility: .visible
        ) {
            Button("Text only") {
                shareItems = buildShareItems(
                    includeText: true,
                    attachments: []
                )
            }
            
            Button("Full task") {
                shareItems = buildShareItems(
                    includeText: true,
                    attachments: taskAttachments
                )
            }
            
            Button("Text and selected attachments") {
                selectedAttachmentIDs.removeAll()
                showingAttachmentPicker = true
            }
            Button("Only Selected attachments") {
                shareOnlySelectedAttachments = true
                selectedAttachmentIDs.removeAll()
                showingAttachmentPicker = true
            }
            Button("All attachments") {
                shareItems = buildShareItems(
                    includeText: false,
                    attachments: taskAttachments
                )
            }
            
            Button("Cancel", role: .cancel) { }
        }
        .alert(
            "Apply attachment to future occurrences?",
            isPresented: $showingRecurringAttachmentScope
        ) {
            Button("This occurrence") {
                recurringAttachmentScopeIDs.removeAll()
                initialEditSnapshot = TaskEditSnapshot(task: task)
            }

            Button("This & Future") {
                let ids = recurringAttachmentScopeIDs
                recurringAttachmentScopeIDs.removeAll()

                for id in ids {
                    guard let attachment = taskAttachments.first(where: { $0.id == id }) else {
                        continue
                    }

                    do {
                        try RecurringAttachmentManager.configurePropagation(
                            for: [attachment],
                            from: task,
                            in: modelContext
                        )
                    } catch {
                        AppLogger.persistence.error(
                            "Recurring attachment propagation setup failed: \(error.localizedDescription)"
                        )
                    }
                }

                saveTask(userInitiated: true)
                initialEditSnapshot = TaskEditSnapshot(task: task)
            }
        } message: {
            Text("Choose whether the attachment should stay with this occurrence or also appear in future occurrences.")
        }
        .alert(
            "Delete attachment from all occurrences?",
            isPresented: $showingRecurringAttachmentGlobalDelete
        ) {
            Button("Delete", role: .destructive) {
                guard let attachment = pendingRecurringAttachmentDeletion else { return }

                // Complete every fallible SwiftData read before moving the physical
                // asset. A failed link fetch must leave the canonical file untouched.
                guard let linkData = RecurringAttachmentManager.encodedSnapshots(
                    for: attachment,
                    in: modelContext
                ) else {
                    AppLogger.persistence.error(
                        "Global attachment deletion stopped because link snapshots could not be read."
                    )
                    return
                }

                let linksToDelete: [RecurringAttachmentLink]
                do {
                    linksToDelete = try RecurringAttachmentManager.linksForDeletion(
                        of: attachment,
                        in: modelContext
                    )
                } catch {
                    AppLogger.persistence.error(
                        "Global attachment deletion stopped because recurrence links could not be fetched: \(error.localizedDescription)"
                    )
                    return
                }

                let ownerTaskID = attachment.task?.id ?? task.id
                let trashName: String?
                do {
                    trashName = try attachment.deleteFileIfNeeded()
                } catch {
                    AppLogger.persistence.error("Attachment deletion stopped because moving the file to Trash failed: \(error.localizedDescription)")
                    return
                }
                do {
                    try RecurringAttachmentManager.deleteLinks(
                        for: attachment,
                        in: modelContext,
                        preFetchedLinks: linksToDelete
                    )
                } catch {
                    modelContext.rollback()
                    if let trashName {
                        do {
                            try TaskAttachment.restoreFileFromTrash(
                                trashFileName: trashName,
                                relativePath: attachment.relativePath
                            )
                        } catch {
                            AppLogger.persistence.fault(
                                "Failed to restore attachment after recurrence-link deletion failed: \(error.localizedDescription)"
                            )
                        }
                    }
                    AppLogger.persistence.error(
                        "Recurring attachment link cleanup failed: \(error.localizedDescription)"
                    )
                    return
                }

                let item = DeletedItem(type: "attachment")
                item.taskID = ownerTaskID
                item.fileName = attachment.originalName
                item.relativePath = attachment.relativePath
                item.trashFileName = trashName
                item.recurringAttachmentLinksData = linkData
                modelContext.insert(item)

                task.attachments?.removeAll { $0.id == attachment.id }
                attachment.task?.attachments?.removeAll {
                    $0.id == attachment.id
                }
                attachment.task = nil

                modelContext.delete(attachment)
                modelContext.processPendingChanges()

                guard commitAttachmentDeletion() else {
                    if let trashName {
                        do {
                            try TaskAttachment.restoreFileFromTrash(
                                trashFileName: trashName,
                                relativePath: attachment.relativePath
                            )
                        } catch {
                            AppLogger.persistence.fault(
                                "Failed to restore attachment after global deletion rollback: \(error.localizedDescription)"
                            )
                        }
                    }
                    return
                }

                // The cloud mirror is deliberately removed only after SwiftData
                // confirms the deletion. A mirror-cleanup failure is non-destructive:
                // the committed Recently Deleted item and its local Trash copy remain.
                do {
                    _ = try TaskAttachment.deleteCloudMirrorVerified(
                        relativePath: attachment.relativePath
                    )
                } catch {
                    AppLogger.persistence.error(
                        "Committed attachment deletion but cloud mirror cleanup failed: \(error.localizedDescription)"
                    )
                }

                initialEditSnapshot = TaskEditSnapshot(task: task)

                NotificationCenter.default.post(
                    name: .attachmentsShouldRefresh,
                    object: nil
                )
                pendingRecurringAttachmentDeletion = nil
            }

            Button("Cancel", role: .cancel) {
                pendingRecurringAttachmentDeletion = nil
            }
        } message: {
            Text("This attachment is shared with this recurrence. If you delete it, it will be removed from all past, current, and future occurrences and moved to Recently Deleted.")
        }
        .confirmationDialog(
            "Apply changes to",
            isPresented: $showingRecurrenceEditScope,
            titleVisibility: .visible
        ) {
            Button("This") {
                recurrenceEditScopeResolved = true
                showingRecurrenceEditScope = false
                finishDetailExit()
            }
            
            Button("This & Future") {
                recurrenceEditScopeResolved = true
                showingRecurrenceEditScope = false
                isSynchronizing = true

                Task { @MainActor in
                    await applyCurrentChangesToFutureOccurrences()
                    isSynchronizing = false
                }
            }
            
            Button("Cancel", role: .cancel) {
                // Stay in the detail view. No future occurrence is changed.
                showingRecurrenceEditScope = false
            }
        } message: {
            Text("Choose whether the changes apply only to this occurrence or also to future occurrences.")
        }
        .navigationTitle("Details")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .padding(.top, -15)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button {
                    requestDetailExit()
                } label: {
                    Image(systemName: "chevron.left")
                }
            }
            
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    showingShareSheet = true
                } label: {
                    Label("Share", systemImage: "square.and.arrow.up")
                }
            }
        }
        .sheet(isPresented: $showCameraPicker) {
            CameraPicker(allowsEditing: true) { image in
                Task { @MainActor in
                    await importCameraImage(image)
                }
            }
        }
        .sheet(isPresented: $showingAudioRecorder) {
            AudioRecorderView { url in
                Task { @MainActor in await saveAttachment(from: url)}
            }
        }
        .sheet(isPresented: $showingShareSheet) {
            ShareSheet(
                task: task,
                attachments: taskAttachments,
                onShare: { items in
                    showingShareSheet = false
                    shareItems = items
                },
                onCancel: { showingShareSheet = false }
            )
        }
        .sheet(isPresented: $showingAttachmentPicker) {
            NavigationStack {
                List(taskAttachments, selection: $selectedAttachmentIDs) { att in
                    Text(att.originalName)
                }
                .navigationTitle("Select attachments")
                .toolbar {
                    ToolbarItem(placement: .confirmationAction) { Button("Share") {
                        let selected = taskAttachments.filter {
                            selectedAttachmentIDs.contains($0.id)
                        }
                        
                        if shareOnlySelectedAttachments {
                            shareItems = buildShareItems(
                                includeText: false,
                                attachments: selected
                            )
                        } else {
                            // share text + selected attachments
                            shareItems = buildShareItems(
                                includeText: true,
                                attachments: selected
                            )
                        }
                        
                        shareOnlySelectedAttachments = false
                        showingAttachmentPicker = false
                    }
                    .disabled(selectedAttachmentIDs.isEmpty)
                    }
                    
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Cancel") {
                            showingAttachmentPicker = false
                        }
                    }
                }
                .environment(\.editMode, .constant(.active))
            }
        }
        .sheet(isPresented: .init(
            get: { !shareItems.isEmpty },
            set: { if !$0 { shareItems = [] } }
        )) {
            ActivityView(items: shareItems)
        }
        .sheet(isPresented: $showingScanner) {
            DocumentScannerView { images in
                Task { @MainActor in
                    await importScans(from: images)
                }
            }
        }
        .sheet(item: $previewItem) { item in
            
            if FileManager.default.fileExists(atPath: item.url.path) {
                
                QuickLookPreview(url: item.url)
                
            } else {
                
                ContentUnavailableView(
                    "File unavailable",
                    systemImage: "icloud.slash"
                )
            }
        }
        .sheet(isPresented: $showingLocationPicker) {
            LocationPickerView { name, coordinate in
                task.locationName = name
                task.locationLatitude = coordinate.latitude
                task.locationLongitude = coordinate.longitude
                
                saveTask(userInitiated: true)
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: .attachmentsShouldRefresh)) { _ in
            debounceCloudKitUpdate()
        }
        .onChange(of: task.title) { _, _ in
            scheduleDebouncedSave()
        }
        .onChange(of: settings.notificationLeadTimeDays) { _, _ in
            NotificationManager.shared.refresh()
        }
        .onChange(of: task.taskDescription) { _, _ in
            scheduleDebouncedSave()
        }
        .fileImporter(
            isPresented: $showingFileImporter,
            allowedContentTypes: [.item],
            allowsMultipleSelection: true
        ) { result in
            guard case .success(let urls) = result else { return }
            Task { @MainActor in await importFiles(from: urls)}
        }
        .sheet(isPresented: $showingLegacyRecurrenceMigration) {
            
            if let task = legacyRecurrenceTask {
                
                RecurrenceMigrationView(
                    task: task,
                    onMigrate: { task, futureCount, endDate, keepCurrentOccurrenceActive in
                        migrateLegacyRecurrence(
                            task,
                            futureCount: futureCount,
                            endDate: endDate,
                            keepCurrentOccurrenceActive: keepCurrentOccurrenceActive
                        )
                    },
                    onDeleteRecurrence: { task in
                        deleteLegacyRecurrence(task)
                    }
                )
            }
        }
        
        .alert(
            initialEditSnapshot?.recurrenceID == nil
            ? "Create future occurrences?"
            : "Modify future occurrences?",
            isPresented: $recurrenceGenerationConfirmation
        ) {
            Button("OK") {
                performConfirmedRecurrenceRegeneration()
            }
            Button("Cancel", role: .cancel) {
                cancelPendingRecurrenceRegeneration()
            }
        } message: {
            if initialEditSnapshot?.recurrenceID == nil {
                if recurrenceGenerationWasCapped {
                    Text(
                        "The new recurrence requires \(recurrenceGenerationRequestedCount) future occurrences. The first \(recurrenceGenerationCreateCount) occurrences will be created, up to the maximum limit of \(RecurrenceGenerationConfiguration.maximumOccurrencesPerOperation)."
                    )
                } else {
                    Text(
                        "The new recurrence will create \(recurrenceGenerationCreateCount) future occurrences according to the selected recurrence."
                    )
                }
            } else if recurrenceGenerationWasCapped {
                Text(
                    "The new recurrence requires \(recurrenceGenerationRequestedCount) future occurrences. The currently scheduled future occurrences will be deleted and replaced with the first \(recurrenceGenerationCreateCount) occurrences, up to the maximum limit of \(RecurrenceGenerationConfiguration.maximumOccurrencesPerOperation)."
                )
            } else {
                Text(
                    "The currently scheduled future occurrences will be deleted and replaced with \(recurrenceGenerationCreateCount) new future occurrences according to the new recurrence."
                )
            }
        }        .alert("Remove deadline?", isPresented: $showingDeleteDeadlineAlert) {
            Button("Remove", role: .destructive) {
                task.deadLine = nil
                task.reminderOffsetMinutes = nil   // ✅ fondamentale
                
                saveTask(userInitiated: true)
            }
            Button("Cancel", role: .cancel) { }
        } message: {
            Text("The set date will be permanently removed.")
        }
        .alert(
            "Photo import incomplete",
            isPresented: Binding(
                get: { photoImportMessage != nil },
                set: { if !$0 { photoImportMessage = nil } }
            )
        ) {
            Button("OK", role: .cancel) {
                photoImportMessage = nil
            }
        } message: {
            Text(photoImportMessage ?? "")
        }
        .onAppear {
            recurrenceEditScopeResolved = false
            showingRecurrenceEditScope = false
            hasFutureRecurrenceOccurrences = false
            isExitingDetail = false
            initialEditSnapshot = TaskEditSnapshot(task: task)
            onAppearAction()
        }
        .onChange(of: photoItems) { _, newItems in
            guard !newItems.isEmpty else { return }
            Task {
                await importPhotos(from: newItems)
            }
        }
        //        .onChange(of: task.reminderOffsetMinutes, initial: false) { _, _ in
        //            saveTask()
        //        }
        //        .onChange(of: task.locationName) { _, _ in
        //            saveTask()
        //        }
        //        .onChange(of: task.locationLatitude) { _, _ in
        //            saveTask()
        //        }
        //        .onChange(of: task.locationLongitude) { _, _ in
        //            saveTask()
        //        }
        .onChange(of: task.isCompleted) { _, newValue in
            handleCompletionChange(newValue)
        }
        .onDisappear {
            saveTaskDebounce?.cancel()
            saveTask(userInitiated: false)
        }
    }
    @MainActor
    private func handleCompletionChange(_ newValue: Bool) {
        let isLegacyRecurrence = task.recurrenceRule != nil
            && task.occurrenceIndex == nil
        let shouldPresentLegacyMigration = newValue
            && isLegacyRecurrence
            && !isMigratingLegacyRecurrence

        guard shouldPresentLegacyMigration else {
            saveTask(userInitiated: true)
            return
        }

        // Do not complete the legacy task before the migration choice.
        task.isCompleted = false
        task.completedAt = nil
        task.snoozeUntil = nil

        legacyRecurrenceTask = task
        showingLegacyRecurrenceMigration = true
    }

    @MainActor
    private func saveCompletedRecurringOccurrence() {
        guard saveTask(userInitiated: true) != nil else {
            return
        }

        RecurrenceCompletionNotice.postIfNeeded(
            for: task,
            wasCompleted: false
        )
    }

    @discardableResult
    @MainActor
    private func saveTask(userInitiated: Bool = false) -> Task<Void, Never>? {
        guard modelContext.hasChanges else { return nil }
        
        var synchronizationTask: Task<Void, Never>?
        
        do {
            try modelContext.save()
            
//            if let recurrenceID = task.recurrenceID {
//                synchronizationTask = Task { @MainActor in
//                    _ = await ForMemoAlarmManager.shared.synchronize(task: task,
//                                                                     in: modelContext)
//                    
//                    let occurrences = (try? modelContext.fetch(
//                        FetchDescriptor<TodoTask>(
//                            predicate: #Predicate<TodoTask> {
//                                $0.recurrenceID == recurrenceID
//                            }
//                        )
//                    )) ?? []
//                    
//                    _ = await ForMemoAlarmManager.shared.synchronize(tasks: occurrences,
//                                                                     in: modelContext)
//                }
//            } else {
//                synchronizationTask = Task { @MainActor in
//                    _ = await ForMemoAlarmManager.shared.synchronize(task: task,
//                                                                     in: modelContext)
//                }
//            }
            
            
            synchronizationTask = Task { @MainActor in
                _ = await ForMemoAlarmManager.shared.synchronize(
                    task: task,
                    in: modelContext
                )
            }
            

            DebugLog.writeCloudKitEvent(
                "TaskDetail context save completed"
            )
            
            NotificationManager.shared.refresh()
#if DEBUG
            AppLogger.notifications.info("💾 Saved")
#endif
        } catch {
            DebugLog.writeCloudKitEvent(
                "TaskDetail context save failed"
            )
            AppLogger.persistence.fault(
                "Task detail save failed: \(error.localizedDescription)"
            )
            
            modelContext.rollback()
            assertionFailure("CRITICAL: TaskDetailView.saveTask failed → rollback executed")
        }
    
    return synchronizationTask
}
    
    /// Commits attachment deletion without using saveTask's optional alarm-task
    /// return value as a success signal. On failure, the caller restores the
    /// staged physical file after this method rolls SwiftData back.
    @MainActor
    private func commitAttachmentDeletion() -> Bool {
        do {
            try modelContext.save()

            Task { @MainActor in
                _ = await ForMemoAlarmManager.shared.synchronize(
                    task: task,
                    in: modelContext
                )
            }

            DebugLog.writeCloudKitEvent(
                "TaskDetail attachment deletion commit completed"
            )
            NotificationManager.shared.refresh()
#if DEBUG
            AppLogger.notifications.info("Attachment deletion committed")
#endif
            return true
        } catch {
            DebugLog.writeCloudKitEvent(
                "TaskDetail attachment deletion commit failed"
            )
            AppLogger.persistence.fault(
                "Task detail attachment deletion commit failed: \(error.localizedDescription)"
            )
            modelContext.rollback()
            return false
        }
    }

    @MainActor
    private func saveAndWaitForAlarmScheduling() async {
        guard modelContext.hasChanges else { return }

        do {
            try modelContext.save()

            let alarmScheduled = await ForMemoAlarmManager.shared.synchronize(
                task: task,
                in: modelContext
            )

            if !alarmScheduled && task.alarmEnabled {
                // Do not leave the task marked as AlarmKit-enabled when no
                // alarm was actually scheduled. Persisting OFF makes the
                // existing notification calculator create a normal deadline
                // notification instead of a silent alarmBadge request.
                task.alarmEnabled = false

                do {
                    try modelContext.save()
                    AppLogger.notifications.error(
                        "AlarmKit scheduling failed; alarm preference disabled and deadline notification fallback enabled for task \(task.id.uuidString)."
                    )
                } catch {
                    // Keep the in-memory fallback active for this rebuild.
                    // The persistence failure is logged explicitly because it
                    // can otherwise restore the unsafe state on next launch.
                    AppLogger.persistence.fault(
                        "CRITICAL: AlarmKit fallback preference could not be persisted for task \(task.id.uuidString): \(error.localizedDescription)"
                    )
                }
            }

            await NotificationManager.shared.refreshAndWait(force: true)

            DebugLog.writeCloudKitEvent(
                "TaskDetail alarm toggle save completed"
            )

    #if DEBUG
            AppLogger.notifications.info("💾 Alarm toggle saved")
    #endif

        } catch {
            DebugLog.writeCloudKitEvent(
                "TaskDetail alarm toggle save failed"
            )

            AppLogger.persistence.fault(
                "Task detail alarm toggle save failed: \(error.localizedDescription)"
            )

            modelContext.rollback()

            assertionFailure(
                "CRITICAL: TaskDetailView.saveAndWaitForAlarmScheduling failed → rollback executed"
            )
        }
    }
    
    
    
    
    // MARK: - Detail exit / recurrence edit scope

    @MainActor
    private func requestDetailExit() {
        guard !isExitingDetail else { return }

        let hasActualChanges =
            initialEditSnapshot != nil &&
            initialEditSnapshot != TaskEditSnapshot(task: task)

        guard hasActualChanges else {
            finishDetailExit()
            return
        }
        
        // Changing only the completion state is an operation on this occurrence,
        // not an edit to the recurrence series. Save it without the scope dialog.
        if let initialEditSnapshot,
           initialEditSnapshot.differsOnlyByCompletion(from: TaskEditSnapshot(task: task)) {
            finishDetailExit()
            return
        }

        // A change to any recurrence definition has its own flow.
        if recurrenceDefinitionChanged() {
            prepareRecurrenceDefinitionChange()
            return
        }

        // A completed occurrence is historical data. Ordinary edits apply only
        // to this occurrence and must not prompt to propagate values forward.
        // Its recurrence identity remains unchanged, so it can be reactivated
        // later without becoming a standalone task.
        if task.isCompleted {
            finishDetailExit()
            return
        }

        // Legacy recurrence: edits are saved normally.
        // Migration is triggered only when the user completes the task.
        if task.recurrenceRule != nil && task.occurrenceIndex == nil {
            finishDetailExit()
            return
        }

        // Non-recurrence edits retain the existing This / This & Future flow.
        saveTask(userInitiated: false)

        guard let recurrenceID = task.recurrenceID,
              task.recurrenceRule != nil else {
            finishDetailExit()
            return
        }

        let currentIndex = task.occurrenceIndex ?? 1

        do {
            let occurrences = try modelContext.fetch(
                FetchDescriptor<TodoTask>(
                    predicate: #Predicate<TodoTask> { candidate in
                        candidate.recurrenceID == recurrenceID
                    }
                )
            )

            let hasFuture = occurrences.contains { occurrence in
                occurrence.id != task.id &&
                (occurrence.occurrenceIndex ?? 1) > currentIndex
            }

            guard hasFuture else {
                // Last occurrence: behave exactly like a single task.
                finishDetailExit()
                return
            }

            hasFutureRecurrenceOccurrences = true
            recurrenceEditScopeResolved = false
            showingRecurrenceEditScope = true

        } catch {
            AppLogger.persistence.error(
                "TaskDetail recurrence edit scope check failed: \(error.localizedDescription)"
            )
        }
    }

    @MainActor
    private func prepareRecurrenceDefinitionChange() {
        guard let initial = initialEditSnapshot else {
            finishDetailExit()
            return
        }

        // If this task already belonged to a recurrence series, the
        // confirmation is needed only when there are future occurrences.
        //
        // If the task was previously single and the user is now creating a
        // recurrence, the new recurrence itself creates future occurrences,
        // so the confirmation is still required.
        if initial.recurrenceID != nil {
            let oldRecurrenceID = initial.recurrenceID!
            let currentIndex = initial.occurrenceIndex ?? 1

            do {
                let occurrences = try modelContext.fetch(
                    FetchDescriptor<TodoTask>(
                        predicate: #Predicate<TodoTask> { candidate in
                            candidate.recurrenceID == oldRecurrenceID
                        }
                    )
                )

                let hasFuture = occurrences.contains { occurrence in
                    occurrence.id != task.id &&
                    (occurrence.occurrenceIndex ?? 1) > currentIndex
                }

                // This is the last occurrence: treat the edit as a normal
                // single-task edit. Do not show the recurrence alert.
                guard hasFuture else {
                    finishDetailExit()
                    return
                }
            } catch {
                AppLogger.persistence.error(
                    "TaskDetail future recurrence check failed: \(error.localizedDescription)"
                )
                return
            }
        }

        // A single task becoming recurring has no existing future
        // occurrences to check; the new recurrence will create them.
        //
        // If an existing recurring task is being changed to "None", we
        // already verified above that future occurrences exist, so the
        // confirmation must still be shown.
        if initial.recurrenceID == nil {
            guard task.recurrenceRule != nil else {
                finishDetailExit()
                return
            }
        }

        let preview = calculateFutureRecurrencePlan()
        recurrenceGenerationRequestedCount = preview.requestedCount
        recurrenceGenerationCreateCount = preview.createCount
        recurrenceGenerationWasCapped = preview.wasCapped
        pendingRecurrenceRegeneration = true

        // Use the shared threshold for every recurrence-generation flow.
        // Existing series with future occurrences still require confirmation,
        // including when the new definition removes recurrence or generates none.
        if preview.createCount > RecurrenceGenerationConfiguration.confirmationThreshold
            || initial.recurrenceID != nil {
            recurrenceGenerationConfirmation = true
        } else {
            performConfirmedRecurrenceRegeneration()
        }
    }

    @MainActor
    private func cancelPendingRecurrenceRegeneration() {
        pendingRecurrenceRegeneration = false
        recurrenceGenerationConfirmation = false

        // The recurrence controls edit the bound task immediately. Restore only
        // the recurrence definition; unrelated edits made in the same session
        // remain intact and can still be saved normally.
        guard let initial = initialEditSnapshot else { return }

        task.recurrenceID = initial.recurrenceID
        task.occurrenceIndex = initial.occurrenceIndex
        task.recurrenceRule = initial.recurrenceRule
        task.recurrenceInterval = initial.recurrenceInterval
        task.recurrenceStartDate = initial.recurrenceStartDate
        task.recurrenceEndDate = initial.recurrenceEndDate
        task.recurrenceCount = initial.recurrenceCount

        selectedRecurrence = RecurrenceUI(rawValue: initial.recurrenceRule ?? "") ?? .none
        if let count = initial.recurrenceCount {
            recurrenceLimitMode = .count
            recurrenceCount = min(max(count, 1), RecurrenceGenerationConfiguration.maximumOccurrencesPerOperation)
        } else {
            recurrenceLimitMode = .until
            recurrenceEndDate = initial.recurrenceEndDate ?? .now
        }
    }

    @MainActor
    private func migrateLegacyRecurrence(
        _ task: TodoTask,
        futureCount: Int?,
        endDate: Date?,
        keepCurrentOccurrenceActive: Bool
    ) {
        isMigratingLegacyRecurrence = true

        do {
            let createdOccurrences = try RecurrenceEngine.migrateLegacyRecurrence(
                for: task,
                futureCount: futureCount,
                endDate: endDate,keepCurrentOccurrenceActive: keepCurrentOccurrenceActive,
                in: modelContext
            )

            try modelContext.save()
            modelContext.processPendingChanges()

            NotificationCenter.default.post(
                name: .taskDidChange,
                object: nil
            )

            // The migration bypasses saveTask(), so synchronize AlarmKit for
            // the original task and every new occurrence. Then force and await
            // the global notification rebuild so Global events are not lost
            // when a non-forced refresh is throttled or already pending.
            Task { @MainActor in
                _ = await ForMemoAlarmManager.shared.synchronize(
                    tasks: [task] + createdOccurrences,
                    in: modelContext
                )

                await NotificationManager.shared.refreshAndWait(force: true)

                legacyRecurrenceTask = nil
                isMigratingLegacyRecurrence = false
                showingLegacyRecurrenceMigration = false
                dismiss()
            }

        } catch {
            isMigratingLegacyRecurrence = false

            AppLogger.persistence.error(
                "TaskDetail legacy recurrence migration failed: \(error.localizedDescription)"
            )
        }
    }

    @MainActor
    private func deleteLegacyRecurrence(_ task: TodoTask) {
        isMigratingLegacyRecurrence = true

        task.isCompleted = true
        task.completedAt = .now
        task.snoozeUntil = nil

        task.recurrenceRule = nil
        task.recurrenceInterval = 1
        task.recurrenceID = nil
        task.occurrenceIndex = nil
        task.recurrenceStartDate = nil
        task.recurrenceEndDate = nil
        task.recurrenceCount = nil

        do {
            try modelContext.save()
            modelContext.processPendingChanges()

            NotificationCenter.default.post(
                name: .taskDidChange,
                object: nil
            )

            Task { @MainActor in
                _ = await ForMemoAlarmManager.shared.synchronize(
                    task: task,
                    in: modelContext
                )

                await NotificationManager.shared.refreshAndWait(force: true)

                legacyRecurrenceTask = nil
                isMigratingLegacyRecurrence = false
                dismiss()
            }

        } catch {
            isMigratingLegacyRecurrence = false

            AppLogger.persistence.error(
                "TaskDetail legacy recurrence removal failed: \(error.localizedDescription)"
            )
        }
    }
    
    
    @MainActor
    private func finishDetailExit() {
        guard !isExitingDetail else { return }

        let completionStateChanged = initialEditSnapshot?.isCompleted != task.isCompleted
        isExitingDetail = true
        saveTask(userInitiated: false)

        if completionStateChanged {
            modelContext.processPendingChanges()
            NotificationCenter.default.post(name: .taskDidChange, object: nil)
        }

        initialEditSnapshot = TaskEditSnapshot(task: task)
        recurrenceEditScopeResolved = true
        hasFutureRecurrenceOccurrences = false

        dismiss()
    }

    @MainActor
    private func applyCurrentChangesToFutureOccurrences() async {
        // This method is used for the normal "This & Future" path.
        // Non-recurrence properties are copied directly.
        // If the deadline changed, future deadlines are recalculated
        // from the new deadline of the current occurrence.

        guard let oldRecurrenceID = task.recurrenceID else {
            finishDetailExit()
            return
        }

        let currentIndex = task.occurrenceIndex ?? 1

        do {
            let occurrences = try modelContext.fetch(
                FetchDescriptor<TodoTask>(
                    predicate: #Predicate<TodoTask> { candidate in
                        candidate.recurrenceID == oldRecurrenceID
                    }
                )
            )

            let futureOccurrences = occurrences
                .filter {
                    $0.id != task.id &&
                    ($0.occurrenceIndex ?? 1) > currentIndex
                }
                .sorted {
                    ($0.occurrenceIndex ?? 1) < ($1.occurrenceIndex ?? 1)
                }

            // Copy the non-date properties first.
            for occurrence in futureOccurrences {
                copyFutureTaskProperties(
                    from: task,
                    to: occurrence
                )
            }

            // If the current task has a deadline and a valid recurrence rule,
            // rebuild the future dates from the NEW current deadline.
            if let newDeadline = task.deadLine,
               let ruleRaw = task.recurrenceRule,
               let rule = RecurrenceEngine.Rule(rawValue: ruleRaw),
               !futureOccurrences.isEmpty {

                let maximumOffset = futureOccurrences.reduce(0) { maximum, occurrence in
                    let occurrenceIndex = occurrence.occurrenceIndex ?? currentIndex
                    return max(
                        maximum,
                        occurrenceIndex - currentIndex
                    )
                }

                let generatedDates = RecurrenceEngine.occurrenceDates(
                    startDate: newDeadline,
                    rule: rule,
                    interval: max(1, task.recurrenceInterval),
                    limit: .count(maximumOffset + 1)
                )

                for occurrence in futureOccurrences {
                    guard let occurrenceIndex = occurrence.occurrenceIndex else {
                        continue
                    }

                    let offset = occurrenceIndex - currentIndex

                    guard offset > 0,
                          offset < generatedDates.count else {
                        continue
                    }

                    occurrence.deadLine = generatedDates[offset]
                }
            }

            try modelContext.save()
            modelContext.processPendingChanges()

            _ = await ForMemoAlarmManager.shared.synchronize(
                tasks: futureOccurrences,
                in: modelContext
            )

            NotificationCenter.default.post(
                name: .taskDidChange,
                object: nil
            )

            await NotificationManager.shared.refreshAndWait(force: true)
            finishDetailExit()

        } catch {
            AppLogger.persistence.error(
                "TaskDetail future recurrence update failed: \(error.localizedDescription)"
            )
        }
    }

    private struct FutureRecurrencePlan {
        let requestedCount: Int
        let createCount: Int
        let wasCapped: Bool
    }

    @MainActor
    private func calculateFutureRecurrencePlan() -> FutureRecurrencePlan {
        guard let ruleRaw = task.recurrenceRule,
              let rule = RecurrenceEngine.Rule(rawValue: ruleRaw),
              let startDate = task.deadLine ?? task.recurrenceStartDate else {
            return FutureRecurrencePlan(
                requestedCount: 0,
                createCount: 0,
                wasCapped: false
            )
        }

        let limit: RecurrenceEngine.Limit

        if let count = task.recurrenceCount {
            let currentIndex = task.occurrenceIndex ?? 1
            let remainingOccurrences = max(1, count - currentIndex + 1)

            limit = .count(
                remainingOccurrences
            )
        } else if let endDate = task.recurrenceEndDate {
            limit = .until(endDate)
        } else {
            limit = .unlimited
        }

        let dates = RecurrenceEngine.occurrenceDates(
            startDate: startDate,
            rule: rule,
            interval: max(1, task.recurrenceInterval),
            limit: limit
        )

        let futureCount = max(0, dates.count - 1)

        return FutureRecurrencePlan(
            requestedCount: futureCount,
            createCount: min(
                futureCount,
                RecurrenceEngine.maximumGeneratedFutureOccurrences
            ),
            wasCapped: futureCount > RecurrenceEngine.maximumGeneratedFutureOccurrences
        )
    }

    @MainActor
    private func currentOccurrenceIndexForNewSequence() -> Int {
        return task.occurrenceIndex ?? 1
    }

    @MainActor
    private func performConfirmedRecurrenceRegeneration() {
        guard pendingRecurrenceRegeneration else { return }
        pendingRecurrenceRegeneration = false
        recurrenceGenerationConfirmation = false

        Task { @MainActor in
            await ForMemoAlarmManager.shared.waitForPendingSynchronizations()
            await performConfirmedRecurrenceRegenerationAfterSynchronization()
        }
    }
    
    
    @MainActor
    private func performConfirmedRecurrenceRegenerationAfterSynchronization() async {

        guard let initial = initialEditSnapshot else {
            finishDetailExit()
            return
        }

        let oldRecurrenceID = initial.recurrenceID
        let currentIndex = initial.occurrenceIndex ?? 1
        let currentDate = task.deadLine ?? task.recurrenceStartDate ?? Date()

        do {
            if let oldRecurrenceID {
                // Collapse any legacy per-occurrence records created by
                // earlier experimental versions into one logical rule per
                // attachment/recurrence pair before changing the series.
                try RecurringAttachmentManager.normalizeRules(
                    for: oldRecurrenceID,
                    in: modelContext
                )
            }

            let currentLinks = RecurringAttachmentManager.links(
                for: task,
                in: modelContext
            )

            // Delete future occurrences belonging to the old series. Shared
            // attachment rules remain independent and are handled below.
            if let oldRecurrenceID {
                let occurrences = try modelContext.fetch(
                    FetchDescriptor<TodoTask>(
                        predicate: #Predicate<TodoTask> { candidate in
                            candidate.recurrenceID == oldRecurrenceID
                        }
                    )
                )

                let futureOccurrencesToDelete = occurrences.filter { occurrence in
                    occurrence.id != task.id &&
                    (occurrence.occurrenceIndex ?? 1) > currentIndex
                }

                // Cancel AlarmKit entries before deleting their TodoTask records.
                // Alarm IDs are the corresponding task IDs.
                await ForMemoAlarmManager.shared.cancelAlarms(
                    ids: futureOccurrencesToDelete.map(\.id)
                )

                for occurrence in futureOccurrencesToDelete {
                    RecurringAttachmentManager.prepareLinksBeforeTaskDeletion(
                        occurrence,
                        preserveAnchors: false,
                        in: modelContext
                    )

                    modelContext.delete(occurrence)
                }
            }

            let activeLinkedAttachmentIDs = Set(
                currentLinks
                    .filter { $0.isActive }
                    .map { $0.attachmentID }
            )

            // When converting a simple task into a recurring task, there are
            // no recurring links yet. Preserve its existing attachments by
            // creating propagation links for their IDs below. Existing
            // recurring series continue to use only their active linked IDs.
            let attachmentIDs: Set<UUID> = oldRecurrenceID == nil
                ? activeLinkedAttachmentIDs.union(
                    (task.attachments ?? []).map(\.id)
                )
                : activeLinkedAttachmentIDs

            guard task.recurrenceRule != nil else {
                // The recurrence ends at the retained occurrence. Preserve
                // the attachment on surviving past occurrences by truncating
                // the old rules before this occurrence. The retained task
                // receives ordinary ownership of the currently visible
                // attachment.
                if let oldRecurrenceID {
                    try RecurringAttachmentManager.truncatePropagation(
                        for: oldRecurrenceID,
                        attachmentIDs: [],
                        endingAt: currentIndex - 1,
                        in: modelContext
                    )
                    try RecurringAttachmentManager.pruneUnreferencedRules(
                        for: oldRecurrenceID,
                        in: modelContext
                    )
                }

                for attachmentID in attachmentIDs {
                    let attachmentDescriptor = FetchDescriptor<TaskAttachment>(
                        predicate: #Predicate<TaskAttachment> { attachment in
                            attachment.id == attachmentID
                        }
                    )

                    guard let attachment = try modelContext.fetch(
                        attachmentDescriptor
                    ).first else {
                        continue
                    }

                    if task.attachments == nil {
                        task.attachments = []
                    }

                    if !(task.attachments ?? []).contains(where: {
                        $0.id == attachment.id
                    }) {
                        attachment.task = task
                        task.attachments?.append(attachment)
                    }
                }

                task.recurrenceID = nil
                task.occurrenceIndex = nil
                task.recurrenceStartDate = nil
                task.recurrenceEndDate = nil
                task.recurrenceCount = nil

                try modelContext.save()
                modelContext.processPendingChanges()
                NotificationCenter.default.post(
                    name: .taskDidChange,
                    object: nil
                )
                NotificationManager.shared.refresh()
                finishDetailExit()
                return
            }

            let newRecurrenceID = UUID()

            // The old series keeps propagation only through the last surviving
            // past occurrence. The new series gets one fresh rule per shared
            // attachment starting at occurrence 1.
            if let oldRecurrenceID {
                try RecurringAttachmentManager.truncatePropagation(
                    for: oldRecurrenceID,
                    attachmentIDs: [],
                    endingAt: currentIndex - 1,
                    in: modelContext
                )

                try RecurringAttachmentManager.pruneUnreferencedRules(
                    for: oldRecurrenceID,
                    in: modelContext
                )
            }

            for attachmentID in attachmentIDs {
                let attachmentDescriptor = FetchDescriptor<TaskAttachment>(
                    predicate: #Predicate<TaskAttachment> { attachment in
                        attachment.id == attachmentID
                    }
                )

                let ownerTaskID =
                    (try? modelContext.fetch(attachmentDescriptor).first?.task?.id)
                    ?? task.id

                modelContext.insert(
                    RecurringAttachmentLink(
                        taskID: ownerTaskID,
                        attachmentID: attachmentID,
                        recurrenceID: newRecurrenceID,
                        occurrenceIndex: 1,
                        propagationStartIndex: 1,
                        propagationEndIndex: nil,
                        isPropagationAnchor: true,
                        isActive: true
                    )
                )
            }

            task.recurrenceID = newRecurrenceID
            task.occurrenceIndex = 1
            task.recurrenceStartDate = currentDate

            if let count = task.recurrenceCount {
                task.recurrenceCount = max(
                    1,
                    count - currentIndex + 1
                )
            }

            let generated = try RecurrenceEngine.materializeFutureOccurrences(
                for: task,
                in: modelContext
            )

            let allowedCount = min(
                generated.count,
                recurrenceGenerationCreateCount
            )

            if generated.count > allowedCount {
                for extra in generated.dropFirst(allowedCount) {
                    modelContext.delete(extra)
                }
            }

            try modelContext.save()
            modelContext.processPendingChanges()

            if let newRecurrenceID = task.recurrenceID {
                let occurrences = (try? modelContext.fetch(
                    FetchDescriptor<TodoTask>(
                        predicate: #Predicate<TodoTask> {
                            $0.recurrenceID == newRecurrenceID
                        }
                    )
                )) ?? []

                _ = await ForMemoAlarmManager.shared.synchronize(
                    tasks: occurrences,
                    in: modelContext
                )
            }

            NotificationCenter.default.post(
                name: .taskDidChange,
                object: nil
            )
            NotificationManager.shared.refresh()
            finishDetailExit()

        } catch {
            AppLogger.persistence.error(
                "TaskDetail recurrence regeneration failed: \(error.localizedDescription)"
            )
        }
    }

    @MainActor
    private func copyFutureTaskProperties(
        from source: TodoTask,
        to destination: TodoTask
    ) {
        destination.title = source.title
        destination.taskDescription = source.taskDescription
        destination.reminderOffsetMinutes = source.reminderOffsetMinutes
        destination.excludeGlobalNotification = source.excludeGlobalNotification
        destination.locationName = source.locationName
        destination.locationLatitude = source.locationLatitude
        destination.locationLongitude = source.locationLongitude
        destination.locationReminderEnabled = source.locationReminderEnabled
        destination.priorityRaw = source.priorityRaw
        destination.mainTagRaw = source.mainTagRaw
        destination.alarmEnabled = source.alarmEnabled
        destination.recurrenceRule = source.recurrenceRule
        destination.recurrenceInterval = source.recurrenceInterval
        destination.recurrenceStartDate = source.recurrenceStartDate
        destination.recurrenceEndDate = source.recurrenceEndDate
        destination.recurrenceCount = source.recurrenceCount
    }

    private func recurrenceDefinitionChanged() -> Bool {
        guard let initial = initialEditSnapshot else {
            return false
        }
        return initial.recurrenceRule != task.recurrenceRule ||
        initial.recurrenceInterval != task.recurrenceInterval ||
        initial.recurrenceStartDate != task.recurrenceStartDate ||
        initial.recurrenceEndDate != task.recurrenceEndDate ||
        initial.recurrenceCount != task.recurrenceCount
    }

    @MainActor
    private func debounceCloudKitUpdate() {
        
        DebugLog.writeCloudKitEvent(
            "TaskDetail CloudKit debounce cancelled"
        )
        cloudKitDebounceTask?.cancel()
        
        cloudKitDebounceTask = Task { @MainActor in
            DebugLog.writeCloudKitEvent(
                "TaskDetail CloudKit debounce scheduled"
            )
            try? await Task.sleep(for: .seconds(1))
            DebugLog.writeCloudKitEvent(
                "TaskDetail CloudKit debounce fired"
            )
            guard !Task.isCancelled else { return }
            
            handleCloudKitUpdate()
        }
    }
    
    @MainActor
    private func scheduleDebouncedSave() {
        
        saveTaskDebounce?.cancel()
        
        saveTaskDebounce = Task { @MainActor in
            
            try? await Task.sleep(for: .milliseconds(500))
            
            guard !Task.isCancelled else { return }
            
            saveTask(userInitiated: true)
        }
    }
    
    @MainActor
    private func handleCloudKitUpdate() {
        
        modelContext.processPendingChanges()
        
        refreshID = UUID()
        
        preloadAttachments()
    }
    
    //MARK:preloadAttachments
    
    @MainActor
    private func preloadAttachments() {
        
        let attachments = taskAttachments
        
        Task.detached(priority: .utility) {

            for attachment in attachments {

                guard let url = attachment.fileURL else {
                    continue
                }

                autoreleasepool {

                    do {

                        let values = try url.resourceValues(
                            forKeys: [
                                .isUbiquitousItemKey,
                                .ubiquitousItemDownloadingStatusKey
                            ]
                        )

                        guard values.isUbiquitousItem == true else {
                            return
                        }

                        if values.ubiquitousItemDownloadingStatus
                            != URLUbiquitousItemDownloadingStatus.current {

                            try? FileManager.default.startDownloadingUbiquitousItem(at: url)
                        }

                    } catch {

                    }
                }
            }
        }
    }
    
    // MARK: removeGhostAttachments
    @MainActor
    private func removeGhostAttachments() {
        
        let ghostAttachments = taskAttachments.filter { attachment in
            
            guard let url = attachment.fileURL else { return false }
            
            // 🔥 NON considerare ghost se è file iCloud non ancora scaricato
            if (try? url.resourceValues(forKeys: [.isUbiquitousItemKey]))?.isUbiquitousItem == true {
                return false
            }
            
            return !FileManager.default.fileExists(atPath: url.path)
        }
        
        guard !ghostAttachments.isEmpty else { return }
        
        AppLogger.notifications.warning("⚠️ Ghost check skipped deletion for safety: \(ghostAttachments.map { $0.originalName })")
        
        // ❌ NON eliminare automaticamente
        // eventualmente qui puoi solo loggare o marcare
    }
    
    // MARK: - importCameraImage
    @MainActor
    private func importCameraImage(_ image: UIImage) async {
        
        guard let data = image.jpegData(compressionQuality: 0.9) else { return }
        
        let filename = "Camera-\(UUID().uuidString).jpg"
        let tmpURL = FileManager.default.temporaryDirectory
            .appendingPathComponent(filename)
        
        do {
            try data.write(to: tmpURL)
            await saveAttachment(from: tmpURL)
        } catch {
            AppLogger.app.error("Failed to write camera image:\(error))")
        }
    }
    
    
    
    // MARK: - buildShareItems
    
    private func buildShareItems(
        includeText: Bool,
        attachments: [TaskAttachment]
    ) -> [Any] {
        
        var items: [Any] = []
        
        if includeText {
            
            var text = task.title
            
            if !task.taskDescription.isEmpty {
                text += "\n\n" + task.taskDescription
            }
            
            if let deadline = task.deadLine {
                text += "\n\nDeadline: \(deadline.formatted())\n"
            }
            
            items.append(text)
        }
        
        for att in attachments {
            
            guard let url = att.fileURL else { continue }
            
            if FileManager.default.fileExists(atPath: url.path) {
                items.append(url)
            }
        }
        
        return items
    }
    
    
    
    @MainActor
    private func openNavigation(
        to coordinate: CLLocationCoordinate2D,
        name: String
    ) {
        let lat = coordinate.latitude
        let lon = coordinate.longitude

        switch settings.navigationApp.id {

        case "google":

            guard let googleURL = URL(
                string: "comgooglemaps://?daddr=\(lat),\(lon)&directionsmode=driving"
            ) else {
                return
            }

            if UIApplication.shared.canOpenURL(googleURL) {
                UIApplication.shared.open(googleURL)
            } else {
                guard let fallbackURL = URL(
                    string: "https://www.google.com/maps/dir/?api=1&destination=\(lat),\(lon)"
                ) else {
                    return
                }
                UIApplication.shared.open(fallbackURL)
            }

        case "waze":

            if let url = URL(
                string: "waze://?ll=\(lat),\(lon)&navigate=yes"
            ) {
                UIApplication.shared.open(url)
            }



        case "chooser":

            let alert = UIAlertController(
                title: String(localized: "Navigate with"),
                message: nil,
                preferredStyle: .actionSheet
            )

            alert.addAction(
                UIAlertAction(
                    title: "Apple Maps",
                    style: .default
                ) { _ in
                    guard let url = URL(
                        string: "http://maps.apple.com/?daddr=\(lat),\(lon)"
                    ) else {
                        return
                    }
                    UIApplication.shared.open(url)
                }
            )

            if let googleMapsURL = URL(string: "comgooglemaps://"),
               UIApplication.shared.canOpenURL(googleMapsURL) {
                alert.addAction(
                    UIAlertAction(
                        title: "Google Maps",
                        style: .default
                    ) { _ in
                        guard let googleURL = URL(
                            string: "comgooglemaps://?daddr=\(lat),\(lon)&directionsmode=driving"
                        ) else {
                            return
                        }
                        UIApplication.shared.open(googleURL)
                    }
                )
            }

            if let wazeURL = URL(string: "waze://"),
               UIApplication.shared.canOpenURL(wazeURL) {
                alert.addAction(
                    UIAlertAction(
                        title: "Waze",
                        style: .default
                    ) { _ in
                        guard let wazeURL = URL(
                            string: "waze://?ll=\(lat),\(lon)&navigate=yes"
                        ) else {
                            return
                        }
                        UIApplication.shared.open(wazeURL)
                    }
                )
            }

            alert.addAction(
                UIAlertAction(
                    title: String(localized: "Cancel"),
                    style: .cancel
                )
            )

            guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let rootVC = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else {
                return
            }

            rootVC.present(alert, animated: true)

        default:

            guard let url = URL(
                string: "http://maps.apple.com/?daddr=\(lat),\(lon)"
            ) else {
                return
            }

            UIApplication.shared.open(url)
        }
    }
    
    
    
    // MARK: - Helpers
    
    private func isAudio(_ attachment: TaskAttachment) -> Bool {
        
        if let type = UTType(mimeType: attachment.contentType) {
            return type.conforms(to: .audio)
        }
        
        return UTType(attachment.contentType)?.conforms(to: .audio) ?? false
    }
    //    }

    private var metadataSection: some View {
        Section("Metadata") {
            LabeledContent(
                "Created at",
                value: task.createdAt.formatted(
                    date: .abbreviated,
                    time: .shortened
                )
            )

            if let occurrenceIndex = task.occurrenceIndex {
                LabeledContent(
                    "Occurrence",
                    value: task.recurrenceCount.map {
                        "\(occurrenceIndex) of \($0)"
                    } ?? "\(occurrenceIndex)"
                )
            }
            if let recurrenceCount = task.recurrenceCount {
                LabeledContent(
                    "Total occurrences",
                    value: "\(recurrenceCount)"
                )
            }

            if let recurrenceStartDate = task.recurrenceStartDate {
                LabeledContent(
                    "Series started",
                    value: recurrenceStartDate.formatted(
                        date: .abbreviated,
                        time: .shortened
                    )
                )
            }
            if let recurrenceEndDate = task.recurrenceEndDate {
                LabeledContent(
                    "Series ends",
                    value: recurrenceEndDate.formatted(
                        date: .abbreviated,
                        time: .shortened
                    )
                )
            }
            
        }
        .listRowBackground(Color(.systemBackground).opacity(0.3))
    }
    
    @MainActor
    private func importPhotos(from items: [PhotosPickerItem]) async {
        var importedCount = 0
        var skippedCount = 0

        for item in items {
            guard let data = try? await item.loadTransferable(type: Data.self) else {
                skippedCount += 1
                AppLogger.app.error("Photo import skipped: unable to load selected item")
                continue
            }

            let imageType = item.supportedContentTypes.first { $0.conforms(to: .image) }
            let fileExtension = imageType?.preferredFilenameExtension ?? "jpg"
            let filename = "Photo-\(UUID().uuidString).\(fileExtension)"
            let tmpURL = FileManager.default.temporaryDirectory
                .appendingPathComponent(filename)

            do {
                try data.write(to: tmpURL)
                await saveAttachment(from: tmpURL, promptForRecurringScope: false)
                importedCount += 1
            } catch {
                skippedCount += 1
                AppLogger.app.error("Failed to write photo:\(error.localizedDescription)")
            }
        }

        photoItems.removeAll()

        if task.recurrenceID != nil,
           !recurringAttachmentScopeIDs.isEmpty {
            showingRecurringAttachmentScope = true
        }

        if skippedCount > 0 {
            photoImportMessage = String(
                localized: "Imported \(importedCount) photos. \(skippedCount) could not be loaded from Photos/iCloud. Open Photos, download them locally, then try again."
            )
        }
    }
    
    
    @MainActor
    private func importFiles(from urls: [URL]) async {
        
        for url in urls {
            
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            
            await saveAttachment(from: url, promptForRecurringScope: false)
        }

        if task.recurrenceID != nil,
           !recurringAttachmentScopeIDs.isEmpty {
            showingRecurringAttachmentScope = true
        }
    }
    
    
    @MainActor
    private func importScans(from images: [UIImage]) async {
        
        for (index, image) in images.enumerated() {
            
            guard let data = image.jpegData(compressionQuality: 0.9) else {
                continue
            }
            
            let filename = "Scan-\(index + 1)-\(UUID().uuidString).jpg"
            let tmpURL = FileManager.default.temporaryDirectory
                .appendingPathComponent(filename)
            
            do {
                try data.write(to: tmpURL)
                await saveAttachment(from: tmpURL, promptForRecurringScope: false)
            } catch {
                AppLogger.app.error("Failed to write scan image:\(error))")
            }
        }

        if task.recurrenceID != nil,
           !recurringAttachmentScopeIDs.isEmpty {
            showingRecurringAttachmentScope = true
        }
    }
    @MainActor
    private func saveAttachment(from url: URL, promptForRecurringScope: Bool = true) async {
        
        let didStartAccessing = url.startAccessingSecurityScopedResource()
        defer {
            if didStartAccessing {
                url.stopAccessingSecurityScopedResource()
            }
        }
        
        do {
            let attachment = try await AttachmentImporter.addAttachment(
                from: url,
                to: task
            )

            // AttachmentImporter now returns a detached model so NewTask
            // can defer persistence until Save. In TaskDetail, the task
            // already exists, so attach and insert the model immediately.
            attachment.task = task
            if task.attachments == nil {
                task.attachments = []
            }
            task.attachments?.append(attachment)
            modelContext.insert(attachment)

            if task.recurrenceID != nil,
               task.occurrenceIndex != nil {
                recurringAttachmentScopeIDs.append(attachment.id)
                if promptForRecurringScope {
                    showingRecurringAttachmentScope = true
                }
            }

            saveTask(userInitiated: true)
            NotificationCenter.default.post(
                name: .attachmentsShouldRefresh,
                object: nil
            )
#if DEBUG
AppLogger.notifications.info(
    "Attachment saved"
)
#endif
        } catch {
            AppLogger.app.error("Attachment import error:\(error.localizedDescription))")
        }
    }
    
    // MARK: - Delete
    private func deleteAttachment(_ attachment: TaskAttachment) {
        if RecurringAttachmentManager.attachmentIsPropagated(
            attachment,
            in: modelContext
        ) {
            pendingRecurringAttachmentDeletion = attachment
            showingRecurringAttachmentGlobalDelete = true
            return
        }

        let trashName: String?
        do {
            trashName = try attachment.deleteFileIfNeeded()
        } catch {
            AppLogger.persistence.error("Attachment deletion stopped because moving the file to Trash failed: \(error.localizedDescription)")
            return
        }

        let item = DeletedItem(type: "attachment")
        item.taskID = task.id
        item.fileName = attachment.originalName
        item.relativePath = attachment.relativePath
        item.trashFileName = trashName
        modelContext.insert(item)

        task.attachments?.removeAll { $0.id == attachment.id }
        modelContext.delete(attachment)
        modelContext.processPendingChanges()

        guard commitAttachmentDeletion() else {
            if let trashName {
                do {
                    try TaskAttachment.restoreFileFromTrash(
                        trashFileName: trashName,
                        relativePath: attachment.relativePath
                    )
                } catch {
                    AppLogger.persistence.fault(
                        "Failed to restore attachment after deletion rollback: \(error.localizedDescription)"
                    )
                }
            }
            return
        }

        initialEditSnapshot = TaskEditSnapshot(task: task)

        NotificationCenter.default.post(
            name: .attachmentsShouldRefresh,
            object: nil
        )
    }

    private func loadImageAsync(for attachment: TaskAttachment) async {
        
        guard imageCache[attachment.id] == nil else {
            AppLogger.notifications.info(
                "Image cache hit"
            )
            return
        }
        
        AppLogger.notifications.info(
            "Loading attachment image"
        )
        
        if let data = await attachment.loadDataAsync() {
            
            AppLogger.persistence.info(
                "Attachment data loaded"
            )
            
            if let image = UIImage(data: data) {
                
                AppLogger.notifications.info(
                    "Attachment image created"
                )
                
                await MainActor.run {
                    imageCache[attachment.id] = image
                }
                
            } else {
                AppLogger.notifications.info(
                    "Attachment image decode failed"
                )
            }
            
        } else {
            AppLogger.notifications.info(
                "Attachment data unavailable"
            )
        }
    }
    // MARK: - Helpers
    
    private func isImage(_ attachment: TaskAttachment) -> Bool {
        
        guard let type = resolvedType(for: attachment) else {
            return false
        }
        
        return type.conforms(to: .image)
    }
    private func iconName(for attachment: TaskAttachment) -> String {
        
        guard let type = resolvedType(for: attachment) else {
            return "doc"
        }
        
        if type.conforms(to: .image) { return "photo" }
        if type.conforms(to: .pdf)   { return "doc.richtext" }
        if type.conforms(to: .movie) { return "film" }
        
        return "doc"
    }
    
    private func resolvedType(for attachment: TaskAttachment) -> UTType? {
        
        if let t = UTType(mimeType: attachment.contentType) {
            return t
        }
        
        return UTType(attachment.contentType)
    }
    
    
    @MainActor
    private func rebuildNotifications() {
        
        _ = (try? modelContext.fetch(
            FetchDescriptor<TodoTask>()
        )) ?? []
        
        NotificationManager.shared.refresh()
    }
    
    
    
    
    @MainActor
    private func onAppearAction() {

        preloadAttachments()

        if let rule = task.recurrenceRule,
           let mapped = RecurrenceUI(rawValue: rule) {
            selectedRecurrence = mapped
        } else {
            selectedRecurrence = .none
        }
    }
}
