import SwiftUI

@MainActor
enum AppTab: Int, CaseIterable, Identifiable {
    case dashboard = 10
    case tasks = 1
    case calendar = 3
    case wallet = 6
    case start = 0
    case vault = 11
    case trips = 7
    case documents = 8
    case today = 4
    case forecast = 9
    case map = 5
    case settings = 2
    case notes = 12
    case recentlyDeleted = 13

    // Preserves the current tab bar and More menu order for existing users.
    static let defaultOrder: [AppTab] = [
        .dashboard, .tasks, .notes, .wallet,
        .start, .vault, .trips, .documents,
         .calendar, .today,  .map,  .forecast, .recentlyDeleted, .settings
    ]

    var id: Int { rawValue }

    var icon: String {
        switch self {
        case .dashboard: "rectangle.grid.3x1"
        case .tasks: "checklist"
        case .calendar: "calendar"
        case .wallet: "wallet.bifold"
        case .start: "info"
        case .vault: "key.shield"
        case .trips: "list.bullet.clipboard"
        case .documents: "doc.text"
        case .today: "calendar.day.timeline.right"
        case .forecast: "cloud.sun"
        case .map: "map"
        case .settings: "gear"
        case .notes: "note.text"
        case .recentlyDeleted: "trash"
        }
    }

    func title(using settings: AppSettings) -> String {
        switch self {
        case .dashboard: "Dashboard"
        case .tasks: String(localized: "list_tab")
        case .calendar: String(localized: "calendar_tab")
        case .wallet: String(localized: "wallet_tab")
        case .start: String(localized: "Start_tab")
        case .vault: String(localized: "Vault")
        case .trips: String(localized: "Checklists")
        case .documents: String(localized: "Documents")
        case .today:
            settings.taskWeekDays == 1
                ? String(localized: "today_tab")
                : String(localized: "\(settings.taskWeekDays) days_tab")
        case .forecast: String(localized: "Weather")
        case .map: String(localized: "map_tab")
        case .settings: String(localized: "settings_tab")
        case .notes: String(localized: "Notes")
        case .recentlyDeleted: String(localized: "Recently Deleted")
        }
    }

    func isVisible(using settings: AppSettings) -> Bool {
        switch self {
        case .vault: settings.showVault
        case .forecast: settings.showWeatherForecast
        default: true
        }
    }
}
