import SwiftUI
import CoreLocation
import SwiftData
import os

struct TaskTabView: View {
    @Environment(\.modelContext) private var modelContext
    @Environment(\.horizontalSizeClass) private var sizeClass
    @Environment(AppSettings.self) private var settings
    @Environment(\.scenePhase) private var scenePhase

//    @Query private var tasks: [TodoTask]
//    @Query private var documents: [DocumentItem]
//    @Query private var cards: [LoyaltyCard]
//    @Query private var trips: [TripList]
    
    @State private var selectedTab: Int = 0
    @State private var previousTab = 0
    @State private var showSnoozeAlert = false
    @State private var showMorePopover = false
    @State private var showGlobalSearch = false
    @State
    private var recoveryResult: AssetRecoveryCoordinator.RecoveryCheckResult?
    @State
    private var recoveryCheckPerformed = false
    
    @State private var StartPath = NavigationPath()
    @State private var dashboardPath = NavigationPath()
    @State private var listPath = NavigationPath()
    @State private var weeklyPath = NavigationPath()
    @State private var calendarPath = NavigationPath()
    @State private var dayPath = NavigationPath()
    @State private var mapPath = NavigationPath()
    @State private var walletPath = NavigationPath()
    @State private var vaultPath = NavigationPath()
    @State private var TripsPath = NavigationPath()
    @State private var documentsPath = NavigationPath()
    @State private var weatherPath = NavigationPath()
    @State private var settingsPath = NavigationPath()
    @State private var notesPath = NavigationPath()
    @StateObject private var noteEditorCoordinator = NoteEditorCoordinator()
    @State private var showNoteUnsavedChangesAlert = false
    @State private var pendingNoteTab: Int?
    @State private var sessionSelectedDate = Calendar.current.startOfDay(for: .now)
    
    var body: some View {
        rootLayout
            .sheet(isPresented: $showGlobalSearch) {
                GlobalSearchView(noteEditorCoordinator: noteEditorCoordinator)
            }
            .onAppear {
                syncWeatherLocationPermission()

                selectedTab = 0


                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                    NotificationCenter.default.post(
                        name: Notification.Name("StartStartIconRotationFast"),
                        object: nil
                    )

                    // Wait exactly for the single rotation to complete.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                        guard selectedTab == 0 else {
                            return
                        }

                        withAnimation(.easeInOut(duration: 0.18)) {
                            if settings.startupTab == -1 {
                                selectedTab = normalizedTabSelection(shouldOpenDashboardAutomatically() ? AppTab.dashboard.rawValue : AppTab.tasks.rawValue)
                            } else {
                                selectedTab = normalizedTabSelection(settings.startupTab)
                            }
                        }
                    }
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 2.8) {

                    guard selectedTab == 0 else {
                        return
                    }

                    withAnimation(.easeInOut(duration: 0.18)) {
                        if settings.startupTab == -1 {
                            selectedTab = normalizedTabSelection(shouldOpenDashboardAutomatically() ? AppTab.dashboard.rawValue : AppTab.tasks.rawValue)
                        } else {
                            selectedTab = normalizedTabSelection(settings.startupTab)
                        }
                    }
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: .snoozeRejectedDueToDeadline)) { _ in
                showSnoozeAlert = true
            }
            .onReceive(
                NotificationCenter.default.publisher(
                    for: Notification.Name("DashboardOpenList")
                )
            ) { _ in

                dashboardPath = NavigationPath()

                withAnimation(.easeInOut(duration: 0.18)) {
                    selectedTab = 1
                }
            }
            .onReceive(
                NotificationCenter.default.publisher(
                    for: Notification.Name("TaskDayOpenCalendar")
                )
            ) { notification in
                guard let date = notification.object as? Date else {
                    return
                }

                sessionSelectedDate = Calendar.current.startOfDay(for: date)
                calendarPath = NavigationPath()

                withAnimation(.easeInOut(duration: 0.18)) {
                    selectedTab = AppTab.calendar.rawValue
                }
            }
            .onReceive(
                NotificationCenter.default.publisher(
                    for: Notification.Name("TaskCalendarOpenDay")
                )
            ) { notification in
                guard let date = notification.object as? Date else {
                    return
                }

                sessionSelectedDate = Calendar.current.startOfDay(for: date)
                dayPath = NavigationPath()

                withAnimation(.easeInOut(duration: 0.18)) {
                    selectedTab = AppTab.agenda.rawValue
                }
            }
            .onReceive(
                NotificationCenter.default.publisher(
                    for: Notification.Name("VaultAuthenticationFailed")
                )
            ) { _ in

                vaultPath = NavigationPath()

                withAnimation(.easeInOut(duration: 0.18)) {
                    selectedTab = previousTab == 11 ? 10 : previousTab
                }
            }
            .onChange(of: settings.showWeatherForecast) { _, enabled in
                if !enabled && selectedTab == AppTab.forecast.rawValue {
                    selectedTab = fallbackVisibleTab()
                }
            }
            .onChange(of: settings.showDashboardTab) { _, enabled in
                if !enabled && selectedTab == AppTab.dashboard.rawValue {
                    selectedTab = fallbackVisibleTab()
                }
            }
            .onChange(of: settings.showWeekTab) { _, enabled in
                if !enabled && selectedTab == AppTab.today.rawValue {
                    selectedTab = fallbackVisibleTab()
                }
            }
            .onChange(of: settings.showMapTab) { _, enabled in
                if !enabled && selectedTab == AppTab.map.rawValue {
                    selectedTab = fallbackVisibleTab()
                }
            }
            .onChange(of: settings.showTasksTab) { _, enabled in
                if !enabled && selectedTab == AppTab.tasks.rawValue {
                    selectedTab = fallbackVisibleTab()
                }
            }
            .onChange(of: settings.showDayTab) { _, enabled in
                if !enabled && selectedTab == AppTab.agenda.rawValue {
                    selectedTab = fallbackVisibleTab()
                }
            }
            .onReceive(
                NotificationCenter.default.publisher(for: .locationPermissionChanged)
            ) { _ in
                syncWeatherLocationPermission()
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active {
                    syncWeatherLocationPermission()
                }
            }
        
            .onChange(of: settings.showVault) { _, enabled in
                if !enabled && selectedTab == AppTab.vault.rawValue {
                    selectedTab = fallbackVisibleTab()
                }
            }
        
            .onChange(of: selectedTab) { oldValue, newValue in

                previousTab = oldValue

                if oldValue == 11 && newValue != 11 {

                    VaultLock.shared.lock()

                    vaultPath = NavigationPath()
                }
            }
            .alert(
                "Snooze not scheduled",
                isPresented: $showSnoozeAlert
            ) {
                Button("OK", role: .cancel) {}
            } message: {
                Text("Snooze exceeds the deadline. No snooze notification will be scheduled. The deadline notification will still occur.")
            }
        
            .alert(item: $recoveryResult) { result in

                Alert(

                    title: Text("Asset Recovery"),

                    message: Text(
    """
    \(result.duplicateFolders.count) duplicate asset folders detected.

    \(result.duplicateFolders
        .map { "• \($0)" }
        .joined(separator: "\n"))

    Automatic recovery has been suspended because
    Asset Recovery Diagnostics is enabled.

    Press Repair to merge the folders.
    """
),

                    primaryButton: .default(
                        Text("Repair")
                    ) {

                        AssetRecoveryCoordinator.recoverAutomaticallyIfNeeded(
                            context: modelContext
                        )

                        recoveryResult = nil

                    },

                    secondaryButton: .cancel {

                        recoveryResult = nil

                    }

                )

            }
            .alert(
                String(localized: "Save changes?"),
                isPresented: $showNoteUnsavedChangesAlert
            ) {
                Button(String(localized: "Save")) {
                    noteEditorCoordinator.save?()
                    noteEditorCoordinator.reset()

                    if let pendingNoteTab {
                        withAnimation(nil) {
                            selectedTab = pendingNoteTab
                        }
                        resetTab(pendingNoteTab)
                    }

                    self.pendingNoteTab = nil
                }

                Button(String(localized: "Don’t Save"), role: .destructive) {
                    noteEditorCoordinator.discard?()
                    noteEditorCoordinator.reset()

                    if let pendingNoteTab {
                        withAnimation(nil) {
                            selectedTab = pendingNoteTab
                        }
                        resetTab(pendingNoteTab)
                    }

                    self.pendingNoteTab = nil
                }

                Button(String(localized: "Cancel"), role: .cancel) {
                    pendingNoteTab = nil
                }
            } message: {
                Text(String(localized: "You have unsaved changes."))
            }
        
            .task {
                let start = CFAbsoluteTimeGetCurrent()

                AppLogger.persistence.notice("STARTUP ⏱ TaskTabView task START")

                guard !recoveryCheckPerformed else {
                    AppLogger.persistence.notice(
                        "STARTUP ⏱ TaskTabView task already performed: \(CFAbsoluteTimeGetCurrent() - start)s"
                    )
                    return
                }

                recoveryCheckPerformed = true

                guard DiagnosticsOptions.assetRecoveryDiagnostics else {
                    AppLogger.persistence.notice(
                        "STARTUP ⏱ Asset Recovery SKIPPED: \(CFAbsoluteTimeGetCurrent() - start)s"
                    )
                    return
                }

                let recoveryStart = CFAbsoluteTimeGetCurrent()

                let result = AssetRecoveryCoordinator.launchRecoveryCheck()

                AppLogger.persistence.notice(
                    "STARTUP ⏱ Asset Recovery = \(CFAbsoluteTimeGetCurrent() - recoveryStart)s"
                )

                guard result.needsRepair else {
                    AppLogger.persistence.notice(
                        "STARTUP ⏱ TaskTabView total = \(CFAbsoluteTimeGetCurrent() - start)s"
                    )
                    return
                }

                recoveryResult = result

                AppLogger.persistence.notice(
                    "STARTUP ⏱ TaskTabView total = \(CFAbsoluteTimeGetCurrent() - start)s"
                )
            }
        
    }
    
    /// Automatic startup opens Dashboard only when an active task is due today or tomorrow.
    /// Tasks without a deadline, completed tasks, and tasks due later do not qualify.
    private func shouldOpenDashboardAutomatically() -> Bool {
        let calendar = Calendar.current
        let todayStart = calendar.startOfDay(for: .now)
        guard
            let dayAfterTomorrowStart = calendar.date(byAdding: .day, value: 2, to: todayStart)
        else {
            return false
        }

        let descriptor = FetchDescriptor<TodoTask>(
            predicate: #Predicate<TodoTask> {
                !$0.isCompleted &&
                $0.deadLine != nil &&
                $0.deadLine! >= todayStart &&
                $0.deadLine! < dayAfterTomorrowStart
            }
        )

        do {
            return try modelContext.fetchCount(descriptor) > 0
        } catch {
            AppLogger.persistence.error(
                "Automatic startup task check failed: \\(error.localizedDescription)"
            )
            return false
        }
    }

    @ViewBuilder
    private var rootLayout: some View {
        
        if sizeClass == .regular {
            iPadLayout
        } else {
            iPhoneLayout
        }
    }
    
    // MARK: - iPhone

    private var visibleTabs: [AppTab] {
        settings.orderedTabs.filter { $0.isVisible(using: settings) }
    }

    private func fallbackVisibleTab() -> Int {
        visibleTabs.first?.rawValue ?? AppTab.settings.rawValue
    }

    private func normalizedTabSelection(_ requestedTab: Int) -> Int {
        guard let tab = AppTab(rawValue: requestedTab),
              tab.isVisible(using: settings) else {
            return fallbackVisibleTab()
        }
        return requestedTab
    }

    private var primaryTabCount: Int {
        max(1, settings.tabBarVisibleItemCount - 1)
    }

    private var primaryTabs: [AppTab] {
        Array(visibleTabs.prefix(primaryTabCount))
    }

    private var moreTabs: [AppTab] {
        Array(visibleTabs.dropFirst(primaryTabCount))
    }
    
    private var iPhoneLayout: some View {
        
        ZStack {
            currentTabView
        }
        .safeAreaInset(edge: .bottom) {
            
            HStack(spacing: 10) {
                ForEach(primaryTabs) { tab in
                    tabItem(tab.icon, tab.title(using: settings), tab.rawValue)
                }
                
                Button {
                    showMorePopover.toggle()
                } label: {
                    VStack(spacing: 4) {

                        Image(systemName: "square.grid.2x2")
                            .font(.system(size: 21, weight: .regular))
                            .frame(height: 22)

                        Text("More")
                            .font(.system(size: 9, weight: .medium))

                        Capsule()
                            .fill(
                                Color(hex: settings.tabBarCustomizationIconColorHex) ?? .blue
                            )
                            .frame(width: 16, height: 3)
                            .opacity(moreTabs.contains { $0.rawValue == selectedTab } ? 1 : 0)
                    }
                    .frame(maxWidth: .infinity)
                    .frame(height: 49)
                    .contentShape(Rectangle())
                    .foregroundStyle(
                        moreTabs.contains { $0.rawValue == selectedTab }
                        ? (Color(hex: settings.tabBarCustomizationIconColorHex) ?? .blue)
                        : Color.primary
                    )
                }
                .popover(isPresented: $showMorePopover, attachmentAnchor: .point(.top), arrowEdge: .bottom) {
                    VStack(alignment: .leading, spacing: 10) {
                        ForEach(moreTabs) { tab in
                            moreTabItem(tab)
                        }
                    }
                    .padding(.vertical, 13)
                    .padding(.trailing, 36)
                    .padding(.leading, 20)
                    .fixedSize(horizontal: true, vertical: false)
                    .presentationCompactAdaptation(.popover)
                }
            }
            .simultaneousGesture(
                DragGesture(minimumDistance: 30)
                    .onEnded { value in
                        handleTabBarSwipe(value.translation)
                    }
            )
            .frame(height: 64)
            .frame(maxWidth: .infinity)
            .padding(.horizontal, 12)
            .background {
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .fill(.clear)
                    .glassEffect()
                    .overlay {
                        RoundedRectangle(cornerRadius: 30, style: .continuous)
                            .fill(Color.accentColor.opacity(0.06))
                    }
                    .shadow(color: .black.opacity(0.05), radius: 8, y: 3)
                    .clipShape(
                        RoundedRectangle(cornerRadius: 30, style: .continuous)
                    )
            }
            .overlay {
                RoundedRectangle(cornerRadius: 30, style: .continuous)
                    .strokeBorder(.white.opacity(0.08), lineWidth: 0.6)
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 10)
            .offset(y: 10)
        }
        .ignoresSafeArea(.keyboard)
    }
    
    @ViewBuilder
    private var currentTabView: some View {
        
        switch selectedTab {
            
        case 10:
            NavigationStack(path: $dashboardPath) {
                Dashboard()
            }
            
            
        case 0:
            NavigationStack(path: $StartPath) {
                StartView()
            }
            
        case 1:
            NavigationStack(path: $listPath) {
                TaskListView()
            }
            
        case 4:
            NavigationStack(path: $weeklyPath) {
                WeeklyTasksView()
            }
            
        case 3:
            NavigationStack(path: $calendarPath) {
                TaskCalendarView(selectedDate: $sessionSelectedDate)
            }

        case 14:
            NavigationStack(path: $dayPath) {
                TaskDayView(selectedDate: $sessionSelectedDate)
            }
            
        case 5:
            NavigationStack(path: $mapPath) {
                TaskMapView(mapPath: $mapPath)
            }
            
        case 6:
            NavigationStack(path: $walletPath) {
                WalletView()
            }
        
        case 11:
            NavigationStack(path: $vaultPath) {
                VaultGateView()
            }
            
        case 7:
            NavigationStack(path: $TripsPath) {
                ChecklistListView()
            }
            
        case 8:
            NavigationStack(path: $documentsPath) {
                DocumentsView()
            }
        case 12:
            NavigationStack(path: $notesPath) {
                NoteListView(noteEditorCoordinator: noteEditorCoordinator)
                    .environmentObject(noteEditorCoordinator)
            }
        case 15:
            GlobalSearchView(noteEditorCoordinator: noteEditorCoordinator)
        case 9:
            NavigationStack(path: $weatherPath) {
                WeatherForecastView()
            }
            
        case 2:
            NavigationStack(path: $settingsPath) {
                SettingsView()
            }
        case 13:
            NavigationStack {
                RecentlyDeletedView(onClose: {
                    selectedTab = previousTab
                })
            }
        default:
            NavigationStack(path: $StartPath) {
                StartView()
            }
        }
    }
    
    // MARK: - iPad
    
    private var iPadLayout: some View {
        
        NavigationSplitView {
            
            List {
                ForEach(visibleTabs) { tab in
                    sidebarRow(tab.title(using: settings), tab.icon, tab.rawValue)
                }
            }
            .listStyle(.sidebar)
            .navigationTitle("Tasks")
            
        } detail: {
            currentTabView
                .safeAreaPadding(.leading, 8)
                
        }
    }
    
    private func sidebarRow(
        _ title: String,
        _ image: String,
        _ tag: Int
    ) -> some View {
        
        Button {
            selectedTab = tag
        } label: {
            HStack(spacing: 10) {
                Image(systemName: image)
                    .foregroundStyle(
                        Color(hex: settings.tabBarCustomizationIconColorHex) ?? .blue
                    )

                Text(title)
                    .foregroundStyle(.primary)

                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(.vertical, 6)
            .background(
                selectedTab == tag
                ? Color.accentColor.opacity(0.15)
                : Color.clear
            )
            .clipShape(RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
    }

    private func moreTabItem(_ tab: AppTab) -> some View {
        Button {
            selectedTab = tab.rawValue
            showMorePopover = false
        } label: {
            HStack(spacing: 10) {
                VStack(spacing: 4) {
                    Image(systemName: tab.icon)
                        .frame(width: 22)
                    Capsule()
                        .fill(Color(hex: settings.tabBarCustomizationIconColorHex) ?? .blue)
                        .frame(width: 16, height: 3)
                        .opacity(selectedTab == tab.rawValue ? 1 : 0)
                }

                Text(tab.title(using: settings))
            }
            .foregroundStyle(
                selectedTab == tab.rawValue
                ? (Color(hex: settings.tabBarCustomizationIconColorHex) ?? .blue)
                : Color.primary
            )
            .frame(maxWidth: .infinity, alignment: .leading)
            .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    
    private func selectTab(_ tag: Int) {
        if selectedTab == 12,
           tag != 12,
           noteEditorCoordinator.isDirty {
            pendingNoteTab = tag
            showNoteUnsavedChangesAlert = true
            return
        }
        resetTab(tag)
        
        withAnimation(nil) {
            selectedTab = tag
        }

//        Task {
//            resetTab(tag)
//        }
    }

    private func tabItem(
        _ icon: String,
        _ title: String,
        _ tag: Int
    ) -> some View {
        
        Button {
            
            if selectedTab != tag {
                selectTab(tag)
            }
            
        } label: {
            
            VStack(spacing: 2) {
                
                Image(systemName: icon)
                    .font(.system(size: 21, weight: .medium))
                    .frame(height: 22)
                
                Text(title)
                    .font(.system(size: 9, weight: .medium))
                    .lineLimit(1)
                    .minimumScaleFactor(0.75)
                
                Capsule()
                    .fill(Color(hex: settings.tabBarCustomizationIconColorHex) ?? .blue)
                    .frame(width: 16, height: 3)
                    .opacity(selectedTab == tag ? 1 : 0)
            }
            .frame(maxWidth: .infinity)
            .frame(height: 49)
            .contentShape(Rectangle())
            .foregroundStyle(
                selectedTab == tag
                ? (Color(hex: settings.tabBarCustomizationIconColorHex) ?? .blue)
                : Color.primary
            )
            // Bubble background removed
        }
        .buttonStyle(.plain)
    }
    
    private func handleTabBarSwipe(_ translation: CGSize) {
        let horizontalDistance = abs(translation.width)
        let verticalDistance = abs(translation.height)

        // Require a deliberate horizontal gesture to avoid accidental tab changes.
        guard horizontalDistance >= 45,
              horizontalDistance > verticalDistance * 1.2,
              let currentIndex = visibleTabs.firstIndex(where: { $0.rawValue == selectedTab })
        else {
            return
        }

        // Left swipe advances; right swipe goes back. Do not wrap at either end.
        let offset = translation.width < 0 ? 1 : -1
        let nextIndex = currentIndex + offset

        guard visibleTabs.indices.contains(nextIndex) else {
            return
        }

        showMorePopover = false
        selectTab(visibleTabs[nextIndex].rawValue)
    }

    private func syncWeatherLocationPermission() {
        let status = CLLocationManager().authorizationStatus
        let hasWeatherPermission =
            status == .authorizedAlways || status == .authorizedWhenInUse

        guard !hasWeatherPermission else {
            return
        }

        settings.showWeatherForecast = false
        WeatherManager.shared.locationPermissionWasRevoked()
    }

    private func resetTab(_ tab: Int) {
        
        switch tab {
            
        case 10:
            dashboardPath = NavigationPath()

            NotificationCenter.default.post(
                name: Notification.Name("DashboardReset"),
                object: nil
            )
            
        case 0:
            if !StartPath.isEmpty {
                StartPath = NavigationPath()
            }
            
        case 1:
            if !listPath.isEmpty {
                listPath = NavigationPath()
            }
            
        case 4:
            if !weeklyPath.isEmpty {
                weeklyPath = NavigationPath()
            }
            
        case 3:
            if !calendarPath.isEmpty {
                calendarPath = NavigationPath()
            }
        case 14:
            if !dayPath.isEmpty {
                dayPath = NavigationPath()
            }
            
        case 5:
            if !mapPath.isEmpty {
                mapPath = NavigationPath()
            }
            
        case 6:
            if !walletPath.isEmpty {
                walletPath = NavigationPath()
            }
        
        case 11:
            if !vaultPath.isEmpty {
                vaultPath = NavigationPath()
            }
            
        case 7:
            if !TripsPath.isEmpty {
                TripsPath = NavigationPath()
            }
        
        case 8:
            if !documentsPath.isEmpty {
                documentsPath = NavigationPath()
            }
        case 9:
            if !weatherPath.isEmpty {
                weatherPath = NavigationPath()
            }
            
        case 2:
            if !settingsPath.isEmpty {
                settingsPath = NavigationPath()
            }
        case 12:
            if !notesPath.isEmpty {
                notesPath = NavigationPath()
            }
        case 13:
            break
            
        default:
            break
        }
    }
}
