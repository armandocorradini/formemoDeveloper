import Foundation
import CoreLocation
import Observation
import SwiftUI

// MARK: - Daily Weather Info

struct DailyWeatherInfo {

    let date: Date

    let symbolName: String
    let weatherCode: Int

    let minTemperature: Int
    let maxTemperature: Int

    let precipitationChance: Int
    let precipitationAmount: Double

    let windSpeed: Int

    let sunrise: Date?
    let sunset: Date?

    let uvIndex: Int?
    let airQualityIndex: Int?

    let cloudCover: Int?
}

struct HourlyWeatherInfo {

    let date: Date
    let hour: Int

    let symbolName: String
    let weatherCode: Int

    let temperature: Int
    let precipitationChance: Int
    let windSpeed: Int
    let uvIndex: Int
    let humidity: Int
    let cloudCover: Int
}

private struct WeatherProcessingResult: Sendable {
    let weatherByDay: [Date: DailyWeatherInfo]
    let hourlyWeatherByDay: [Date: [HourlyWeatherInfo]]
}

// MARK: - Weather Manager

@MainActor
@Observable
final class WeatherManager {

    static let shared = WeatherManager()

    @ObservationIgnored
    @AppStorage("showWeatherForecast")
    private var showWeatherForecast: Bool = true

// MARK: - Open Meteo Response

private struct OpenMeteoResponse: Decodable {

    let daily: OpenMeteoDaily
    let hourly: OpenMeteoHourly
}

private struct OpenMeteoDaily: Decodable {

    let time: [String]

    let weather_code: [Int]

    let temperature_2m_min: [Double]
    let temperature_2m_max: [Double]

    let precipitation_probability_max: [Double]
    let precipitation_sum: [Double]

    let wind_speed_10m_max: [Double]

    let sunrise: [String]
    let sunset: [String]

    let uv_index_max: [Double?]
    let cloud_cover_mean: [Int]
    
}

private struct OpenMeteoHourly: Decodable {

    let time: [String]

    let weather_code: [Int]
    let cloud_cover: [Int]
    let precipitation_probability: [Int]
    let precipitation: [Double]
    let temperature_2m: [Double]
    let wind_speed_10m: [Double]
    let uv_index: [Double]
    let relative_humidity_2m: [Int]
}

    private(set) var weatherByDay: [Date: DailyWeatherInfo] = [:]
    private(set) var hourlyWeatherByDay: [Date: [HourlyWeatherInfo]] = [:]
    
    
    private(set) var isAvailable: Bool = false
    private(set) var isLoading: Bool = false
    private(set) var lastLoadFailed: Bool = false
    private(set) var refreshID = UUID()

    private var lastRefresh: Date = .distantPast

    private let refreshInterval: TimeInterval = 1800

    private var retryCount = 0

    private init() {}

    // MARK: - Public

    func weather(for date: Date) -> DailyWeatherInfo? {

        guard showWeatherForecast else {
            return nil
        }

        let key = Calendar.current.startOfDay(for: date)

        return weatherByDay[key]
    }
    
    
    func hourlyWeather(for date: Date) -> [HourlyWeatherInfo] {

        let key = Calendar.current.startOfDay(for: date)

        return hourlyWeatherByDay[key] ?? []
    }

    func representativeSymbol(for date: Date) -> String {

        if Calendar.current.isDateInToday(date) {

            let now = Date()

            let hourly = hourlyWeather(for: now)

            if let nearest = hourly.min(by: {
                abs($0.date.timeIntervalSince(now))
                < abs($1.date.timeIntervalSince(now))
            }) {
                return nearest.symbolName
            }

            return weather(for: now)?.symbolName
                ?? "cloud.sun.fill"
        }

        return weather(for: date)?.symbolName
            ?? "cloud.sun.fill"
    }
    
    func weatherDescription(
        weatherCode: Int,
        isDay: Bool
    ) -> String {

        switch weatherCode {

        case 0:
            return isDay
                ? String(localized: "Clear Sky")
                : String(localized: "Clear Night")

        case 1:
            return String(localized: "Mainly Clear")

        case 2:
            return isDay
                ? String(localized: "Partly Cloudy")
                : String(localized: "Partly Cloudy Night")

        case 3:
            return String(localized: "Overcast")

        case 45, 48:
            return String(localized: "Fog")

        case 51, 53, 55:
            return String(localized: "Drizzle")

        case 61, 63, 65:
            return String(localized: "Rain")

        case 80, 81, 82:
            return isDay
                ? String(localized: "Scattered Showers")
                : String(localized: "Night Showers")

        case 71, 73, 75, 77, 85, 86:
            return String(localized: "Snow")

        case 95, 96, 99:
            return String(localized: "Thunderstorm")

        default:
            return String(localized: "Variable")
        }
    }

    func refreshIfNeeded() async {

        guard showWeatherForecast else {
            weatherByDay = [:]
            refreshID = UUID()
            isAvailable = false
            isLoading = false
            lastLoadFailed = false
            return
        }
        guard Date().timeIntervalSince(lastRefresh) > refreshInterval else {
            return
        }

        await refresh()
    }

    func refresh() async {

        isLoading = true
        lastLoadFailed = false

        guard let location = LocationReminderManager.shared.currentLocation else {

            guard retryCount < 3 else {
                isAvailable = false
                isLoading = false
                lastLoadFailed = true
                refreshID = UUID()
                return
            }

            retryCount += 1

            LocationReminderManager.shared.requestCurrentLocation()

            isAvailable = false
            isLoading = false

            // Retry automatically after CoreLocation has time
            // to deliver a fresh location update.
            Task {
                try? await Task.sleep(for: .seconds(2))
                await refresh()
            }

            return
        }

        do {

            retryCount = 0

            let latitude = location.coordinate.latitude
            let longitude = location.coordinate.longitude

            let urlString = "https://air-quality-api.open-meteo.com/v1/air-quality?latitude=\(latitude)&longitude=\(longitude)&daily=pm10_max&timezone=auto"

            // Request 8 days because just after midnight the UI can already consume
            // today's forecast as day 0, causing the last visible future day to be missing.
            let forecastURLString = "https://api.open-meteo.com/v1/forecast?latitude=\(latitude)&longitude=\(longitude)&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,precipitation_sum,wind_speed_10m_max,sunrise,sunset,uv_index_max,cloud_cover_mean&hourly=weather_code,cloud_cover,precipitation_probability,precipitation,temperature_2m,wind_speed_10m,uv_index,relative_humidity_2m&forecast_days=8&timezone=auto"

            guard let url = URL(string: forecastURLString),
                  let airQualityURL = URL(string: urlString) else {
                isAvailable = false
                isLoading = false
                lastLoadFailed = true
                refreshID = UUID()
                return
            }

            async let forecastResponse = URLSession.shared.data(from: url)
            async let airQualityResponse = URLSession.shared.data(from: airQualityURL)

            let (data, _) = try await forecastResponse
            let (airQualityData, _) = try await airQualityResponse

            let decoded = try JSONDecoder().decode(OpenMeteoResponse.self, from: data)

            let airQualityDecoded = try JSONSerialization.jsonObject(with: airQualityData) as? [String: Any]

            let airQualityDaily = (airQualityDecoded?["daily"] as? [String: Any])

            let pm10Values = airQualityDaily?["pm10_max"] as? [Double?] ?? []


            let processingResult = await Task.detached(priority: .userInitiated) {
                WeatherManager.processWeatherData(
                    decoded: decoded,
                    pm10Values: pm10Values
                )
            }.value

            weatherByDay = processingResult.weatherByDay
            hourlyWeatherByDay = processingResult.hourlyWeatherByDay
            refreshID = UUID()
            isAvailable = !processingResult.weatherByDay.isEmpty
            isLoading = false
            lastLoadFailed = false
            lastRefresh = Date()

        } catch {

            refreshID = UUID()
            isAvailable = false
            isLoading = false
            lastLoadFailed = true
        }
    }

    private nonisolated static func processWeatherData(
        decoded: OpenMeteoResponse,
        pm10Values: [Double?]
    ) -> WeatherProcessingResult {

        var updated: [Date: DailyWeatherInfo] = [:]
        var hourlyUpdated: [Date: [HourlyWeatherInfo]] = [:]

        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withFullDate]

        let localDateFormatter = DateFormatter()
        localDateFormatter.locale = Locale(identifier: "en_US_POSIX")
        localDateFormatter.timeZone = .current
        localDateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm"

        for index in decoded.hourly.time.indices {

            guard let parsedDate = localDateFormatter.date(
                from: decoded.hourly.time[index]
            ) else {
                continue
            }

            let key = Calendar.current.startOfDay(for: parsedDate)
            let hour = Calendar.current.component(.hour, from: parsedDate)

            guard hour >= 0,
                  hour <= 23 else {
                continue
            }

            let weatherCode =
                decoded.hourly.weather_code[safe: index] ?? 0

            let cloudCover =
                decoded.hourly.cloud_cover[safe: index]

            let precipitationChance =
                decoded.hourly.precipitation_probability[safe: index] ?? 0

            let precipitationAmount =
                decoded.hourly.precipitation[safe: index] ?? 0

            let temperature = Int(
                (decoded.hourly.temperature_2m[safe: index] ?? 0).rounded()
            )

            let windSpeed = Int(
                (decoded.hourly.wind_speed_10m[safe: index] ?? 0).rounded()
            )

            let uvIndex = Int(
                (decoded.hourly.uv_index[safe: index] ?? 0).rounded()
            )

            let humidity =
                decoded.hourly.relative_humidity_2m[safe: index] ?? 0

            let symbolName: String

            if Calendar.current.isDateInToday(parsedDate) {
                symbolName = Self.symbol(
                    for: weatherCode,
                    cloudCover: cloudCover,
                    precipitationChance: precipitationChance,
                    precipitationAmount: precipitationAmount,
                    windSpeed: 0,
                    isDay: hour >= 6 && hour < 20
                )
            } else {
                symbolName = WeatherCondition(code: weatherCode)
                    .symbolName(
                        isDay: hour >= 6 && hour < 20,
                        cloudCover: cloudCover
                    )
            }

            hourlyUpdated[key, default: []].append(
                HourlyWeatherInfo(
                    date: parsedDate,
                    hour: hour,
                    symbolName: symbolName,
                    weatherCode: weatherCode,
                    temperature: temperature,
                    precipitationChance: precipitationChance,
                    windSpeed: windSpeed,
                    uvIndex: uvIndex,
                    humidity: humidity,
                    cloudCover: cloudCover ?? 0
                )
            )
        }

        for index in decoded.daily.time.indices {

            guard let date = formatter.date(
                from: decoded.daily.time[index]
            ) else {
                continue
            }

            let key = Calendar.current.startOfDay(for: date)

            let weatherCode =
                decoded.daily.weather_code[safe: index] ?? 0

            let daytimeCodes = Self.hourlyWeatherCodes(
                for: date,
                hourly: decoded.hourly
            )

            let dominantWeatherCode = Self.dominantDaytimeWeatherCode(
                fallback: weatherCode,
                hourlyCodes: daytimeCodes
            )

            let daytimePrecipitationChance =
                Self.daytimePrecipitationProbability(
                    for: date,
                    hourly: decoded.hourly
                )

            let daytimePrecipitationAmount =
                Self.daytimePrecipitationAmount(
                    for: date,
                    hourly: decoded.hourly
                )

            let precipitationChance = max(
                Double(daytimePrecipitationChance),
                (decoded.daily.precipitation_probability_max[safe: index] ?? 0) * 0.45)

            let precipitationAmount = max(
                daytimePrecipitationAmount,
                (decoded.daily.precipitation_sum[safe: index] ?? 0) * 0.35)
                
            let windSpeed =
                decoded.daily.wind_speed_10m_max[safe: index] ?? 0

            let uvIndex = decoded.daily.uv_index_max[safe: index] ?? nil

            let airQuality =
                index < pm10Values.count
                ? pm10Values[index]
                : nil

            let sunrise = localDateFormatter.date(
                from: decoded.daily.sunrise[safe: index] ?? ""
            )

            let sunset = localDateFormatter.date(
                from: decoded.daily.sunset[safe: index] ?? ""
            )

            let now = Date()

            let isCurrentlyDaytime: Bool

            if Calendar.current.isDateInToday(date),
               let sunrise,
               let sunset {

                let currentHour =
                    Calendar.current.component(.hour, from: now)

                let sunriseHour =
                    Calendar.current.component(.hour, from: sunrise)

                let sunsetHour =
                    Calendar.current.component(.hour, from: sunset)

                isCurrentlyDaytime =
                    currentHour >= sunriseHour &&
                    currentHour < sunsetHour

            } else {
                isCurrentlyDaytime = true
            }

            updated[key] = DailyWeatherInfo(
                date: date,
                symbolName: Self.symbol(
                    for: dominantWeatherCode,
                    cloudCover: decoded.daily.cloud_cover_mean[safe: index],
                    precipitationChance: Int(precipitationChance.rounded()),
                    precipitationAmount: precipitationAmount,
                    windSpeed: Int(windSpeed.rounded()),
                    isDay: isCurrentlyDaytime
                ),
                weatherCode: dominantWeatherCode,
                minTemperature:
                    Int((decoded.daily.temperature_2m_min[safe: index] ?? 0).rounded()),
                maxTemperature:
                    Int((decoded.daily.temperature_2m_max[safe: index] ?? 0).rounded()),
                precipitationChance:
                    Int(precipitationChance.rounded()),
                precipitationAmount: precipitationAmount,
                windSpeed:
                    Int(windSpeed.rounded()),
                sunrise: sunrise,
                sunset: sunset,
                uvIndex:
                    uvIndex.map { Int($0.rounded()) },
                airQualityIndex:
                    airQuality.map { Int($0.rounded()) },
                cloudCover:
                    decoded.daily.cloud_cover_mean[safe: index]
            )
        }

        return WeatherProcessingResult(
            weatherByDay: updated,
            hourlyWeatherByDay: hourlyUpdated
        )
    }
    
    
    // MARK: - Weather Symbol Mapping

    private nonisolated static func symbol(
        for weatherCode: Int,
        cloudCover: Int?,
        precipitationChance: Int,
        precipitationAmount: Double,
        windSpeed: Int,
        isDay: Bool = true
    ) -> String {

        let condition = WeatherCondition(code: weatherCode)

        let clouds = max(0, min(cloudCover ?? 0, 100))

        let sunshineScore = max(
            0,
            115
            - clouds
            - Int(Double(precipitationChance) * 0.38)
            - Int(precipitationAmount * 3.2)
        )
        let severeWeatherCodes: Set<Int> = [63, 65, 81, 82, 95, 96, 99]

        let isSevereWeather = severeWeatherCodes.contains(weatherCode)

        // Strong rain
        if precipitationAmount >= 8 {
            return "cloud.heavyrain.fill"
        }

        // Real thunderstorms only
        if [95, 96, 99].contains(weatherCode) {

            if precipitationChance >= 80,
               precipitationAmount >= 8 {

                return "cloud.bolt.rain.fill"
            }

            return isDay
                ? "cloud.sun.rain.fill"
                : "cloud.moon.rain.fill"
        }


        // Pleasant / mostly dry days
        if sunshineScore >= 28,
           precipitationAmount < 2,
           precipitationChance < 72 {

            if clouds < 25 {
                return isDay
                    ? "sun.max.fill"
                    : "moon.stars.fill"
            }

            return isDay
                ? "cloud.sun.fill"
                : "cloud.moon.fill"
        }

        // Windy dry conditions
        if windSpeed >= 45,
           precipitationAmount < 1 {

            return "wind"
        }

        // Light precipitation should not dominate the whole day icon
        // Persistent drizzle / humid grey weather
        if precipitationAmount >= 0.3,
           precipitationAmount < 1.2,
           precipitationChance >= 55,
           clouds >= 70 {

            return "cloud.drizzle.fill"
        }

        // Ignore isolated weak showers during otherwise pleasant days
        if !isSevereWeather,
           sunshineScore >= 46,
           precipitationAmount < 2.2,
           precipitationChance < 72 {

            if clouds < 25 {
                return isDay
                    ? "sun.max.fill"
                    : "moon.stars.fill"
            }

            return isDay
                ? "cloud.sun.fill"
                : "cloud.moon.fill"
        }

        // Real scattered showers only if truly relevant
        if precipitationAmount >= 2.2,
           precipitationChance >= 68 {

            if sunshineScore >= 42 {

                return isDay
                    ? "cloud.sun.rain.fill"
                    : "cloud.moon.rain.fill"
            }

            return "cloud.rain.fill"
        }

        return condition.symbolName(
            isDay: isDay,
            cloudCover: cloudCover
        )
    }

    private nonisolated static func hourlyWeatherCodes(
        for date: Date,
        hourly: OpenMeteoHourly
    ) -> [Int] {

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
        let calendar = Calendar.current

        let (startHour, endHour) = weatherEvaluationWindow(for: date)

        return zip(hourly.time.indices, hourly.time)
            .compactMap { index, rawDate in

                guard let parsedDate = formatter.date(from: rawDate) else {
                    return nil
                }

                guard calendar.isDate(parsedDate, inSameDayAs: date) else {
                    return nil
                }

                let hour = calendar.component(.hour, from: parsedDate)

                guard (startHour...endHour).contains(hour) else {
                    return nil
                }

                return hourly.weather_code[safe: index]
            }
    }

    private nonisolated static func daytimePrecipitationProbability(
        for date: Date,
        hourly: OpenMeteoHourly
    ) -> Int {

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
        let calendar = Calendar.current

        let (startHour, endHour) = weatherEvaluationWindow(for: date)

        let values = zip(hourly.time.indices, hourly.time)
            .compactMap { index, rawDate -> Int? in

                guard let parsedDate = formatter.date(from: rawDate) else {
                    return nil
                }

                guard calendar.isDate(parsedDate, inSameDayAs: date) else {
                    return nil
                }

                let hour = calendar.component(.hour, from: parsedDate)

                guard (startHour...endHour).contains(hour) else {
                    return nil
                }

                return hourly.precipitation_probability[safe: index]
            }

        guard !values.isEmpty else {
            return 0
        }

        let sorted = values.sorted()

        return sorted[sorted.count / 2]
    }

    private nonisolated static func daytimePrecipitationAmount(
        for date: Date,
        hourly: OpenMeteoHourly
    ) -> Double {

        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = .current
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm"
        let calendar = Calendar.current

        let (startHour, endHour) = weatherEvaluationWindow(for: date)

        return zip(hourly.time.indices, hourly.time)
            .compactMap { index, rawDate -> Double? in

                guard let parsedDate = formatter.date(from: rawDate) else {
                    return nil
                }

                guard calendar.isDate(parsedDate, inSameDayAs: date) else {
                    return nil
                }

                let hour = calendar.component(.hour, from: parsedDate)

                guard (startHour...endHour).contains(hour) else {
                    return nil
                }

                return hourly.precipitation[safe: index]
            }
            .reduce(0, +) / 2.8
    }

    private nonisolated static func dominantDaytimeWeatherCode(
        fallback: Int,
        hourlyCodes: [Int]
    ) -> Int {

        guard !hourlyCodes.isEmpty else {
            return fallback
        }

        var weightedScores: [Int: Double] = [:]

        for code in hourlyCodes {

            let baseWeight: Double

            switch code {

            // Clear / pleasant
            case 0:
                baseWeight = 5.5

            case 1:
                baseWeight = 5.0

            case 2:
                baseWeight = 4.2

            // Overcast
            case 3:
                baseWeight = 2.4

            // Fog
            case 45, 48:
                baseWeight = 1.8

            // Drizzle
            case 51, 53, 55:
                baseWeight = 1.4

            // Light rain / isolated showers
            case 61, 80:
                baseWeight = 0.9

            // Moderate rain
            case 63, 81:
                baseWeight = 0.45

            // Heavy rain / violent showers
            case 65, 82:
                baseWeight = 0.15

            // Thunderstorm
            case 95, 96, 99:
                baseWeight = 0.08

            default:
                baseWeight = 1.0
            }

            weightedScores[code, default: 0] += baseWeight
        }

        // Strong sunshine bias
        let sunshineHours = hourlyCodes.filter {
            [0, 1, 2].contains($0)
        }.count

        if sunshineHours >= 4 {

            if sunshineHours >= 6 {
                return 0
            }

            return 1
        }

        return weightedScores
            .max(by: { $0.value < $1.value })?
            .key ?? fallback
    }
    
    
    private nonisolated static func weatherEvaluationWindow(
        for date: Date
    ) -> (startHour: Int, endHour: Int) {

        let calendar = Calendar.current

        guard calendar.isDateInToday(date) else {

            return (10, 17)
        }

        let currentHour = calendar.component(.hour, from: .now)

        switch currentHour {

        case ..<10:

            return (10, 17)

        case 10..<14:

            return (
                currentHour,
                min(currentHour + 7, 18)
            )

        case 14..<16:

            return (
                currentHour,
                min(currentHour + 5, 19)
            )

        case 16..<18:

            return (
                currentHour,
                min(currentHour + 4, 20)
            )

        case 18..<21:

            return (
                currentHour,
                21
            )

        default:

            return (
                currentHour,
                23
            )
        }
    }
}

// MARK: - Weather Condition

enum WeatherCondition: Int, Sendable {

    // Clear / Clouds

    case clearSky = 0
    case mainlyClear = 1
    case partlyCloudy = 2
    case overcast = 3

    // Fog

    case fog = 45
    case depositingRimeFog = 48

    // Drizzle

    case drizzleLight = 51
    case drizzleModerate = 53
    case drizzleDense = 55

    // Freezing Drizzle

    case freezingDrizzleLight = 56
    case freezingDrizzleDense = 57

    // Rain

    case rainSlight = 61
    case rainModerate = 63
    case rainHeavy = 65

    // Freezing Rain

    case freezingRainLight = 66
    case freezingRainHeavy = 67

    // Snow

    case snowFallSlight = 71
    case snowFallModerate = 73
    case snowFallHeavy = 75
    case snowGrains = 77

    // Rain Showers

    case rainShowersSlight = 80
    case rainShowersModerate = 81
    case rainShowersViolent = 82

    // Snow Showers

    case snowShowersSlight = 85
    case snowShowersHeavy = 86

    // Thunderstorm

    case thunderstorm = 95
    case thunderstormHailSlight = 96
    case thunderstormHailHeavy = 99

    // Unknown

    case unknown = -1

    nonisolated init(code: Int?) {

        guard let code else {
            self = .unknown
            return
        }

        self = Self(rawValue: code) ?? .unknown
    }
}

// MARK: - Symbol Mapping

extension WeatherCondition {

    nonisolated
    func symbolName(
        isDay: Bool,
        cloudCover: Int? = nil
    ) -> String {

        let clouds = max(0, min(cloudCover ?? 0, 100))

        switch self {

        // =====================================================
        // Thunderstorm
        // =====================================================

        case .thunderstorm,
             .thunderstormHailSlight,
             .thunderstormHailHeavy:

            return "cloud.bolt.rain.fill"

        // =====================================================
        // Snow
        // =====================================================

        case .snowFallSlight,
             .snowFallModerate,
             .snowFallHeavy,
             .snowGrains,
             .snowShowersSlight,
             .snowShowersHeavy:

            return "cloud.snow.fill"

        // =====================================================
        // Heavy Rain
        // =====================================================

        case .rainHeavy,
             .freezingRainHeavy,
             .rainShowersViolent:

            return "cloud.heavyrain.fill"

        // =====================================================
        // Moderate Rain
        // =====================================================

        case .rainModerate,
             .freezingRainLight,
             .rainShowersModerate:

            return isDay
                ? "cloud.sun.rain.fill"
                : "cloud.moon.rain.fill"

        // =====================================================
        // Light Rain / Drizzle
        // =====================================================

        case .rainSlight,
             .rainShowersSlight,
             .drizzleLight,
             .drizzleModerate:

            if clouds < 55 {

                return isDay
                    ? "cloud.sun.rain.fill"
                    : "cloud.moon.rain.fill"
            }

            return "cloud.drizzle.fill"

        // =====================================================
        // Dense / Freezing Drizzle
        // =====================================================

        case .drizzleDense,
             .freezingDrizzleLight,
             .freezingDrizzleDense:

            return "cloud.sleet.fill"

        // =====================================================
        // Fog
        // =====================================================

        case .fog,
             .depositingRimeFog:

            return "cloud.fog.fill"

        // =====================================================
        // Clear Sky
        // =====================================================

        case .clearSky:

            switch clouds {

            case 0..<20:

                return isDay
                    ? "sun.max.fill"
                    : "moon.stars.fill"

            case 20..<85:

                return isDay
                    ? "cloud.sun.fill"
                    : "cloud.moon.fill"

            default:

                return "cloud.fill"
            }

        // =====================================================
        // Mainly Clear
        // =====================================================

        case .mainlyClear:

            switch clouds {

            case 0..<92:

                return isDay
                    ? "cloud.sun.fill"
                    : "cloud.moon.fill"

            default:

                return "cloud.fill"
            }

        // =====================================================
        // Partly Cloudy
        // =====================================================

        case .partlyCloudy:

            return isDay
                ? "cloud.sun.fill"
                : "cloud.moon.fill"

        // =====================================================
        // Overcast
        // =====================================================

        case .overcast:

            switch clouds {
            case 0..<85:
                return isDay
                    ? "cloud.sun.fill"
                    : "cloud.moon.fill"
            default:
                return "cloud.fill"
            }

        // =====================================================
        // Unknown
        // =====================================================

        case .unknown:

            return isDay
                ? "cloud.sun.fill"
                : "cloud.moon.fill"
        }
    }
}

private extension Array {

    nonisolated subscript(safe index: Int) -> Element? {

        guard indices.contains(index) else {
            return nil
        }

        return self[index]
    }
}
